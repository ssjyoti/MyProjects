package com.sogetinl.cg.vo.dashboard;

import java.io.Serializable;

public class DashboardTenantVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String clientName;

	private String tenantName;

	private String lastExtractionDate;

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public String getLastExtractionDate() {
		return lastExtractionDate;
	}

	public void setLastExtractionDate(String lastExtractionDate) {
		this.lastExtractionDate = lastExtractionDate;
	}

}
