package com.sogetinl.cg.serviceimpl.cart;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.UserConstants;
import com.sogetinl.cg.dao.cart.ShoppingCartDAO;
import com.sogetinl.cg.domain.Cart;
import com.sogetinl.cg.domain.Orders;
import com.sogetinl.cg.service.cart.ShoppingCartService;
import com.sogetinl.cg.vo.petVO.CartVO;
import com.sogetinl.cg.vo.petVO.OrderVO;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ShoppingCartServiceImpl implements ShoppingCartService
{

   private final static Logger LOG = Logger.getLogger(ShoppingCartServiceImpl.class);

   @Autowired
   private ShoppingCartDAO shoppingCartDAO;

   @Override
   public List<CartVO> getShoppingCartData() throws PetSuppliesException
   {
      LOG.info("ShoppingCartServiceImpl >> getShoppingCartData >> ENTER");
      CartVO cartVO;
      List<Cart> cart = shoppingCartDAO.findAll();
      List<CartVO> searchResults = new ArrayList<CartVO>();
      try
      {
         for (Cart crt : cart)
         {
            cartVO = new CartVO();
            cartVO.setCartId(crt.getCartId());
            cartVO.setOrderType(crt.getOrderType());
            cartVO.setOrderDate(crt.getOrderDate().toString());
            cartVO.setOrderPrice(crt.getOrderPrice());
            cartVO.setOrderQuantity(crt.getOrderQuantity());
            cartVO.setPurchaseOrder(crt.getPurchaseOrder());
            cartVO.setOrderStatus(crt.getOrderStatus());
           

            searchResults.add(cartVO);
         }

      }
      catch (Exception e)
      {
         LOG.info("ShoppingCartServiceImpl >> Exception >> EXIT"+e);
      }

      LOG.info("ShoppingCartServiceImpl >> getShoppingCartData >> EXIT");
      return searchResults;

   }
   
   @Override
   public String updateShoppingCart(final CartVO cartVO) throws PetSuppliesException {
      LOG.info("ShoppingCartServiceImpl>>> updateShoppingCart CartVO>>  "
            + cartVO.toString());
      
      final Cart cart = new Cart();
      
      cart.setCartId(cartVO.getCartId());
      cart.setOrderType(cartVO.getOrderType());
      cart.setOrderPrice(cartVO.getOrderPrice());
      cart.setPurchaseOrder(cartVO.getPurchaseOrder());
      cart.setOrderQuantity(cartVO.getOrderQuantity());
      cart.setOrderStatus(cartVO.getOrderStatus());
      BeanUtils.copyProperties(cartVO, cart);
      
     
      LOG.info("ShoppingCartServiceImpl>>> updateShoppingCart  cart>>  "
            + cart.toString());
      shoppingCartDAO.updateCart(cart);
      return UserConstants.PRODUCT_UPDATE_SUCCESS;
   }
   
   
   @Override
   public String placeOrder(final OrderVO orderVO) throws PetSuppliesException {
      LOG.info("ShoppingCartServiceImpl>>> placeOrder productVO>>  "
            + orderVO.toString());
     
      final Orders orders = new Orders();
      
      orders.setOrderId(orderVO.getOrderId());
      orders.setOrderType(orderVO.getOrderType());
      orders.setOrderPrice(orderVO.getOrderPrice());
      orders.setPurchaseOrder(orderVO.getPurchaseOrder());
      orders.setOrderQuantity(orderVO.getOrderQuantity());
      orders.setOrderStatus(orderVO.getOrderStatus());
      
           
      BeanUtils.copyProperties(orderVO, orders);
      
     
      
      LOG.info("ShoppingCartServiceImpl>>> placeOrder  >>  "
            + orders.toString());
      shoppingCartDAO.placeOrder(orders,orderVO.getCartId());
      return UserConstants.PRODUCT_UPDATE_SUCCESS;
   }


}
