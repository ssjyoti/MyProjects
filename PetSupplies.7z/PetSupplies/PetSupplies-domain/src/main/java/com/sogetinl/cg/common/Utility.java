package com.sogetinl.cg.common;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

public class Utility {
	private final static Logger LOG = Logger.getLogger(Utility.class);

	private static final String ACCESS_PROPERTIES_FILE = "clientUserAccess";

	public static Map<String, String> getAllAccessList() {
		final Map<String, String> allAccessMap = new HashMap<String, String>();
		final ResourceBundle rb = ResourceBundle
				.getBundle(ACCESS_PROPERTIES_FILE);
		final Enumeration<String> keys = rb.getKeys();
		while (keys.hasMoreElements()) {
			final String key = keys.nextElement();
			final String value = rb.getString(key);
			allAccessMap.put(key, value);
		}
		LOG.info(allAccessMap.toString());
		return allAccessMap;
	}

}
