package com.sogetinl.cg.service.authentication;

import java.util.List;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.domain.Person;
import com.sogetinl.cg.domain.User;
import com.sogetinl.cg.vo.user.UserVO;

public interface AuthenticationService
{

   public User authenticate(Person person) throws PetSuppliesException;

   public List<UserVO> getUserListForAdmin(User user) throws PetSuppliesException;
   
   public String updateUser(UserVO userVO) throws PetSuppliesException;
   
   public int changePassword(String userName, String password) throws PetSuppliesException;



}
