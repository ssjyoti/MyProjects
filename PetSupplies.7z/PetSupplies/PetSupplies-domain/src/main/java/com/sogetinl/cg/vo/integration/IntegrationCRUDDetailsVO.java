package com.sogetinl.cg.vo.integration;

import java.io.Serializable;

public class IntegrationCRUDDetailsVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private int id;

	private String integrationID;

	private String integrationName;

	private String dataDescription;

	private String functionalArea;

	private String vendor;

	private String direction;

	private String isFormat;

	private String method;

	private String dataSource;

	private int expectedProcessing;

	private int expectedTransaction;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIntegrationID() {
		return integrationID;
	}

	public void setIntegrationID(String integrationID) {
		this.integrationID = integrationID;
	}

	public String getIntegrationName() {
		return integrationName;
	}

	public void setIntegrationName(String integrationName) {
		this.integrationName = integrationName;
	}

	public String getDataDescription() {
		return dataDescription;
	}

	public void setDataDescription(String dataDescription) {
		this.dataDescription = dataDescription;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getIsFormat() {
		return isFormat;
	}

	public void setIsFormat(String isFormat) {
		this.isFormat = isFormat;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public int getExpectedProcessing() {
		return expectedProcessing;
	}

	public void setExpectedProcessing(int expectedProcessing) {
		this.expectedProcessing = expectedProcessing;
	}

	public int getExpectedTransaction() {
		return expectedTransaction;
	}

	public void setExpectedTransaction(int expectedTransaction) {
		this.expectedTransaction = expectedTransaction;
	}

	@Override
	public String toString() {
		return "IntegrationCRUDDetailsVO [integrationID=" + integrationID
				+ ", dataDescription=" + dataDescription + ", functionalArea="
				+ functionalArea + ", vendor=" + vendor + ", direction="
				+ direction + ", isFormat=" + isFormat + ", method=" + method
				+ ", dataSource=" + dataSource + ", expectedProcessing="
				+ expectedProcessing + ", expectedTransaction="
				+ expectedTransaction + "]";
	}

}
