package com.sogetinl.cg.vo.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.sogetinl.cg.domain.UserRole;

public class UserVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userName;

	private String firstName;

	private String lastName;

	private String email;

	private String address;

	private String contactNumber;

	private Integer clientId;

	private String clientName;

	private String accessType;

	private String status;

	private String errorMsg;

	private Boolean isNewClient;
	
	private String comment;
	
	private Boolean isPwdReset;
	
	private String password;
	
	private String newPassword;

	private String cnfNewPassword;
	
	private List<UserRole> userroles = new ArrayList<UserRole>();

	public String getUserName() {
		return userName;
	}

	public void setUserName(final String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(final String address) {
		this.address = address;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(final String contactNumber) {
		this.contactNumber = contactNumber;
	}

	/**
	 * @return the clientId
	 */
	public Integer getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(final Integer clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}

	/**
	 * @param clientName
	 *            the clientName to set
	 */
	public void setClientName(final String clientName) {
		this.clientName = clientName;
	}

	/**
	 * @return the accessType
	 */
	public String getAccessType() {
		return accessType;
	}

	/**
	 * @param accessType
	 *            the accessType to set
	 */
	public void setAccessType(final String accessType) {
		this.accessType = accessType;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(final String status) {
		this.status = status;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg
	 *            the errorMsg to set
	 */
	public void setErrorMsg(final String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the isNewClient
	 */
	public Boolean getIsNewClient() {
		return isNewClient;
	}

	/**
	 * @param isNewClient
	 *            the isNewClient to set
	 */
	public void setIsNewClient(final Boolean isNewClient) {
		this.isNewClient = isNewClient;
	}

	/**
	 * @return the userroles
	 */
	public List<UserRole> getUserroles() {
		return userroles;
	}

	/**
	 * @param userroles
	 *            the userroles to set
	 */
	public void setUserroles(final List<UserRole> userroles) {
		this.userroles = userroles;
	}

	/**
	 * @return the comments
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComment(String comments) {
		this.comment = comments;
	}

	/**
	 * @return the isPwdReset
	 */
	public Boolean getIsPwdReset() {
		return isPwdReset;
	}

	/**
	 * @param isPwdReset
	 *            the isPwdReset to set
	 */
	public void setIsPwdReset(Boolean isPwdReset) {
		this.isPwdReset = isPwdReset;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}

	/**
	 * @param newPassword
	 *            the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	/**
	 * @return the cnfNewPassword
	 */
	public String getCnfNewPassword() {
		return cnfNewPassword;
	}

	/**
	 * @param cnfNewPassword
	 *            the cnfNewPassword to set
	 */
	public void setCnfNewPassword(String cnfNewPassword) {
		this.cnfNewPassword = cnfNewPassword;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("UserVO [userName=");
		builder.append(userName);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", email=");
		builder.append(email);
		builder.append(", address=");
		builder.append(address);
		builder.append(", contactNumber=");
		builder.append(contactNumber);
		builder.append(", clientId=");
		builder.append(clientId);
		builder.append(", clientName=");
		builder.append(clientName);
		builder.append(", accessType=");
		builder.append(accessType);
		builder.append(", status=");
		builder.append(status);
		builder.append(", errorMsg=");
		builder.append(errorMsg);
		builder.append(", isNewClient=");
		builder.append(isNewClient);
		builder.append(", comment=");
		builder.append(comment);
		builder.append("]");
		return builder.toString();
	}
}
