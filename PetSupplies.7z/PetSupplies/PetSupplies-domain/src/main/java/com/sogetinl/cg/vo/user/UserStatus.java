package com.sogetinl.cg.vo.user;

public enum UserStatus {
	INPROGRESS("INPROGRESS"), REJETCED("REJETCED"), LOCKED("LOCKED"), ACTIVE(
			"ACTIVE");

	private String userStatus;

	private UserStatus(final String userStatus) {
		this.userStatus = userStatus;
	}

	public String getValue() {
		return userStatus;
	}
}
