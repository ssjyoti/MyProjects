package com.sogetinl.cg.serviceimpl.order;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.UserConstants;
import com.sogetinl.cg.dao.order.OrderManagementDAO;
import com.sogetinl.cg.domain.Orders;
import com.sogetinl.cg.service.order.OrderManagementService;
import com.sogetinl.cg.vo.petVO.OrderVO;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class OrderManagementServiceImpl implements OrderManagementService
{

   private final static Logger LOG = Logger.getLogger(OrderManagementServiceImpl.class);

   @Autowired
   private OrderManagementDAO orderManagementDAO;

   @Override
   public List<OrderVO> getOrderData() throws PetSuppliesException
   {
      LOG.info("OrderManagementServiceImpl >> getOrderData >> ENTER");
      OrderVO orderVO;
      List<Orders> orders = orderManagementDAO.findAll();
      List<OrderVO> searchResults = new ArrayList<OrderVO>();
      try
      {
         for (Orders ord : orders)
         {
            orderVO = new OrderVO();
            orderVO.setOrderId(ord.getOrderId());
            orderVO.setOrderType(ord.getOrderType());
            orderVO.setOrderDate(ord.getOrderDate().toString());
            orderVO.setOrderPrice(ord.getOrderPrice());
            orderVO.setOrderQuantity(ord.getOrderQuantity());
            orderVO.setPurchaseOrder(ord.getPurchaseOrder());
            orderVO.setOrderStatus(ord.getOrderStatus());
           

            searchResults.add(orderVO);
         }

      }
      catch (Exception e)
      {
         LOG.info("OrderManagementServiceImpl >> Exception >> EXIT"+e);
      }

      LOG.info("OrderManagementServiceImpl >> getDashboardData >> EXIT");
      return searchResults;

   }
   
   @Override
   public String updateOrder(final OrderVO orderVO) throws PetSuppliesException {
      LOG.info("OrderManagementServiceImpl>>> updateProduct productVO>>  "
            + orderVO.toString());
     
      final Orders orders = new Orders();
      
      orders.setOrderId(orderVO.getOrderId());
      orders.setOrderType(orderVO.getOrderType());
      orders.setOrderPrice(orderVO.getOrderPrice());
      orders.setPurchaseOrder(orderVO.getPurchaseOrder());
      orders.setOrderQuantity(orderVO.getOrderQuantity());
      orders.setOrderStatus(orderVO.getOrderStatus());
      
           
      BeanUtils.copyProperties(orderVO, orders);
      
     
      
      LOG.info("OrderManagementServiceImpl>>> updateProduct  product>>  "
            + orders.toString());
      orderManagementDAO.updateOrder(orders);
      return UserConstants.PRODUCT_UPDATE_SUCCESS;
   }

}
