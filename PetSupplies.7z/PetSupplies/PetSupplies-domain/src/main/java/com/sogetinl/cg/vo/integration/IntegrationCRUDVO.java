package com.sogetinl.cg.vo.integration;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class IntegrationCRUDVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<String> vendorList;

	private Map<String, String> integrationMap;

	private Map<String, List<IntegrationCRUDDetailsVO>> vendorMap;

	public List<String> getVendorList() {
		return vendorList;
	}

	public void setVendorList(final List<String> vendorList) {
		this.vendorList = vendorList;
	}

	public Map<String, String> getIntegrationMap() {
		return integrationMap;
	}

	public void setIntegrationMap(Map<String, String> integrationMap) {
		this.integrationMap = integrationMap;
	}

	public Map<String, List<IntegrationCRUDDetailsVO>> getVendorMap() {
		return vendorMap;
	}

	public void setVendorMap(
			final Map<String, List<IntegrationCRUDDetailsVO>> vendorMap) {
		this.vendorMap = vendorMap;
	}

}
