package com.sogetinl.cg.service.order;

import java.util.List;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.vo.petVO.OrderVO;

public interface OrderManagementService
{
   public List<OrderVO> getOrderData() throws PetSuppliesException;
   
   public String updateOrder(OrderVO orderVO) throws PetSuppliesException;
   
}
