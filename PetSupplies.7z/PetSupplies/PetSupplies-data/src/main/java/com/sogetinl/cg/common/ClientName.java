package com.sogetinl.cg.common;

public enum ClientName {
	US("US"), ASIAPAC("ASIAPAC"), ANZ("ANZ"), UK("UK"), SA("SA"), PetSupplies("PetSupplies");

	private String cName;

	private ClientName(final String cName) {
		this.cName = cName;
	}

	public String getValue() {
		return cName;
	}
}
