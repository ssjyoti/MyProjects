
package com.sogetinl.cg.daoimpl.cart;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.dao.cart.ShoppingCartDAO;
import com.sogetinl.cg.domain.Cart;
import com.sogetinl.cg.domain.Orders;

@Repository
@Transactional
public class ShoppingCartDAOImpl implements ShoppingCartDAO
{

   private final static Logger LOG = Logger.getLogger(ShoppingCartDAOImpl.class);

   @PersistenceContext(unitName = "PetSuppliesUnit")
   private EntityManager entityManager;

   @SuppressWarnings("unchecked")
   @Override

   public List<Cart> findAll() throws PetSuppliesException
   {

      LOG.info("getting All Cart");
      try
      {
         final Query query = entityManager.createQuery("from Cart");
         final List<Cart> cart = query.getResultList();
         LOG.info("cart@ShoppingCartDAO: Returning " + cart.size());
         return cart;
      }
      catch (final Exception re)
      {
         LOG.error("get failed", re);
re.printStackTrace();
         throw new PetSuppliesException(re.getMessage());
      }

   }
  
   
   @Override
   public void updateCart(final Cart cart) throws PetSuppliesException {
        LOG.info("saveOrUpdate Cart");
      try {
         entityManager.merge(cart);
         entityManager.flush();
         LOG.info("saveOrUpdate successful");
      } catch (final Exception re) {
         LOG.error("saveOrUpdate failed", re);
         throw new PetSuppliesException(re.getMessage());
      }
   }
   
   @Override
   public void removeCart(final String cartId) throws PetSuppliesException {
        LOG.info("remove from Cart");
        int deletedRecord = 0;
      try {
         deletedRecord = entityManager
               .createQuery(
                     "delete from Cart c where c.getCartId=:getCartId")
               .setParameter("getCartId", cartId).executeUpdate();
         entityManager.flush();
         LOG.info("AuthenticationDAO::deleting client " +cartId
               + " successful. Deleted " + deletedRecord + " record.");
         LOG.info("remove successful");
      } catch (final Exception re) {
         LOG.error("remove failed", re);
         throw new PetSuppliesException(re.getMessage());
      }
   }


   @Override
   public void placeOrder(final Orders orders,String cartId) throws PetSuppliesException {
        LOG.info("save Product");
      try {
         entityManager.merge(orders);
         entityManager.flush();
         removeCart(cartId);
         LOG.info("save successful");
      } catch (final Exception re) {
         LOG.error("save failed", re);
         throw new PetSuppliesException(re.getMessage());
      }
   }
   
   
}
