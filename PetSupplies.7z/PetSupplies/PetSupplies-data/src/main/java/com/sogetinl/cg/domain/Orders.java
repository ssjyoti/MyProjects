package com.sogetinl.cg.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Orders implements Serializable
{

   private static final long serialVersionUID = -826045311764871L;

   /*
    * @GeneratedValue(strategy = GenerationType.AUTO)
    * @Column(name = "ID") private Integer id;
    */

   @Id
   @Column(name = "ORDER_ID")
   private String orderId;

   @Column(name = "ORDER_TYPE")
   private String orderType;

   @Column(name = "ORDER_QUANTITY")
   private String orderQuantity;

   @Column(name = "ORDER_PRICE")
   private String orderPrice;

   @Column(name = "ORDER_DATE")
   private Timestamp orderDate;

   @Column(name = "PURCHASE_ORDER")
   private String purchaseOrder;

   @Column(name = "ORDER_STATUS")
   private String orderStatus;

   public String getOrderId()
   {
      return orderId;
   }

   public void setOrderId(String orderId)
   {
      this.orderId = orderId;
   }

   public String getOrderType()
   {
      return orderType;
   }

   public void setOrderType(String orderType)
   {
      this.orderType = orderType;
   }

   public String getOrderQuantity()
   {
      return orderQuantity;
   }

   public void setOrderQuantity(String orderQuantity)
   {
      this.orderQuantity = orderQuantity;
   }

   public String getOrderPrice()
   {
      return orderPrice;
   }

   public void setOrderPrice(String orderPrice)
   {
      this.orderPrice = orderPrice;
   }

   public Timestamp getOrderDate()
   {
      return orderDate;
   }

   public void setOrderDate(Timestamp orderDate)
   {
      this.orderDate = orderDate;
   }

   public String getPurchaseOrder()
   {
      return purchaseOrder;
   }

   public void setPurchaseOrder(String purchaseOrder)
   {
      this.purchaseOrder = purchaseOrder;
   }

   public String getOrderStatus()
   {
      return orderStatus;
   }

   public void setOrderStatus(String orderStatus)
   {
      this.orderStatus = orderStatus;
   }

   @Override
   public String toString()
   {
      return "Order [orderId=" + orderId + ", orderType=" + orderType + ", orderQuantity=" + orderQuantity + ", orderPrice=" + orderPrice + ", orderDate=" + orderDate + ", purchaseOrder="
            + purchaseOrder + ", orderStatus=" + orderStatus + "]";
   }

}
