package com.sogetinl.cg.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "client")
public class Client implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -8260424354311764871L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ClientID")
	private Integer clientID;

	@Column(name = "Client_Name")
	private String clientName;

	@Column(name = "DB_Instance")
	private String dbInstance;

	@Column(name = "SFTP_Server")
	private String sftpServer;

	@Column(name = "ENABLED")
	private Boolean enabled;

	@Column(name = "APPLICATION_URL")
	private String applicationURL;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "client")
	private Set<User> userList = new HashSet<User>();

	/**
	 * @return the clientID
	 */
	public Integer getClientID() {
		return clientID;
	}

	/**
	 * @param clientID
	 *            the clientID to set
	 */
	public void setClientID(final Integer clientID) {
		this.clientID = clientID;
	}

	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}

	/**
	 * @param clientName
	 *            the clientName to set
	 */
	public void setClientName(final String clientName) {
		this.clientName = clientName;
	}

	/**
	 * @return the dbInstance
	 */
	public String getDbInstance() {
		return dbInstance;
	}

	/**
	 * @param dbInstance
	 *            the dbInstance to set
	 */
	public void setDbInstance(final String dbInstance) {
		this.dbInstance = dbInstance;
	}

	/**
	 * @return the sftpServer
	 */
	public String getSftpServer() {
		return sftpServer;
	}

	/**
	 * @param sftpServer
	 *            the sftpServer to set
	 */
	public void setSftpServer(final String sftpServer) {
		this.sftpServer = sftpServer;
	}

	/**
	 * @return the enabled
	 */
	public Boolean getEnabled() {
		return enabled;
	}

	/**
	 * @param enabled
	 *            the enabled to set
	 */
	public void setEnabled(final Boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 * @return the applicationURL
	 */
	public String getApplicationURL() {
		return applicationURL;
	}

	/**
	 * @param applicationURL
	 *            the applicationURL to set
	 */
	public void setApplicationURL(final String applicationURL) {
		this.applicationURL = applicationURL;
	}

	/**
	 * @return the userList
	 */
	public Set<User> getUserList() {
		return userList;
	}

	/**
	 * @param userList
	 *            the userList to set
	 */
	public void setUserList(final Set<User> userList) {
		this.userList = userList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Client [clientID=");
		builder.append(clientID);
		builder.append(", clientName=");
		builder.append(clientName);
		builder.append(", dbInstance=");
		builder.append(dbInstance);
		builder.append(", sftpServer=");
		builder.append(sftpServer);
		builder.append(", enabled=");
		builder.append(enabled);
		builder.append(", applicationURL=");
		builder.append(applicationURL);
		builder.append(", userList=");
		builder.append(userList);
		builder.append("]");
		return builder.toString();
	}

}
