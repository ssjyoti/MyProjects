package com.sogetinl.cg.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "user")
public class User implements Serializable
{

   private static final long serialVersionUID = -8260424725311764871L;

   /*
    * @GeneratedValue(strategy = GenerationType.AUTO)
    * @Column(name = "ID") private Integer id;
    */

   @Id
   @Column(name = "USERNAME")
   private String userName;

   @Column(name = "FIRST_NAME")
   private String firstName;

   @Column(name = "LAST_NAME")
   private String lastName;

   @Column(name = "EMAIL", unique = true)
   private String email;

   @Column(name = "PASSWORD")
   private String password;

   @Column(name = "IS_PASSWORD_RESET")
   private Boolean isPwdReset;

   @Column(name = "PWD_LAST_MODIFIED")
   private Timestamp pwdLastModifiedDate;

   @Column(name = "STATUS")
   private String status;

   @Column(name = "CONTACT_NUMBER")
   private String contactNumber;

   @Column(name = "ADDRESS")
   private String address;

   @Column(name = "COMMENT")
   private String comment;

   @Column(name = "is_Cg_User")
   private boolean isCgUser;

   @ManyToOne
   @JoinColumn(name = "ClientID")
   Client client;

   @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "user")
   private List<UserRole> userroles = new ArrayList<UserRole>();

   @Transient
   List<String> roles = new ArrayList<String>();

   public User()
   {
      super();
   }

   /**
    * @return the userName
    */
   public String getUserName()
   {
      return userName;
   }

   /**
    * @param userName the userName to set
    */
   public void setUserName(final String userName)
   {
      this.userName = userName;
   }

   /**
    * @return the firstName
    */
   public String getFirstName()
   {
      return firstName;
   }

   /**
    * @param firstName the firstName to set
    */
   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   /**
    * @return the lastName
    */
   public String getLastName()
   {
      return lastName;
   }

   /**
    * @param lastName the lastName to set
    */
   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   /**
    * @return the email
    */
   public String getEmail()
   {
      return email;
   }

   /**
    * @param email the email to set
    */
   public void setEmail(final String email)
   {
      this.email = email;
   }

   /**
    * @return the password
    */
   public String getPassword()
   {
      return password;
   }

   /**
    * @param password the password to set
    */
   public void setPassword(final String password)
   {
      this.password = password;
   }

   /**
    * @return the isPwdReset
    */
   public Boolean getIsPwdReset()
   {
      return isPwdReset;
   }

   /**
    * @param isPwdReset the isPwdReset to set
    */
   public void setIsPwdReset(final Boolean isPwdReset)
   {
      this.isPwdReset = isPwdReset;
   }

   /**
    * @return the status
    */
   public String getStatus()
   {
      return status;
   }

   /**
    * @param status the status to set
    */
   public void setStatus(final String status)
   {
      this.status = status;
   }

   public String getContactNumber()
   {
      return contactNumber;
   }

   public void setContactNumber(final String contactNumber)
   {
      this.contactNumber = contactNumber;
   }

   /**
    * @return the comment
    */
   public String getComment()
   {
      return comment;
   }

   /**
    * @param comment the comment to set
    */
   public void setComment(final String comment)
   {
      this.comment = comment;
   }

   /**
    * @return the pwdLastModifiedDate
    */
   public Timestamp getPwdLastModifiedDate()
   {
      return pwdLastModifiedDate;
   }

   /**
    * @param pwdLastModifiedDate the pwdLastModifiedDate to set
    */
   public void setPwdLastModifiedDate(final Timestamp pwdLastModifiedDate)
   {
      this.pwdLastModifiedDate = pwdLastModifiedDate;
   }

   /**
    * @return the client
    */
   public Client getClient()
   {
      return client;
   }

   /**
    * @param client the client to set
    */
   public void setClient(final Client client)
   {
      this.client = client;
   }

   /**
    * @return the userroles
    */
   public List<UserRole> getUserroles()
   {
      return userroles;
   }

   /**
    * @param userroles the userroles to set
    */
   public void setUserroles(final List<UserRole> userroles)
   {
      this.userroles = userroles;
   }

   /**
    * @return the roles
    */
   public List<String> getRoles()
   {
      return roles;
   }

   /**
    * @param roles the roles to set
    */
   public void setRoles(final List<String> roles)
   {
      this.roles = roles;
   }

   public String getAddress()
   {
      return address;
   }

   public void setAddress(final String address)
   {
      this.address = address;
   }

   @Override
   public String toString()
   {
      return "User [userName=" + userName + ", emailId=" + email + ", phone=" + contactNumber + ", client=" + "NA" + ", accessType=" + this.getRoles() + ", comments=" + comment + ", address="
            + "NA" + ", status=" + status + "]";// ", userroles="
      // +
      // userroles.toString()+
      // "]";
   }

   public boolean isCgUser()
   {
      return isCgUser;
   }

   public void setCgUser(boolean isCgUser)
   {
      this.isCgUser = isCgUser;
   }

}
