package com.sogetinl.cg.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product implements Serializable
{

   private static final long serialVersionUID = -8260424725311764871L;

   /*
    * @GeneratedValue(strategy = GenerationType.AUTO)
    * @Column(name = "ID") private Integer id;
    */

   @Id
   @Column(name = "PRODUCT_ID")
   private String productId;
   
   @Column(name = "PRODUCT_TYPE")
   private String productType;

   @Column(name = "QUANTITY")
   private String quantity;

   @Column(name = "PRICE")
   private String price;
   
   @Column(name = "STATUS")
   private String status;

   /*
    * @Column(name = "PET_ID") private String petId;
    * @Column(name = "SUPPLY_ID") private String supplyId;
    */

   @ManyToOne
   @JoinColumn(name = "PET_ID")
   Pet pet;

   @ManyToOne
   @JoinColumn(name = "SUPPLY_ID")
   Supply supply;

   public Product()
   {
      super();
   }

   public String getProductId()
   {
      return productId;
   }

   public void setProductId(String productId)
   {
      this.productId = productId;
   }

   public String getProductType()
   {
      return productType;
   }

   public void setProductType(String productType)
   {
      this.productType = productType;
   }

   public String getQuantity()
   {
      return quantity;
   }

   public void setQuantity(String quantity)
   {
      this.quantity = quantity;
   }

   public String getPrice()
   {
      return price;
   }

   public void setPrice(String price)
   {
      this.price = price;
   }

   public Pet getPet()
   {
      return pet;
   }

   public void setPet(Pet pet)
   {
      this.pet = pet;
   }

   public Supply getSupply()
   {
      return supply;
   }

   public void setSupply(Supply supply)
   {
      this.supply = supply;
   }
   
   public String getStatus()
   {
      return status;
   }

   public void setStatus(String status)
   {
      this.status = status;
   }

   @Override
   public String toString()
   {
      return "Product [productId=" + productId + ", quantity=" + quantity + ", price=" + price + "]";
   }

}
