package com.sogetinl.cg.common;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class RecommsConstants {
	// Organization Recommendations
	public static final Map<String, String> ORG_RECOMM_MAP = new HashMap<String, String>();

	public static final String ORG_EX_NO_HIRING_RESTRICTIONS = "<Critical>: Organization is job management but no hiring restrictions have been specified.";

	public static final String ORG_EX_NO_PRIMARY_LOCATION_REQD = "<Critical>: Primary Location is required for top level supervisory organizations.";

	public static final String ORG_EX_INVALID_ORGSUB_TYPE = "<Best Practice> : Organization Subtype is not valid for Organization Type.";

	public static final String ORG_EX_INVALID_ORG_ASSIGNMENTS = "<Best Practice> : Invalid Organization Assignments";

	public static final String ORG_EX_UNDEFINED_DEFAULT_ORG = "<Best Practice> : Undefined Default Organization Assignments";

	public static final String ORG_EX_UNASSIGNED_ROLE = "<Best Practice> : Unassigned Role Exception";

	public static final String ORG_EX_UNASSIGNED_MANAGER = "<Critical>: Unassigned Manager";

	// Absence Recommendations
	public static final Map<String, String> ABSENCE_RECOMM_MAP = new HashMap<String, String>();

	public static final String ABSENCE_EX_DESC_COMMENTS = "<Best Practice> : Time Off Plan with no Description/Comments";

	public static final String ABSENCE_EX_DAILY_DEFAULT = "<Best Practice> : Time Off Plan with Daily default not set";

	public static final String ABSENCE_EX_CALC_FALG = "<Critical>: Time Off Enter through Time Tracking Enabled with Time Calculation tag not set";

	public static final String ABSENCE_EX_ALLOW_OVERIDE = "<Best Practice> : Time Off with Allow Override for Entry on Behalf of Worker";

	public static final String ABSENCE_EX_CUSTOM_MESSAGE = "<Critical>: Time Off Entry Validation enabled with no custom message";

	// Compensation Recommendations

	public static final Map<String, String> COMPENSATION_RECOMM_MAP = new HashMap<String, String>();

	public static final String COMP_EX_COMP_PACKAGE = "<Best Practice> : Number of Compensation Packages Configured";

	public static final String COMP_EX_SALARY_PLAN = "<Best Practice> : Number of Salary Plans Configured";

	public static final String COMP_EX_UNASSIGNED_COMP_PLAN = "<Critical>: Compensation Plans not assigned to any Compensation packages";

	public static final String COMP_EX_COMP_PLAN_NO_RULE = "<Critical>: Compensation Plans with no Eligibility Rules assigned";

	public static final String COMP_EX_COMP_GRADE = "<Best Practice> : Compensation Grades Pay range configured at Grade level";

	// BP Framework Recommendations
	public static final Map<String, String> BP_RECOMM_MAP = new HashMap<String, String>();

	public static final Set<String> BP_STEP_TYPE_RECOMM_SET = new HashSet<String>();

	public static final Set<String> BP_STEP_TYPE_APPROVE_RECOMM_SET = new HashSet<String>();

	public static final String BP_EX_WO_EXCLUDE_INI = "<Best Practice> : Business Process without Exclude Initiators";

	public static final String BP_EX_WO_ALT_APPROVER = "<Best Practice> : Business Process without Alternate Approvers";

	public static final String BP_EX_WO_NOTIFICATIONS = "<Best Practice> : Business Process without Notifications";

	public static final String BP_EX_WO_SEC_GRP = "<Critical>: Business Process with empty Security group for Action,Approval,To Do and Review Step.";

	public static final String BP_EX_SEC_GRP_NOT_ALLOWED_APPROVAL = "<Critical>: Business Process with Security Group configured not allowed to perform Approval.";

	public static final String BP_EX_OVERIDE_DEFAULT_DEF = "<Best Practice> : Business Process definitions overriden  from default definitions.";

	// Staffing Recommendations
	public static final Map<String, String> STAFFING_RECOMM_MAP = new HashMap<String, String>();

	public static final String STAFFING_EX_HIRE_REASON = "<Best Practice> :Hire Reason to be selected.";

	public static final String STAFFING_EX_SAME_SSN = "<Critical>: Members Hired with same SSNs.";

	public static final String STAFFING_EX_HIRED_TWICE = "<Critical>: Worker Incorrectly Hired Twice.";

	public static final String STAFFING_EX_EMPTY_ORG = "<Best Practice> :Empty Supervisory Organizations.";

	public static final String STAFFING_EX_NO_JOB_RESTRICTIONS = "<Best Practice> :Position Management - No Job restrictions";

	public static final String STAFFING_EX_FTE_LESS_THAN_ONE = "<Best Practice> :Time Type is Full Time but the FTE is less than 1.";

	// Talent Recommendations
	public static final Map<String, String> TALENT_RECOMM_MAP = new HashMap<String, String>();

	public static final String TALENT_EX_CERT_ISSUE_DATE = "<Best Practice> :Employee Certification Issue Date not available in the system.";

	public static final String TALENT_EX_PROF_AFFL_DATETYPE = "<Best Practice> :Professional Affliation Begin date and Relationship Type not available in the system.";

	public static final String TALENT_EX_EXP_LEVEL = "<Best Practice> :Employee's Experience level  not available in the system.";

	public static final String TALENT_EX_POT_ASSMT = "<Best Practice> :Employee's Potential Assessment not available in the system.";

	public static final String TALENT_EX_ORG_GOALS = "<Critical>: Organizations with Org Goals not set in current Goal Period.";

	public static final String TALENT_EX_EMPTY_POOL = "<Critical>: Empty Talent Pools.";

	public static final String TAL_FLD_ORG = "orgName";

	public static final String TAL_FLD_TPOOL = "talentPool";

	public static final String TAL_FLD_PAFFL = "profAffiliation";

	public static final String TAL_FLD_ISSUE_DT = "issueDate";

	public static final String TAL_FLD_EXP_LEVEL = "experienceLevel";

	public static final String TAL_FLD_GOAL_PERIOD = "period";

	public static final String TAL_FLD_PAFFL_YEAR = "year";

	public static final String TAL_FLD_PAFFL_RTYPE = "relationType";

	public static final String TAL_FLD_TPOOL_STATUS = "poolStatus";

	public static final String TAL_FLD_POTENTIAL = "potential";

	// Critical Recommendations

	public static final Set<String> ORG_CRIT_RECOMMS = new HashSet<String>();

	public static final Set<String> STAFFING_CRIT_RECOMMS = new HashSet<String>();

	public static final Set<String> BP_CRIT_RECOMMS = new HashSet<String>();

	public static final Set<String> COMP_CRIT_RECOMMS = new HashSet<String>();

	public static final Set<String> ABSENCE_CRIT_RECOMMS = new HashSet<String>();

	public static final Set<String> TALENT_CRIT_RECOMMS = new HashSet<String>();

	public static final Set<String> SEC_CRIT_RECOMMS = new HashSet<String>();

	public static final String ORG_RECOMM_KEY = "Organization";

	public static final String STAFFING_RECOMM_KEY = "Staffing";

	public static final String BP_RECOMM_KEY = "BusinessProcess";

	public static final String COMP_RECOMM_KEY = "Compensation";

	public static final String ABSENCE_RECOMM_KEY = "Absence";

	public static final String TALENT_RECOMM_KEY = "Talent";

	public static final String SEC_RECOMM_KEY = "Security";
	
	public static final String INT_RECOMM_KEY = "Integration";
	

	public static final String EX_TYPE_BEST_PRACTICE = "<Best Practice> : ";

	public static final String EX_TYPE_CRITICAL = "<Critical>: ";

	static {

		// Organization Recommendation Map
		ORG_RECOMM_MAP.put(ORG_EX_NO_HIRING_RESTRICTIONS,
				"Hiring Restrictions need to be set.");
		ORG_RECOMM_MAP
				.put(ORG_EX_NO_PRIMARY_LOCATION_REQD,
						"Primary Location is required to be filled in the Top supervisory organizations.");
		ORG_RECOMM_MAP.put(ORG_EX_INVALID_ORGSUB_TYPE,
				"Organization Subtype should be Valid.");
		ORG_RECOMM_MAP.put(ORG_EX_INVALID_ORG_ASSIGNMENTS,
				"Invalid Organization Assignments.");
		ORG_RECOMM_MAP
				.put(ORG_EX_UNDEFINED_DEFAULT_ORG,
						"It is necessary to have all organization default organization assignments assigned.");
		ORG_RECOMM_MAP
				.put(ORG_EX_UNASSIGNED_ROLE,
						"It is necessary to have all organization roles assigned which are Mandatory.");
		ORG_RECOMM_MAP
				.put(ORG_EX_UNASSIGNED_MANAGER,
						"Manager is not assigned to the supervisory organization which is a mandatory as there are also part of approval process.");

		ORG_CRIT_RECOMMS.add(ORG_EX_NO_PRIMARY_LOCATION_REQD);
		ORG_CRIT_RECOMMS.add(ORG_EX_UNASSIGNED_MANAGER);
		ORG_CRIT_RECOMMS.add(ORG_EX_NO_HIRING_RESTRICTIONS);

		// Absence Recommendation Map
		ABSENCE_RECOMM_MAP.put(ABSENCE_EX_DESC_COMMENTS,
				"Add a valid Description/Comments for all Time Off Plans");
		ABSENCE_RECOMM_MAP.put(ABSENCE_EX_DAILY_DEFAULT,
				"Daily Default unit  to be set across all the Time Off Plans");
		ABSENCE_RECOMM_MAP
				.put(ABSENCE_EX_CALC_FALG,
						"Configure Time Calculation tag for Time Off Entry through Time Tracking");
		ABSENCE_RECOMM_MAP
				.put(ABSENCE_EX_ALLOW_OVERIDE,
						"Disable Allow Override for Entry on Behalf of Worker in Time Off Validation");
		ABSENCE_RECOMM_MAP
				.put(ABSENCE_EX_CUSTOM_MESSAGE,
						"Configure  custom messages for each of Time Off Entry Validation");

		ABSENCE_CRIT_RECOMMS.add(ABSENCE_EX_CALC_FALG);
		ABSENCE_CRIT_RECOMMS.add(ABSENCE_EX_CUSTOM_MESSAGE);

		// Compensation Recommendation Map
		COMPENSATION_RECOMM_MAP.put(COMP_EX_COMP_PACKAGE,
				"Configure one Compensation Package across the Organization");
		COMPENSATION_RECOMM_MAP.put(COMP_EX_SALARY_PLAN,
				"Configure one Salary Plan across the Organization");
		COMPENSATION_RECOMM_MAP
				.put(COMP_EX_UNASSIGNED_COMP_PLAN,
						"Assign Compensation Plans to appropriate Compensation Pacakages");
		COMPENSATION_RECOMM_MAP.put(COMP_EX_COMP_PLAN_NO_RULE,
				"Assign Eligibility Rules to Compensation Plans");
		COMPENSATION_RECOMM_MAP.put(COMP_EX_COMP_GRADE,
				"Move Pay rage configurations to Grade profile level");

		COMP_CRIT_RECOMMS.add(COMP_EX_UNASSIGNED_COMP_PLAN);
		COMP_CRIT_RECOMMS.add(COMP_EX_COMP_PLAN_NO_RULE);

		// BP Framework Recommendation Map
		BP_RECOMM_MAP
				.put(BP_EX_WO_EXCLUDE_INI,
						"As a best practise it is recommended to check Exclude Initiator while the Business Process is configured.To implement this change, go to Edit BP definition and add Exclude initiators.");
		BP_RECOMM_MAP
				.put(BP_EX_WO_ALT_APPROVER,
						"As a best practise it is recommended to include Alternate Approvers while the Business Process is configured.To implement this change, go to Edit BP definition and add alternate approvers.");
		BP_RECOMM_MAP
				.put(BP_EX_WO_NOTIFICATIONS,
						"As a best practise it is recommended to include Notifications while the Business Process is configured.To implement this change, go to Edit BP definition and add Notifications.");
		BP_RECOMM_MAP
				.put(BP_EX_WO_SEC_GRP,
						"Security Group should be configured for Action,Approval,To Do and Review Steps.");
		BP_RECOMM_MAP
				.put(BP_EX_SEC_GRP_NOT_ALLOWED_APPROVAL,
						"Security Group assigned to a Approval step should be valid to perform Approvals.");
		BP_RECOMM_MAP
				.put(BP_EX_OVERIDE_DEFAULT_DEF,
						"Default Definintion can be overriden, if workflow logic sufficiently differs from the default definition.");

		BP_CRIT_RECOMMS.add(BP_EX_WO_SEC_GRP);
		BP_CRIT_RECOMMS.add(BP_EX_SEC_GRP_NOT_ALLOWED_APPROVAL);

		// Staffing Recommendation Map
		STAFFING_RECOMM_MAP.put(STAFFING_EX_HIRE_REASON,
				"It is recommended to include the Hire Reason.");
		STAFFING_RECOMM_MAP.put(STAFFING_EX_SAME_SSN,
				"It is recommended to edit the SSN to remove duplicates.");
		STAFFING_RECOMM_MAP.put(STAFFING_EX_HIRED_TWICE,
				"It is recommended to terminate one of the hires.");
		STAFFING_RECOMM_MAP
				.put(STAFFING_EX_EMPTY_ORG,
						"It is recommended to Inactivate Supervisory Organization with no members staffed in it(Can be done for the Lowest level Supervisory Org) and can be activated later on need basis.");
		STAFFING_RECOMM_MAP
				.put(STAFFING_EX_NO_JOB_RESTRICTIONS,
						"It is recommended to include hiring restrictions for a Position in a Position Management.");

		STAFFING_RECOMM_MAP.put(STAFFING_EX_FTE_LESS_THAN_ONE,
				"It is recommended to set FTE as 1 for Full Time employees.");

		STAFFING_CRIT_RECOMMS.add(STAFFING_EX_SAME_SSN);
		STAFFING_CRIT_RECOMMS.add(STAFFING_EX_HIRED_TWICE);

		BP_STEP_TYPE_RECOMM_SET.add("Action");
		BP_STEP_TYPE_RECOMM_SET.add("Approval");
		BP_STEP_TYPE_RECOMM_SET.add("Approval Chain");
		BP_STEP_TYPE_RECOMM_SET.add("Consolidated Approval");
		BP_STEP_TYPE_RECOMM_SET.add("Consolidated Approval Chain");
		BP_STEP_TYPE_RECOMM_SET.add("Mass Approval");
		BP_STEP_TYPE_RECOMM_SET.add("Review Documents");
		BP_STEP_TYPE_RECOMM_SET.add("To Do");

		BP_STEP_TYPE_APPROVE_RECOMM_SET.add("Approval");
		BP_STEP_TYPE_APPROVE_RECOMM_SET.add("Approval Chain");

		// Talent Recommendation Map
		TALENT_RECOMM_MAP
				.put(TALENT_EX_CERT_ISSUE_DATE,
						"Employee Certification Issue date should be entered in the system.");
		TALENT_RECOMM_MAP
				.put(TALENT_EX_PROF_AFFL_DATETYPE,
						"Professional Affliation Begin Date and Relation Type should have valid values respectively .");
		TALENT_RECOMM_MAP.put(TALENT_EX_EXP_LEVEL,
				"Employee's Experience Level should be entered in the system.");
		TALENT_RECOMM_MAP
				.put(TALENT_EX_POT_ASSMT,
						"Potential should be assessed for employee's in the organization.");
		TALENT_RECOMM_MAP.put(TALENT_EX_ORG_GOALS,
				"Oraganization Goal should be set for Current Goal Period.");
		TALENT_RECOMM_MAP.put(TALENT_EX_EMPTY_POOL,
				"Talent Pool pool member count should be atleast one.");

		TALENT_CRIT_RECOMMS.add(TALENT_EX_EMPTY_POOL);
		TALENT_CRIT_RECOMMS.add(TALENT_EX_ORG_GOALS);

		SEC_CRIT_RECOMMS.add("Pending changes to policies.");
		SEC_CRIT_RECOMMS
				.add("domain policies where in required access is only view. However, we have given modify access.");

	}

}
