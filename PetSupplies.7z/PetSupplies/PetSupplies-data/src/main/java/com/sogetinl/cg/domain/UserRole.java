package com.sogetinl.cg.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * Entity implementation class for Entity: UserRole
 */
@Entity
@Table(name = "user_role")
public class UserRole implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6972701062586482149L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Integer id;

	// @Column(name = "USERNAME")
	@Transient
	private String userName;

	// @Column(name = "ROLE_NAME")
	@Transient
	private String roleName;

	@ManyToOne
	@JoinColumn(name = "USERNAME")
	User user;

	@ManyToOne
	@JoinColumn(name = "ROLE_NAME")
	Role role;

	// private List<User> roles = new ArrayList<User>();

	public Integer getId() {
		return this.id;
	}

	public void setId(final Integer id) {
		this.id = id;
	}

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(final String roleName) {
		this.roleName = roleName;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(final String userName) {
		this.userName = userName;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(final User user) {
		this.user = user;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("UserRole [id=");
		builder.append(id);
		builder.append(", userName=");
		builder.append(userName);
		builder.append(", roleName=");
		builder.append(roleName);
		builder.append(", User=");
		builder.append(user);
		builder.append(", role=");
		builder.append(role);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the role
	 */
	public Role getRole() {
		return role;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(final Role role) {
		this.role = role;
	}

}
