
 package com.sogetinl.cg.dao.cart;

import com.sogetinl.cg.common.PetSuppliesException;
import java.util.List;

import com.sogetinl.cg.domain.Cart;
import com.sogetinl.cg.domain.Orders;

public interface ShoppingCartDAO
{
   public List<Cart> findAll() throws PetSuppliesException;

   public void updateCart(Cart cart) throws PetSuppliesException;
   
   public void placeOrder(Orders orders,String cartId) throws PetSuppliesException;
   
   public void removeCart(String cartId) throws PetSuppliesException;
   
}

