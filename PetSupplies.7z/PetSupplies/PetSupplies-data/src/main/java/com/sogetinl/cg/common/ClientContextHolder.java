package com.sogetinl.cg.common;

import org.apache.log4j.Logger;

public class ClientContextHolder {
	private final static Logger LOG = Logger
			.getLogger(ClientContextHolder.class);

	private static final ThreadLocal<ClientName> contextHolder = new ThreadLocal<ClientName>();

	public static void setClientName(final ClientName clientName) {
		LOG.info("IN ClientContextHolder :: setting " + clientName);
		contextHolder.set(clientName);
	}

	public static ClientName getClientName() {
		LOG.info("IN ClientContextHolder :: getting " + contextHolder.get());
		return contextHolder.get();
	}

	public static void clearClientName() {
		LOG.info("IN ClientContextHolder :: clearing " + contextHolder.get());
		contextHolder.remove();
	}
}
