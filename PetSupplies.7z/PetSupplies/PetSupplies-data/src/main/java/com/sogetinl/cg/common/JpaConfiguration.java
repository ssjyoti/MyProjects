package com.sogetinl.cg.common;

import java.util.HashMap;
import java.util.Map;

//import org.hibernate.cache.HashtableCacheProvider;
import org.hibernate.dialect.MySQLDialect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Component
public class JpaConfiguration {

	@Value("#{dataSource}")
	private javax.sql.DataSource dataSource;

	@Bean
	public Map<String, Object> jpaProperties() {
		final Map<String, Object> props = new HashMap<String, Object>();
		// props.put("hibernate.dialect", H2Dialect.class.getName());
		props.put("hibernate.dialect", MySQLDialect.class.getName());
		// props.put("hibernate.cache.provider_class",
		// HashtableCacheProvider.class.getName());
		props.put("hibernate.show_sql", true);
		return props;
	}

	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {
		final HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setShowSql(false);
		hibernateJpaVendorAdapter.setGenerateDdl(false);
		// hibernateJpaVendorAdapter.setDatabase(Database.H2);
		hibernateJpaVendorAdapter.setDatabase(Database.MYSQL);
		return hibernateJpaVendorAdapter;
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean() {
		final LocalContainerEntityManagerFactoryBean lef = new LocalContainerEntityManagerFactoryBean();
		lef.setDataSource(this.dataSource);
		lef.setJpaPropertyMap(this.jpaProperties());
		lef.setJpaVendorAdapter(this.jpaVendorAdapter());
		lef.setPersistenceUnitName("PetSuppliesUnit");
		// lef.setPackagesToScan("com.sogetinl.cg.domain");
		return lef;
	}

	@Bean
	public PlatformTransactionManager transactionManager() {
		return new JpaTransactionManager(
				localContainerEntityManagerFactoryBean().getObject());
	}

}
