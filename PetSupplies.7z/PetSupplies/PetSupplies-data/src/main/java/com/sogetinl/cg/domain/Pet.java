package com.sogetinl.cg.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "pet")
public class Pet implements Serializable
{

   /**
    *
    */
   private static final long serialVersionUID = -8260424354311764871L;

   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   @Column(name = "PET_ID")
   private Integer petId;

   @Column(name = "PET_TYPE")
   private String petType;

   @Column(name = "BREED")
   private String breed;
   
   @Column(name = "ABOUT")
   private String about;
   

   @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "pet")
   private Set<Product> productList = new HashSet<Product>();

   /**
    * @return the petId
    */
   public Integer getPetId()
   {
      return petId;
   }

   /**
    * @param petId the petId to set
    */
   public void setPetId(final Integer petId)
   {
      this.petId = petId;
   }

   /**
    * @return the petType
    */
   public String getPetType()
   {
      return petType;
   }

   /**
    * @param petType the petType to set
    */
   public void setPetType(final String petType)
   {
      this.petType = petType;
   }

   /**
    * @return the breed
    */
   public String getBreed()
   {
      return breed;
   }

   /**
    * @param breed the breed to set
    */
   public void setBreed(final String breed)
   {
      this.breed = breed;
   }

   /**
    * @return the proudctList
    */
   public Set<Product> getProductList()
   {
      return productList;
   }

   /**
    * @param productList the productList to set
    */
   public void setProductList(final Set<Product> productList)
   {
      this.productList = productList;
   }
   
   /**
    *@return the about
    */
   public String getAbout()
   {
      return about;
   }

   /**
    * @param about the about to set
    */
   public void setAbout(String about)
   {
      this.about = about;
   }

   @Override
   public String toString()
   {
      StringBuilder builder = new StringBuilder();
      builder.append("Pet [petId=");
      builder.append(petId);
      builder.append(", petType=");
      builder.append(petType);
      builder.append(", breed=");
      builder.append(breed);
      builder.append(", about=");
      builder.append(about);
      builder.append(", productList=");
      builder.append(productList);
      builder.append("]");
      return builder.toString();
   }

}
