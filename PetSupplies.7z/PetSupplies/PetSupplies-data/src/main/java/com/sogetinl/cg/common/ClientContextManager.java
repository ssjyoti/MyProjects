package com.sogetinl.cg.common;

import org.apache.log4j.Logger;

public class ClientContextManager
{
   private final static Logger LOG = Logger.getLogger(ClientContextManager.class);

   public static void setContextHolder(final String cName)
   {
      ClientContextHolder.clearClientName();
      LOG.info("ClientContextManager:: " + cName);
      ClientName clientName = null;
      if (ClientName.US.getValue().equalsIgnoreCase(cName))
      {
         LOG.info("ClientContextManager:: INSIDE");
         clientName = ClientName.US;
      }
      else if (ClientName.ASIAPAC.getValue().equalsIgnoreCase(cName))
      {
         clientName = ClientName.ASIAPAC;
      }
      else if (ClientName.ANZ.getValue().equalsIgnoreCase(cName))
      {
         clientName = ClientName.ANZ;
      }
      else if (ClientName.UK.getValue().equalsIgnoreCase(cName))
      {
         clientName = ClientName.UK;
      }
      else if (ClientName.SA.getValue().equalsIgnoreCase(cName))
      {
         clientName = ClientName.SA;
      }
      else
      {
         clientName = ClientName.PetSupplies;
      }
      // if (clientName != null) {
      LOG.info("ClientContextManager:: INSIDE clientName=" + clientName);
      ClientContextHolder.setClientName(clientName);
      // }
   }

}
