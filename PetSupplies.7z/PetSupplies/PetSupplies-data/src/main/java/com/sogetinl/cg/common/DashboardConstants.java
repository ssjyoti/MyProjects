package com.sogetinl.cg.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class DashboardConstants {
	// Dashboard Sections
	public static final String DBSECTION_INTEGRATION = "integrationSection";

	public static final String DBSECTION_ORGANIZATION = "orgnizationSection";

	public static final String DBSECTION_SECURITY = "securitySection";

	public static final String DBSECTION_ACCESS = "accessSection";

	public static final String DBSECTION_COMPENSATION = "compensationSection";

	public static final String DBSECTION_ABSENCE = "absenceSection";

	public static final String DBSECTION_TALENT = "talentSection";

	// Integrations

	public static final String INTEGRATION_TYPE_DOMAIN = "IntegrationTypes";

	public static final String INTEGRATION_TYPE_COL_SYSTEM = "integrationRefId";

	public static final String INTEGRATION_TYPE_COL_TEMPLATE = "integrationTemplate";

	public static final String INTEGRATION_TYPE_CUSTOM = "custom";

	public static final String INTEGRATION_TYPE_CORE_CONNECTORS = "coreConnectors";

	public static final String INTEGRATION_TYPE_EIB = "EIB";

	public static final String INTEGRATION_TYPE_TOTAL = "integrations";

	// Organization

	public static final String SUPERORG_KEY_SUPER_ORGS = "supervisoryOrgs";

	public static final String ALL_POSITIONS_KEY_POSITIONS = "openPositions";

	public static final String COUNTRYWISE_STAFFING_DOMAIN = "CountrywiseStaffingCount";

	public static final String COUNTRYWISE_STAFFING_COL_COUNTRY = "locationAddressCountry";

	public static final String COUNTRYWISE_STAFFING_KEY_COUNTRIES = "country";

	public static final String COUNTRYWISE_STAFFING_KEY_WORKERS = "workers";

	public static final String POSITIONS_MGMT_DOMAIN = "SuperOrgPositionMgmt";

	public static final String POSITIONS_MGMT_COL_ORG_NM = "supervisoryOrgReferenceId";

	public static final String POSITIONS_MGMT_COL_STATUS = "status";

	public static final String POSITIONS_MGMT_COL_ECOUNT = "employeeCount";

	public static final String POSITIONS_MGMT_COL_CWCOUNT = "contingentWorkerCount";

	public static final String POSITIONS_MGMT_COL_OPCOUNT = "openPositionCount";

	public static final Set<String> SUM_CALC_FIELDS = new TreeSet<String>();

	public static final Set<String> BOOLEAN_PARAM_FIELDS = new TreeSet<String>();

		
	// AccessManagement

	public static final String ACCESS_MGMT_KEY_WORKERS = "workers";

	public static final String ACCESS_MGMT_KEY_IMPLEMENTORS = "implementers";

	public static final String ACCESS_MGMT_KEY_OTHERS = "others";

	public static final String ACCESS_MGMT_KEY_TOTAL_ACCESS_GRANTED = "accessGranted";

	public static final String ACCESS_MGMT_COL_WORKERS = "workerName";

	public static final String ACCESS_MGMT_COL_IMPLTERS = "isImplementer";

	public static final String ACCESS_MGMT_COL_INTUSRS = "isIntegrationUser";

	public static final String ACCESS_MGMT_COL_DEVELPOERS = "isDeveloper";

	public static final String ACCESS_MGMT_COL_ACTIVE_STATUS = "isAccountActive";

	public static final String ACCESS_MGMT_COL_SGADMINS = "isSecurityGroupAdministrator";

	// Security Groups

	public static final String SEC_GROUP_DOMAIN = "SecurityGroupOrg";

	public static final String SEC_GROUP_COL_SEC_GROUP = "securityGroup";

	public static final String SEC_GROUP_COL_TYPE = "type";

	public static final String SEC_GROUP_KEY_ROLE_BASED = "roleBased";

	public static final String SEC_GROUP_KEY_USER_BASED = "usedBased";

	public static final String SEC_GROUP_ROLE_BASED = "Role-Based Security Group (Constrained)";

	public static final String SEC_GROUP_USER_BASED = "User-Based Security Group";

	public static final String SEC_GROUP_KEY_OTHERS = "others";

	public static final String SEC_GROUP_KEY_TOTAL = "securityGroups";

	public static final List<String> SEC_ESSMSS_LIST = new ArrayList<String>();

	// Talent

	public static final String TALENT_SUCC_PLAN_DOMAIN = "SuccessionPlan";

	public static final String TALENT_SUCC_PLAN_COL_SP = "successionPlanJobProfile";

	public static final String TALENT_SUCC_PLAN_KEY_SP = "successionPlans";

	public static final String TALENT_ORG_GOALS_DOMAIN = "OrgGoals";

	public static final String TALENT_ORG_GOALS_COL_ORG_NAME = "orgName";

	public static final String TALENT_ORG_GOALS_KEY = "orgHasGoals";

	public static final String TALENT_TALENT_POOL_DOMAIN = "TalentPoolMain";

	public static final String TALENT_TALENT_POOL_COL_TPOOL = "talentPool";

	public static final String TALENT_TALENT_POOL_KEY = "talentPool";

	static {
		SEC_ESSMSS_LIST.add(CommonConstants.ESS_TEXT);
		SEC_ESSMSS_LIST.add(CommonConstants.MSS_TEXT);

		SUM_CALC_FIELDS.add(POSITIONS_MGMT_COL_OPCOUNT);
		SUM_CALC_FIELDS.add(POSITIONS_MGMT_COL_CWCOUNT);
		SUM_CALC_FIELDS.add(POSITIONS_MGMT_COL_ECOUNT);

		BOOLEAN_PARAM_FIELDS.add(POSITIONS_MGMT_COL_STATUS);
		BOOLEAN_PARAM_FIELDS.add(ACCESS_MGMT_COL_ACTIVE_STATUS);
	}

}
