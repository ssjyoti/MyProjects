
 package com.sogetinl.cg.dao.product;

import com.sogetinl.cg.common.PetSuppliesException;
import java.util.List;
import com.sogetinl.cg.domain.Product;

public interface ProductDAO
{
   public List<Product> findAll() throws PetSuppliesException;

   public List<Product> findBySearchCriteria(String criteriaString) throws PetSuppliesException;
   
   public void updateProduct(final Product product) throws PetSuppliesException;
}

