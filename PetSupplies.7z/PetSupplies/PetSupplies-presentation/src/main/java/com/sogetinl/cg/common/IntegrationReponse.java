package com.sogetinl.cg.common;

import com.sogetinl.cg.vo.integration.IntegrationCRUDVO;

public class IntegrationReponse {

	private String status = CommonConstants.EMPTY_STRING;

	private String message = CommonConstants.EMPTY_STRING;

	private IntegrationCRUDVO vendorDetails;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public IntegrationCRUDVO getVendorDetails() {
		return vendorDetails;
	}

	public void setVendorDetails(IntegrationCRUDVO vendorDetails) {
		this.vendorDetails = vendorDetails;
	}

}
