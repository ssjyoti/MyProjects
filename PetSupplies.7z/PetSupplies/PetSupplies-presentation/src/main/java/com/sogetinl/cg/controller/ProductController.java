package com.sogetinl.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.sogetinl.cg.common.ClientContextManager;
import com.sogetinl.cg.common.CommonConstants;
import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.PetSuppliesReponse;
import com.sogetinl.cg.service.product.ProductService;
import com.sogetinl.cg.vo.petVO.ProductVO;

/**
 * jyotiranjan.paik
 */
@Controller
public class ProductController
{
   private final static Logger LOG = Logger.getLogger(ProductController.class);

   @Autowired
   private ProductService productService;

   @RequestMapping(value = "/getProductSearchResultsData", method = RequestMethod.GET, headers = { "Content-type=application/json" })
   public @ResponseBody List<ProductVO> getProductSearchData(final HttpServletRequest request, final HttpServletResponse response)
   {
      LOG.info("ENTER>> ProductSearchController::getProductSearchData  - ");

      if (request.getSession().getAttribute(CommonConstants.CLIENT_DB_REF) != null)
      {
         ClientContextManager.setContextHolder((String) request.getSession().getAttribute(CommonConstants.CLIENT_DB_REF));
      }
      List<ProductVO> searchList = null;
      try
      {
         searchList = productService.getProductSearchData();
      }
      catch (final PetSuppliesException e)
      {
         LOG.error("ProductSearchController  :: getProductSearchData>> Exceptions occurred>> " + e);
      }

      LOG.info("EXIT>> ProductSearchController::getProductSearchData");
      
      final Gson json = new Gson();
      LOG.info("ProductSearchController  :: getProductSearchData>> JSON >> Response=" + json.toJson(searchList));
     
      return searchList;

   }
   
   @RequestMapping(value = "/updateProduct", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse updateProduct(
         @RequestBody final ProductVO productVO, final HttpServletRequest request) {
      LOG.info("ENTER>> ProductController::updateProduct  - ");
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      try {
         productService.updateProduct(productVO);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ProductController::updateProduct  - "+ e.getMessage());
         new PetSuppliesReponse("Failure", "Error occurred while updating Product",
               productVO.getBreedOrItem(), productVO.getPetOrSupplyType(), null, null);
      }
      List<ProductVO> productVOList = null;
      try {
         productVOList = productService.getProductSearchData();
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ProductController::getProductSearchData  - "
               + e.getMessage());
         new PetSuppliesReponse("Failure",
               "Product updated, but failed to fetch the Productr list",
               productVO.getBreedOrItem(), productVO.getPetOrSupplyType(), null, null);
      }
      LOG.info("Exit>> ProductController::updateProduct  - returning>"
            + productVOList);
     
      return new PetSuppliesReponse("Success", "Product updated successfully",
            productVO.getBreedOrItem(), productVO.getPetOrSupplyType(), null, null);
   }

}
