package com.sogetinl.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.sogetinl.cg.common.ClientContextManager;
import com.sogetinl.cg.common.CommonConstants;
import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.PetSuppliesReponse;
import com.sogetinl.cg.service.order.OrderManagementService;
import com.sogetinl.cg.vo.petVO.OrderVO;

/**
 * jyotiranjan.paik
 */
@Controller
public class OrderManagementController
{
   private final static Logger LOG = Logger.getLogger(OrderManagementController.class);

   @Autowired
   private OrderManagementService orderManagementService;
   
   @RequestMapping(value = "/getOrderHistoryResultsData", method = RequestMethod.GET, headers = { "Content-type=application/json" })
   public @ResponseBody List<OrderVO> getOrderHistoryResultsData(final HttpServletRequest request, final HttpServletResponse response)
   {
      LOG.info("ENTER>> OrderManagementController::getOrderHistoryResultsData  - ");

      if (request.getSession().getAttribute(CommonConstants.CLIENT_DB_REF) != null)
      {
         ClientContextManager.setContextHolder((String) request.getSession().getAttribute(CommonConstants.CLIENT_DB_REF));
      }
      List<OrderVO> searchList = null;
      try
      {
         searchList = orderManagementService.getOrderData();
      }
      catch (final PetSuppliesException e)
      {
         LOG.error("OrderManagementController  :: getOrderHistoryResultsData>> Exceptions occurred>> " + e);
      }

      LOG.info("EXIT>> OrderManagementController::getOrderHistoryResultsData");
      
      final Gson json = new Gson();
      LOG.info("OrderManagementController  :: getOrderHistoryResultsData>> JSON >> Response=" + json.toJson(searchList));
     
      return searchList;

   }
   
   @RequestMapping(value = "/updateOrder", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse updateOrder(
         @RequestBody final OrderVO orderVO, final HttpServletRequest request) {
      LOG.info("ENTER>> ProductController::updateOrder  - ");
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      try {
         orderManagementService.updateOrder(orderVO);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ProductController::updateOrder  - "+ e.getMessage());
         new PetSuppliesReponse("Failure", "Error occurred while updating Order",
               orderVO.getOrderId(), orderVO.getOrderType(), null, null);
      }
      List<OrderVO> orderVOList = null;
      try {
         orderVOList = orderManagementService.getOrderData();
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ProductController::updateOrder  - "
               + e.getMessage());
         new PetSuppliesReponse("Failure",
               "Product updated, but failed to fetch the Productr list",
               orderVO.getOrderId(), orderVO.getOrderType(), null, null);
      }
      LOG.info("Exit>> ProductController::updateOrder  - returning>"
            + orderVOList);
     
      return new PetSuppliesReponse("Success", "Order updated successfully",
            orderVO.getOrderId(), orderVO.getOrderType(), null, null);
   }
   
 }
