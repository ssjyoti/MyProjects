define([ 'angular' ], function(angular) {
	'use strict';

	/**
	 * @ngdoc function
	 * @name petSuppliesApp.controller:AboutCtrl
	 * @description # AboutCtrl Controller of the petSuppliesApp
	 */
	angular.module('petSuppliesApp.Service.DataServices', []).controller(
			'dataserviceCtrl', function($scope, $rootScope) {
				$rootScope.loadingPage = false;
			}).service(
			'DataServices',
			function($rootScope, $q) {
				var url = "", methodType = "GET", dataType = "{}";
				this.getData = function(callType, paramVal) {

					var deferred = $q.defer();

					if (callType == "Pet_Search_Results") {
						methodType = "GET";
						url = contextPath + "/getProductSearchResultsData"; // "SecurityGroups2.json";
					} else if (callType == "Security_Tree_Chart") {
						methodType = "POST";
						dataType = JSON.stringify(paramVal);
						url = contextPath + "/getSecurityStructure"; // "Security.json?secGrpList="+paramVal;
					} else if (callType == "Security_Group_Type") {
						methodType = "GET";
						url = contextPath + "/getSecurityGroupTypes"; // "SecurityGroupTypes.json";
					} else if (callType == "userDetails") {
						methodType = "GET"
						url = contextPath + "/getUserListForAdmin";
					} else if (callType == "userUpdate") {
						methodType = "POST"
							dataType = JSON.stringify(paramVal);
							url = contextPath + "/updateUser";
					}else if (callType == "passwordChange") {
						methodType = "POST"
							dataType = JSON.stringify(paramVal);
							url = contextPath + "/changePassword";
					} else if (callType == "productUpdate") {
						methodType = "POST"
							dataType = JSON.stringify(paramVal);
							url = contextPath + "/updateProduct";
					} else if (callType == "Order_History_Results") {
						methodType = "GET";
						url = contextPath + "/getOrderHistoryResultsData"; // "SecurityGroups2.json";
					}  else if (callType == "orderUpdate") {
						methodType = "POST"
							dataType = JSON.stringify(paramVal);
							url = contextPath + "/updateOrder";
					} else if (callType == "Shopping_Cart_Data") {
						methodType = "GET";
						url = contextPath + "/getShoppingCartData"; // "SecurityGroups2.json";
					} else if (callType == "shoppingCartUpdate") {
						methodType = "POST"
							dataType = JSON.stringify(paramVal);
							url = contextPath + "/updateShoppingCart";
					} else if (callType == "place_Order") {
						methodType = "POST"
							dataType = JSON.stringify(paramVal);
							url = contextPath + "/placeOrder";
					}

				$.ajax({
                type: methodType,
                contentType: "application/json; charset=utf-8",
                url: url,
              //url:contextPath+"/getSecurityStructure
                dataType: 'json',
                async: true,
                data: dataType, 
                beforeSend: function() {
                   $rootScope.loadingPage = true;                  
                   /* $('#pageLoadModal').modal({
                        backdrop: 'static'
                    });*/
               $('#pageLoadModal').modal('show'); 
                  },
                  complete: function() {
                     $rootScope.loadingPage = false;
                     $('#pageLoadModal').modal('hide'); 
                  },
                success: function (data) {
                    deferred.resolve(data);
                },
                error: function (result) {
                    deferred.reject('ERROR');
                }
           });
            return deferred.promise;
        };

	});
});
