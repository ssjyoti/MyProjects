define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller:MainCtrl
   * @description
   * # MainCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.MainCtrl', [])
    .controller('MainCtrl', function ($scope,$rootScope) {
      $rootScope.moduleHeaderName = "Welcome to Pet Supplies Application";
       $scope.currentUser = sessionStorage.getItem("firstName");
       $scope.clientName = sessionStorage.getItem("clientId");
	    $scope.currentUserId = sessionStorage.getItem("username");
	    $scope.roleName = sessionStorage.getItem("roleId");
        $rootScope.pageWidth = screen.availWidth-215;
    
        $rootScope.pageHeight = screen.availHeight;
        
    //  $scope.reloadPage = function(){$window.location.href = "#staffing";}
    })
   .directive('mainTabs', function($window,$rootScope,DataServices) {
            return {
                
                restrict: 'A',                
                link: function(scope,rootscope, elm, attrs) {
                    var jqueryElm = $(elm[0]);
                    $(jqueryElm).tabs();
                   
                   var service = DataServices.getData("Dashboard","");
                            service.then(function(data){
                            	
                            }, function(reject){
                            });
                 
                    
                  
                  
                }
            }
  });
});
