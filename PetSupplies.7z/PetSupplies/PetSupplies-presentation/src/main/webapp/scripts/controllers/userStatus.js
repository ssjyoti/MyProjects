define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller:AboutCtrl
   * @description
   * # AboutCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.UserStatusCtrl', [])
    .controller('UserStatusCtrl', function ($scope,$rootScope) {
      $rootScope.moduleHeaderName = "User Status";
     
    })
  .directive('userstatusTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                     var service,dataCount,dataObj,counter;
                     service = DataServices.getData("userDetails","");
                            service.then(function(data){
                            dataCount = data.length;
                            counter=1;
                                scope.clientList = [];
                                scope.accessList = [];
                                scope.userDetails = [];
                                  if(data !=undefined){
                                        for(var i=0; i<dataCount; i++) {
                                        dataObj = {
                                            srNo :counter++,
                                            userName : data[i].userName,
                                            firstName :data[i].firstName,
                                            lastName :data[i].lastName,
                                            email :data[i].email,
                                            address :data[i].address,
                                            contactNumber :data[i].contactNumber,
                                            clientId : data[i].clientId,
                                            clientName :data[i].clientName,
                                            accessType :data[i].accessType,
                                            status :data[i].status,
                                            comment :data[i].comment,
                                            userroles :data[i].userroles
                                        }
                                        if(scope.clientList.indexOf(data[i].clientName) == -1){
                                            scope.clientList.push(data[i].clientName);
                                        }
                                        if(scope.accessList.indexOf(data[i].accessType) == -1){
                                            scope.accessList.push(data[i].accessType);
                                        }
                                       // scope.$apply();
                                        scope.userDetails.push(dataObj);
                                    }
                                      
                                    }
                                    
                                    
                                }, function(reject){
                            });
                    
                     scope.startIndex=0;
                     scope.endIndex=10;
                      scope.nextData = function(){
                            scope.startIndex = scope.startIndex+10;
                          if(scope.endIndex <=scope.userDetails.length)
                            scope.endIndex = scope.endIndex+10;

                       }
                        scope.previousData = function(){

                           scope.startIndex = scope.startIndex-10;
                           scope.endIndex = scope.endIndex-10;
                       }
                        
                        scope.getUserDetaila = function(selectedObj){
                             scope.userObjct = {
                                userName:selectedObj.userName,
                                firstName:selectedObj.firstName,
                                lastName:selectedObj.lastName,
                                contactNumber:selectedObj.contactNumber,
								email:selectedObj.email,
                                clientName:selectedObj.clientName,
								clientId:selectedObj.clientId,
                                address:selectedObj.address,
                                accessType:selectedObj.accessType,
                                status:selectedObj.status,
                                comment:selectedObj.comment
                            
                        };
                            scope.$apply();
                            $("#userDetailsModal").modal("show");
                        }
                       $("#updateUserDetailsForm").submit(function(event){
                            var formData = {
                                    userName:$("#userId").val(),
                                    firstName:$("#firstName").val(),
                                    lastName:$("#lastName").val(),
                                    contactNumber:$("#contactNumber").val(),
									email:$("#email").val(),
                                    clientName:$("#clientName").val(),
									clientId:$("#clientId").val(),
                                    address:$("#address").val(),
							        accessType:$("#accessType").val(),
							        status:$('#status :selected').val(),
                                    comment:$("#commentsID").val()
                            };
                            service = DataServices.getData("userUpdate",formData);
                            service.then(function(data){
                                
                                    scope.addRecordStatus = data.status;
                                    scope.statusMessage = data.message;
                                scope.userDetails = [];
								counter = 1;
								var userList = data["userList"];
                                  if(data !=undefined){
                                        for(var i=0; i<userList.length; i++) {
                                        dataObj = {
                                            srNo :counter++,
                                            userName : userList[i].userName,
                                            firstName :userList[i].firstName,
                                            lastName :userList[i].lastName,
                                            email :userList[i].email,
                                            address :userList[i].address,
                                            contactNumber :userList[i].contactNumber,
                                            clientId : userList[i].clientId,
                                            clientName :userList[i].clientName,
                                            accessType :userList[i].accessType,
                                            status :userList[i].status,
                                            comment :userList[i].comment,
                                            userroles :userList[i].userroles
                                        }
                                        scope.userDetails.push(dataObj);
                                    }
									scope.$apply();
                                    }
                                        
                                 $("#userDetailsModal").modal("hide");
                                 $("#statusMessageModal").modal("show");
                                      
                                  
							  }, function(reject){
                            });
                            
                        });
                }
                }
  })
    .filter('slice', function() {
            return function(arr, start, end) {
            if (!arr || !arr.length) { return; }
            return arr.slice(start, end);
            };
        })
});
