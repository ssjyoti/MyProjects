define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller.OrderManagementCtrl
   * @description
   * # OrderManagementCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.OrderManagementCtrl', [])
    .controller('OrderManagementCtrl', function ($scope,$rootScope) {
      $rootScope.moduleHeaderName = "Order History";
      $scope.cart = [];
    })
  .directive('ordermanagementTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                     var service,dataCount,dataObj,counter;
                     service = DataServices.getData("Order_History_Results","");
                            service.then(function(data){
                            dataCount = data.length;
                                counter=1;
                                scope.orderTypes = [];
                                scope.orderStatusList = []
                                scope.orderList = [];
									if(data !=undefined){
                                        for(var i=0; i<dataCount; i++) {
											if (data[i].exceptionType != "<Best Practice> : Invalid Product Assignments") {
												var dataObj = {
														srNo : counter++,
														exceptionType : data[i].exceptionType,
														orderId : data[i].orderId,
														orderType :data[i].orderType,
														orderQuantity : data[i].orderQuantity,
														orderPrice :data[i].orderPrice,
														orderDate :data[i].orderDate,
														purchaseOrder : data[i].purchaseOrder,
														orderStatus : data[i].orderStatus,
												}
												if(scope.orderTypes.indexOf(data[i].orderType) == -1){
		                                            scope.orderTypes.push(data[i].orderType);
		                                        }
												if(scope.orderStatusList.indexOf(data[i].orderStatus) == -1){
		                                            scope.orderStatusList.push(data[i].orderStatus);
		                                        }
											}
											scope.orderList.push(dataObj);
										}
                                      
                                    }
                                    
                                    
                                }, function(reject){
                            });
                    
                     scope.startIndex=0;
                     scope.endIndex=10;
                      scope.nextData = function(){
                            scope.startIndex = scope.startIndex+10;
                          if(scope.endIndex <=scope.orderList.length)
                            scope.endIndex = scope.endIndex+10;

                       }
                        scope.previousData = function(){

                           scope.startIndex = scope.startIndex-10;
                           scope.endIndex = scope.endIndex-10;
                       }
                        
                       

						scope.openTrackOrder = function() {
							$("#trackOrderModal").modal(
									"show");
						}
                        
                        scope.getOrderDetail = function(selectedObj){
                             
                            $("#orderDetailModal").modal("show");
                        }
                       $("#updateUserDetailsForm").submit(function(event){
                            var formData = {
                                    userName:$("#userId").val(),
                                    firstName:$("#firstName").val(),
                                    lastName:$("#lastName").val(),
                                    contactNumber:$("#contactNumber").val(),
									email:$("#email").val(),
                                    clientName:$("#clientName").val(),
									clientId:$("#clientId").val(),
                                    workdayTenant:$("#workdayTenant").val(),
							        accessType:$("#accessType").val(),
							        status:$('#status :selected').val(),
                                    comment:$("#commentsID").val()
                            };
                            service = DataServices.getData("userUpdate",formData);
                            service.then(function(data){
                                
                                    scope.addRecordStatus = data.status;
                                    scope.statusMessage = data.message;
                                scope.orderList = [];
								counter = 1;
								var userList = data["userList"];
                                  if(data !=undefined){
                                        for(var i=0; i<userList.length; i++) {
                                        dataObj = {
                                            srNo :counter++,
                                            userName : userList[i].userName,
                                            firstName :userList[i].firstName,
                                            lastName :userList[i].lastName,
                                            email :userList[i].email,
                                            workdayTenant :userList[i].workdayTenant,
                                            contactNumber :userList[i].contactNumber,
                                            clientId : userList[i].clientId,
                                            clientName :userList[i].clientName,
                                            accessType :userList[i].accessType,
                                            status :userList[i].status,
                                            comment :userList[i].comment,
                                            userroles :userList[i].userroles
                                        }
                                        scope.orderList.push(dataObj);
                                    }
									scope.$apply();
                                    }
                                        
                                 $("#orderListModal").modal("hide");
                                 $("#statusMessageModal").modal("show");
                                      
                                  
							  }, function(reject){
                            });
                            
                        });
                }
                }
  })
    .filter('slice', function() {
            return function(arr, start, end) {
            if (!arr || !arr.length) { return; }
            return arr.slice(start, end);
            };
        })
});
