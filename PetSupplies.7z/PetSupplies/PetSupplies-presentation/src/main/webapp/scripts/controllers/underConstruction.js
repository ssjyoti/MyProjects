define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller:MainCtrl
   * @description
   * # MainCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.UnderConstructionCtrl', [])
    .controller('UnderConstructionCtrl', function ($scope) {
      $scope.awesomeThings = [
        'HTML5 Boilerplate',
        'AngularJS',
        'Karma'
      ];
    });
});
