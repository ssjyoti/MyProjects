define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller:ChangePasswordCtrl
   * @description
   * # ChangePasswordCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.ChangePasswordCtrl', [])
    .controller('ChangePasswordCtrl', function ($scope) {
    })
	   .directive('changepasswordTabs', function($window,DataServices) {
            return {
                
                restrict: 'A',                
                link: function(scope, elm, attrs) {
					var service;
                    var jqueryElm = $(elm[0]);
                    $(jqueryElm).tabs();
                   
				   $("#changePasswordForm").submit(function(event){
						
                                    
                            var formData = {
                                    userName:$("#userId").val(),
                                    password:$("#currentPwd").val(),
                                    newPassword:$("#newPwd").val(),
                                    cnfNewPassword:$("#confirmPwd").val()
									
                            };
                            if(formData.password === formData.newPassword){
                            	scope.addRecordStatus ="Failed";
                                scope.statusMessage = "New Password shouldn't be same as Current Password";
								
                            }else{
							if(formData.newPassword.length>5 && formData.cnfNewPassword.length>5){
							if(formData.newPassword === formData.cnfNewPassword){
								service = DataServices.getData("passwordChange",formData);
                                service.then(function(data){
                                
                                    scope.addRecordStatus = data.status;
                                    scope.statusMessage = data.message;
                               
							  }, 
							  function(reject){
                            });
							}else{
								scope.addRecordStatus ="Failed";
                                scope.statusMessage = "New Password/Confirm Password not matched";
							}
							}else{
								scope.addRecordStatus ="Failed";
                                scope.statusMessage = "Password should have min 6 characters";
							}
                            }
                            
                            $("#statusMessageModal").modal("show");
                            
                        });
				   
				   
				   
				}
			}
	   });
});
