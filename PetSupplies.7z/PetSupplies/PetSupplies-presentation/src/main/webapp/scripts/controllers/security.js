

    define(['angular'], function(angular) {
        'use strict';

        /**
         * @ngdoc function
         * @name petSuppliesApp.controller:SecurityCtrl
         * @description
         * # SecurityCtrl
         * Controller of the petSuppliesApp
         */

        angular.module('petSuppliesApp.controllers.SecurityCtrl', [])
            .controller('SecurityCtrl', function($scope,$rootScope) {
            $rootScope.pageWidth = screen.availWidth-215;
         $scope.getDepth = function (obj) {
                                    var depth = 0;
                                    if (obj.children) {
                                        obj.children.forEach(function (d) {
                                            var tmpDepth = $scope.getDepth(d)
                                            if (tmpDepth > depth) {
                                                depth = tmpDepth
                                            }
                                        })
                                    }

                         $rootScope.pageWidth = screen.availWidth+(depth*50);
                          $scope.previousPageWidth =  screen.availWidth+(depth*50);
                                    return 1 + depth
                                }


            $scope.resetInsightWidth =function() {
                $rootScope.pageWidth = $scope.previousPageWidth;            
            }
            $scope.resetWidth =function() {
                    $rootScope.pageWidth = screen.availWidth-232;
            }
            $scope.resetRecommWidth =function() {
                    $rootScope.pageWidth = screen.availWidth-215;
            }
           
            $rootScope.pageHeight = screen.availHeight;
               $scope.operationsData =false;
               $scope.showSecurityServices =false;
               $scope.loadingFunctionalSecurity = false;
               $scope.loadingSecurityGroup = false;
               $scope.loadingSecurityRecomm = false;
               $scope.loadingSecurityException = true;
            
            })
            .directive('securityTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                        var jqueryElm = $(elm[0]);
                        var w = scope.pageWidth,//$('#securityTabs').width()-50,
                        h = 600;
                  
                       $(jqueryElm).tabs();
                         var root,security_root,tree,tree1,diagonal,svg;
                        
                          var securityTable = $('#securty-table'),
                              securityOpsTable = $('#securityOps-table'),
                              operationsTable = $('#operations-table'),
                              chartsHolder = $('.securityTabular');
                        var margin = {
                                top: 20,
                                right: 120,
                                bottom: 20,
                                left: 40
                            },
                            width = w - margin.right - margin.left,height;
                           // height = h - margin.top - margin.bottom;
                         var node_count,secGrpList =[];
                         
                    if(window.location.href.indexOf("showRecommendation") != -1) {
                            $("#insightLink").removeClass("ui-state-active");
                            $("#insightLink").addClass("ui-state-default");
                            $("#recomLink").addClass("ui-state-active");
                            $("#insights").hide();
                            $("#overview").hide();
                            $("#recomendation").show();
                        }
                       $("#overviewLink").click(function(){
                            $("#overviewLink").removeClass("ui-state-default");
                            $("#overviewLink").addClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active");
                            $("#recomLink").removeClass("ui-state-active");
                            $("#recomLink").addClass("ui-state-default");
                            $("#insightLink").addClass("ui-state-default");
                            $("#insights").hide();
                            $("#recomendation").hide();
                            $("#overview").show();
                       });
                        $("#insightLink").click(function(){
                              root =security_root;
                            $("#insightLink").removeClass("ui-state-default");
                            $("#insightLink").addClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active");
                            $("#overviewLink").addClass("ui-state-default");
                            $("#recomLink").removeClass("ui-state-active");
                            $("#recomLink").addClass("ui-state-default");
                            $("#overviewLink").removeClass("ui-state-active");
                            $("#recomLink").addClass("ui-state-default");
                            $("#insights").show();
                            $("#recomendation").hide();
                            $("#overview").hide();
                       });
                        $("#recomLink").click(function(){
                            $("#recomLink").removeClass("ui-state-default");
                            $("#recomLink").addClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active");
                            $("#overviewLink").removeClass("ui-state-active");
                            $("#overviewLink").addClass("ui-state-default");
                            $("#insightLink").removeClass("ui-state-active");
                            $("#insightLink").addClass("ui-state-default");
                            $("#insights").hide();
                            $("#recomendation").show();
                           $("#overview").hide();
                       });
                        var i = 0,
                            duration = 750,root_recom,service;
                          
                             
                            service = DataServices.getData("Security_Group_List","");
                            service.then(function(data){
                                    scope.secGroupList = data; 
                                      //scope.$apply();
                                
                             }, function(reject){
                            });
                            
                         
                        $("#securitySubmitBtn").click(function(){
                            scope.loadingFunctionalSecurity = true;
                            scope.$apply();
                            secGrpList = [];
                            $('#secGrpId option:selected').each(function(){
                                  secGrpList.push($(this).val());
                                });
                                  
                                  $(".securityDomain").hide();
                                  $(".businessProcess").hide();
                            
                        service = DataServices.getData("Security_Tree_Chart",secGrpList);
                            service.then(function(data){
                                scope.getDepth(data);
                                root = data;
                                security_root =data;
                                node_count =root.children.length;
                                if(node_count >=20 && node_count <30)
                                    h= 40*node_count;
                                else if(node_count >=30)                                
                                    h= 30*node_count;
                                else {
                                       h= 600;
                                }
                                  height = h-margin.top - margin.bottom;  
                                
                               tree = d3.layout.tree()
                            .size([height, width]);

                         diagonal = d3.svg.diagonal()
                            .projection(function(d) {
                                return [d.y, d.x];
                            });
                        svg = d3.select('#securitySVG')
                            .attr('width', width + margin.right + margin.left)
                            .attr('height', height + margin.top + margin.bottom)
                            .append('g')
                            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
                                
                                
                                root.x0 = height / 2;
                                root.y0 = 0;
                                
                                function collapse(d) {
                                    if (d.children) {
                                        d._children = d.children;
                                        d._children.forEach(collapse);
                                        d.children = null;
                                    }
                                }

                                root.children.forEach(collapse);
                                setParents(root, null);
                               // collapseAll(root);

                                update(root);
                                scope.loadingFunctionalSecurity = false;
                                 scope.$apply();
                                }, function(reject){
                            });
                          
                                $("#securitySVG").html("");
                        });
                        /* $("#insight").click(function(){
                             root =security_root;
                         });*/

                        
                        function update(source) {
                            // Compute the new tree layout.
                                                     
                           var nodes = tree.nodes(root).reverse(),
                            links = tree.links(nodes);
                            // Normalize for fixed-depth.
                            nodes.forEach(function(d) {
                                d.y = d.depth * 180;
                            });

                            // Update the nodes…
                            var node = svg.selectAll('g.node')
                                .data(nodes, function(d) {
                                    return d.id || (d.id = ++i);
                                });

                            // Enter any new nodes at the parent's previous position.
                            var nodeEnter = node.enter().append('g')
                                .attr('class', 'node')
                                .attr('transform', function(d) {
                                    return 'translate(' + source.y0 + ',' + source.x0 + ')';
                                })
                                .on('click', click)
                             .on('mouseout', mouseout)
                            .on("mouseover",mouseOver)
                            .on("dblclick",dblClick)
                            
                           
                            nodeEnter.append('circle')
                                .attr('r', 10)
                                .style('fill', function(d) {
                                    return d._children ? '#B43104' : '#fff';
                                });


                         
                            nodeEnter.append('text')
                                .attr('x', function(d) {
									  if(d.entityName.length<=10) {
                                        return 40;
                                    }
                                    return 70;
                                 /*   if(d.id==1) {
                                        return 10;
                                    }
                                    else if(d.entityName.length >=8  && d.entityName.length<=10) {
                                        return 40;
                                    }
                                    else if(d.entityName.length >=9  && d.entityName.length<=15) {
                                        return 55;
                                    }
                                    return d.children || d._children ? 70 : 70;*/
                                })
                                .attr('y',function(d) {
                                   /* if(d.id==1) {
                                        return -10;
                                    }*/
                                    return 20;
                                })
                                .attr('text-anchor', function(d) {
                                    return d.children || d._children ? 'end' : 'start';
                                })
                                .text(function(d) {
                                    var entityName = d.entityName.length >15 ?d.entityName.slice(0,15)+'..':d.entityName;
                                    return entityName;
                                })
                                .style('fill-opacity', 1);

                            // Transition nodes to their new position.
                            var nodeUpdate = node.transition()
                                .duration(duration)
                                .attr('transform', function(d) {
                                    return 'translate(' + d.y + ',' + d.x + ')';
                                });

                            nodeUpdate.select('circle')
                                .attr('r', 10)
                           //     .attr('stroke-dasharray',5.5)
                           //     .attr('d','M5 20 l215 0')
                                  .attr('stroke-dasharray', function(d){
                                    if(d.bussinessProcess === true) {
                                        return 1.1;
                                    }
                                  })
                                  .style('fill', function(d) {
                                    return d._children ? '#EB977A' : '#fff';
                                });  


                            nodeUpdate.select('text')
                                .style('fill-opacity', 1);

                            // Transition exiting nodes to the parent's new position.
                            var nodeExit = node.exit().transition()
                                .duration(duration)
                                .attr('transform', function(d) {
                                    return 'translate(' + source.y + ',' + source.x + ')';
                                })
                                .remove();

                            nodeExit.select('circle')
                                .attr('r', 1e-6);

                            nodeExit.select('text')
                                .style('fill-opacity', 1e-6);
                            

                            // Update the links…
                            var link = svg.selectAll('path.link')
                                .data(links, function(d) {
                                    return d.target.id;
                                });

                            // Enter any new links at the parent's previous position.
                            link.enter().insert('path', 'g')
                                .attr('class', 'link')
                                .style('stroke', function(d) {
                                    return '#005777';
                                })
                                .attr('d', function(d) {
                                    var o = {
                                        x: source.x0,
                                        y: source.y0
                                    };
                                    return diagonal({
                                        source: o,
                                        target: o
                                    });
                                });

                            // Transition links to their new position.
                            link.transition()
                                .duration(duration)
                                .attr('d', diagonal);

                            // Transition exiting nodes to the parent's new position.
                            link.exit().transition()
                                .duration(duration)
                                .attr('d', function(d) {
                                    var o = {
                                        x: source.x,
                                        y: source.y
                                    };
                                    return diagonal({
                                        source: o,
                                        target: o
                                    });
                                })
                                .remove();

                            // Stash the old positions for transition.
                            nodes.forEach(function(d) {
                                d.x0 = d.x;
                                d.y0 = d.y;
                            });
                        }
                         
  
                        d3.select(self.frameElement).style('height', '800px');
                        
						function click(d) {
						  if (d3.event.defaultPrevented) return; // ignore drag
						  if (d.children) {
						      collapseAll(d);
						  } else {
						      if (d._parent){
						          d._parent.children.forEach(function(e){
						              if (e != d){
						                  collapseAll(e);
						              }
						          });
						      }
						    d.children = d._children;
						    d._children = null;
						  }
                           /* if(tempValue =="securitySVG")
						      update(d);
                            else*/
                              update(d);
                                
						}
                         
                         function mouseOver(d) {
                             var g = d3.select(this);
                            if(d.entityName.length>15) {
                                 var info = g.append('text')
                                 .classed('info', true)
                                 .attr('x',10)
                                  .attr('y', d._parent !=null? -10:-30)
                                 .text(d.bussinessProcess === undefined? d.entityName:d.bussinessProcess === false?'Dom: '+d.entityName:'BP: '+d.entityName);
                            }
                                
                                 g = d3.select(this); // The node
                         }
                         
                         function dblClick(d) {
                             
                              if (d.bussinessProcess === false) {
                                        $(".businessProcess").hide();
                                         $(".securityDomain").show();
                                        if(d._children != null)
                                         scope.securityGroupOperations = d._children[0].securityGroupOperations;
                                         scope.entityName = d.entityName;
                                         scope.$apply();
                                     }
                                else if(d.bussinessProcess === true) {
                                      $(".securityDomain").hide();
                                      $(".businessProcess").show();
                                      scope.securityGrpTable = "";
                                      scope.bussinessActivities = d.bussinessActivities;
                                      scope.entityName = d.entityName;
                                      scope.$apply();    
                                }
                                else if(d.bussinessProcess == undefined) {
                                    $(".securityDomain").hide();
                                      $(".businessProcess").hide();
                                }
                           
                            
                               
                                $(".securityDomain").css("top",(d.x+150)+'px');
                                $(".securityDomain").css("left",(d.y+150)+'px');
                                $(".businessProcess").css("top",(d.x+150)+'px');
                                $(".businessProcess").css("left",(d.y+100)+'px');
                         }

						function collapseAll(d){
						    if (d.children){
						        d.children.forEach(collapseAll);
						        d._children = d.children;
						        d.children = null;
						    }
						    else if (d._childred){
						        d._children.forEach(collapseAll);
						    }
						}                         
						
						function setParents(d, p){
						    d._parent = p;
						  if (d.children) {
						      d.children.forEach(function(e){ setParents(e,d);});
						  } else if (d._children) {
						      d._children.forEach(function(e){ setParents(e,d);});
						  }
						}                        
                      
                        function mouseout(d) {
                            // operationsDiv.empty();
                             if(d.entityName.length>15) {
                                d3.select(this).select('text.info').remove();
                            }


                        }
                         
                          jQuery("#secGrpId").on("change", function(){
                             // var msg = $("#msg");

                              var count = 0;

                              for (var i = 0; i < this.options.length; i++)
                              {
                                var option = this.options[i];

                                option.selected ? count++ : null;

                                if (count >3)
                                {
                                    option.selected = false;
                                    option.disabled = true;
                                    //alert("Please select only two options.");
                                }else{
                                    option.disabled = false;
                                    //msg.html("");
                                }
                              }
                            });
                         
// Security Recommendation                        

                        var recomTabularData;
                          service = DataServices.getData("Security_Recommendation","");
                            service.then(function(data){
                                scope.recomTabularData = data;
                                scope.loadingSecurityException = false;
                                scope.$apply();
                            }, function(reject){
                            });
                       scope.geProblemList = function(selectedObj) {
                           var counter =1,problemList = [];
                           scope.problemList = [];
                           scope.problemType = selectedObj.exceptionType;
                           var recomDataCount =scope.recomTabularData.length;
                           for(var i=0; i<recomDataCount; i++){
                               if(scope.recomTabularData[i].exceptionType == selectedObj.exceptionType) {
                                   problemList = scope.recomTabularData[i].problemExistsWith;
                                   break;
                               }
                           };
                          var problemListCount = problemList.length;
                            for(var j=0; j<problemListCount; j++) {
                                        var dataObj = {
                                            slNo:counter++,
                                            problem:problemList[j]                                            
                                        }
                                        scope.problemList.push(dataObj);
                                    };
                           scope.$apply();
                       };
                         
                          scope.startIndex=0;
                         scope.endIndex=20;
                          scope.nextData = function(){
                                scope.startIndex = scope.startIndex+20;
                              if(scope.endIndex <=scope.problemList.length)
                                scope.endIndex = scope.endIndex+20;

                           }
                            scope.previousData = function(){

                               scope.startIndex = scope.startIndex-20;
                               scope.endIndex = scope.endIndex-20;
                           }
                            
                            $(".glyphicon-download").unbind().click(function(event) {
                               var pdf = new jsPDF('p', 'pt', 'letter');
                            // source can be HTML-formatted string, or a reference
                            // to an actual DOM element from which the text will be scraped.
                              var divContents;     
                               
                            divContents = $("#problemListModal-Download").html();
                             //  divContents = divContents.replace("none","block");   
                                  
                                
                            var source = divContents;

                            // we support special element handlers. Register them with jQuery-style 
                            // ID selector for either ID or node name. ("#iAmID", "div", "span" etc.)
                            // There is no support for any other type of selectors 
                            // (class, of compound) at this time.
                            var specialElementHandlers = {
                                // element with id of "bypass" - jQuery style selector
                                '#bypassme': function (element, renderer) {
                                    // true = "handled elsewhere, bypass text extraction"
                                    return true
                                }
                            };
                            var margins = {
                                top: 80,
                                bottom: 60,
                                left: 40,
                                width: 522
                            };
                            // all coords and widths are in jsPDF instance's declared units
                            // 'inches' in this case
                            pdf.fromHTML(
                            source, // HTML string or DOM elem ref.
                            margins.left, // x coord
                            margins.top, { // y coord
                                'width': margins.width, // max width of content on PDF
                                'elementHandlers': specialElementHandlers
                            },

                            function (dispose) {
                                // dispose: object with X, Y of the last line add to the PDF 
                                //          this allow the insertion of new lines after html
                                pdf.save(scope.problemType+'.pdf');
                            }, margins);
                             
                              
                        });
                    }
                };
            })
            .directive('insightTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                        var jqueryElm = $(elm[0]);
                        var w = scope.pageWidth,//$('#securityTabs').width()-50,
                        h = 600;
                         var service,node_count,tree;
                          var margin = {
                                top: 20,
                                right: 120,
                                bottom: 20,
                                left: 105
                            }, width = w - margin.right - margin.left,height,diagonal,i = 0,duration = 750;
                         
                         var  chartsHolder = $('.securityTabular');
                       $(jqueryElm).tabs();
                         
                          $("#securityGrpType").click(function(){
                             
                            service = DataServices.getData("Security_Group_Type","");
                            service.then(function(data){
                                    scope.securityGroupTypeList = data; 
                                    
                                
                             }, function(reject){
                            });
                              scope.$apply();
                         });
                          jQuery("#securityGroupId").on("change", function(){
                             // var msg = $("#msg");

                              var count = 0;

                              for (var i = 0; i < this.options.length; i++)
                              {
                                var option = this.options[i];

                                option.selected ? count++ : null;

                                if (count >3)
                                {
                                    option.selected = false;
                                    option.disabled = true;
                                    //alert("Please select only two options.");
                                }else{
                                    option.disabled = false;
                                    //msg.html("");
                                }
                              }
                            });
                        
                         var svg1,root1,securityInputVO,securityGroupList = [],securityGrpTreeData,securityGroupTypeId,securityGroupData ={};
                         $("#securityForm").submit(function(event){   
                             scope.loadingSecurityGroup = true;
                             scope.$apply();
                               $(".businessProcess").hide();
                                $(".securityDomain").hide();
								securityGroupList = [];
                            
                              $('#securityGroupId option:selected').each(function(){
                                  securityGroupList.push($(this).val());
                                  
                                });
                             securityGroupTypeId = $("#securityGroupTypeId option:selected").val();
							 securityInputVO = {
								 securityGroups:securityGroupList,
								 type:securityGroupTypeId
							 }
                          
                            service = DataServices.getData("Security_Group_Details",securityInputVO);
                                service.then(function(data){
                                    scope.getDepth(data);
                               root1 = data;
                                node_count =root1.children.length;
                                if(node_count >=20 && node_count <30)
                                    h= 40*node_count;
                                else if(node_count >=30)                                
                                    h= 26*node_count;
                                else {
                                       h= 600;
                                }
                                  height = h-margin.top - margin.bottom;  
                                
                                 tree = d3.layout.tree()
                            .size([height, width]);
                                        
                         diagonal = d3.svg.diagonal()
                            .projection(function(d) {
                                return [d.y, d.x];
                            });
                              svg1 = d3.select('#securityDetailSVG')
                            .attr('width', width + margin.right + margin.left)
                            .attr('height', height + margin.top + margin.bottom)
                            .append('g')
                            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
                    
                               root1.x0 = height / 2;
                                root1.y0 = 0;
                                    
                                function collapse(d) {
                                    if (d.children) {
                                        d._children = d.children;
                                        d._children.forEach(collapse);
                                        d.children = null;
                                    }
                                }

                                root1.children.forEach(collapse);
                                setParents(root1, null);
                               // collapseAll(root1);
                                        
                                update(root1);
                               scope.loadingSecurityGroup = false;
                                scope.$apply();
                                }, function(reject){
                            });
                              $("#securityDetailSVG").html("");
                              
                         })
                         $("#securityGroupTypeId").change(function(){
                             scope.securityGroupList = [];
                             securityGroupList = [];
                                var selectedSecurityGrpTypeVal = $("#securityGroupTypeId option:selected").val();                                    
                                        service = DataServices.getData("Security_Group",selectedSecurityGrpTypeVal); 
                                        service.then(function(data){
                                            scope.securityGroupList = data;

                                         }, function(reject){
                                    });
                             
                             scope.$apply();
                              $("#securityDetailSVG").html("");
                                
                         })
                        function update(source) {
                            // Compute the new tree layout.
                                                     
                               var nodes = tree.nodes(root1).reverse(),
                            links = tree.links(nodes);
                            // Normalize for fixed-depth.
                            nodes.forEach(function(d) {
                                d.y = d.depth * 180;
                            });

                            // Update the nodes…
                            var node = svg1.selectAll('g.node')
                                .data(nodes, function(d) {
                                    return d.id || (d.id = ++i);
                                });

                            // Enter any new nodes at the parent's previous position.
                            var nodeEnter = node.enter().append('g')
                                .attr('class', 'node')
                                .attr('transform', function(d) {
                                    return 'translate(' + source.y0 + ',' + source.x0 + ')';
                                })
                                .on('click', click)
                             .on('mouseout', mouseout)
                              .on('mouseover', mouseover)
                            .on("dbLclick",dblClick)
                                
                           
                            
                           
                            nodeEnter.append('circle')
                                .attr('r', 10)
                                
                                .style('fill', function(d) {
                                    return d._children ? '#B43104' : '#fff';
                                });


                          
                            nodeEnter.append('text')
                                 .attr('x', function(d) {
									  if(d.entityName.length<=10) {
                                        return 40;
                                    }
                                    return 70;
                                    /*if(d.id==1) {
                                        return 10;
                                    }
                                    else if(d.entityName.length >=8  && d.entityName.length<=10) {
                                        return 40;
                                    }
                                    else if(d.entityName.length >=9  && d.entityName.length<=15) {
                                        return 55;
                                    }
                                    return d.children || d._children ? 70 : 70;*/
                                })
                                .attr('y',function(d) {
                                   /* if(d.id==1) {
                                        return -10;
                                    }*/
                                    return 20;
                                })
                                .attr('text-anchor', function(d) {
                                    return d.children || d._children ? 'end' : 'start';
                                })
                                .text(function(d) {
                                    var entityName = d.entityName.length >15 ?d.entityName.slice(0,15)+'..':d.entityName;
                                    return entityName;
                                })
                                .style('fill-opacity', 1);

                            // Transition nodes to their new position.
                            var nodeUpdate = node.transition()
                                .duration(duration)
                                .attr('transform', function(d) {
                                    return 'translate(' + d.y + ',' + d.x + ')';
                                });

                            nodeUpdate.select('circle')
                                .attr('r', 10)
                           //     .attr('stroke-dasharray',5.5)
                           //     .attr('d','M5 20 l215 0')
                                  .attr('stroke-dasharray', function(d){
                                    
                                    if(d._parent != null && (d.permissions != null || d.entityName == "Functional Area for Business Process Type" || d._parent.entityName == "Functional Area for Business Process Type")) {
                                        return 1.1;
                                    }
                                  })
                                  .style('fill', function(d) {
                                    return d._children ? '#EB977A' : '#fff';
                                });  


                            nodeUpdate.select('text')
                                .style('fill-opacity', 1);

                            // Transition exiting nodes to the parent's new position.
                            var nodeExit = node.exit().transition()
                                .duration(duration)
                                .attr('transform', function(d) {
                                    return 'translate(' + source.y + ',' + source.x + ')';
                                })
                                .remove();

                            nodeExit.select('circle')
                                .attr('r', 1e-6);

                            nodeExit.select('text')
                                .style('fill-opacity', 1e-6);
                            

                            // Update the links…
                            var link = svg1.selectAll('path.link')
                                .data(links, function(d) {
                                    return d.target.id;
                                });

                            // Enter any new links at the parent's previous position.
                            link.enter().insert('path', 'g')
                                .attr('class', 'link')
                                .style('stroke', function(d) {
                                    return '#005777';
                                })
                                .attr('d', function(d) {
                                    var o = {
                                        x: source.x0,
                                        y: source.y0
                                    };
                                    return diagonal({
                                        source: o,
                                        target: o
                                    });
                                });

                            // Transition links to their new position.
                            link.transition()
                                .duration(duration)
                                .attr('d', diagonal);

                            // Transition exiting nodes to the parent's new position.
                            link.exit().transition()
                                .duration(duration)
                                .attr('d', function(d) {
                                    var o = {
                                        x: source.x,
                                        y: source.y
                                    };
                                    return diagonal({
                                        source: o,
                                        target: o
                                    });
                                })
                                .remove();

                            // Stash the old positions for transition.
                            nodes.forEach(function(d) {
                                d.x0 = d.x;
                                d.y0 = d.y;
                            });
                        }
                         
  
                        d3.select(self.frameElement).style('height', '800px');
                        
						function click(d) {
						  if (d3.event.defaultPrevented) return; // ignore drag
						  if (d.children) {
						      collapseAll(d);
						  } else {
						      if (d._parent){
						          d._parent.children.forEach(function(e){
						              if (e != d){
						                  collapseAll(e);
						              }
						          });
						      }
						    d.children = d._children;
						    d._children = null;
						  }
                           /* if(tempValue =="securitySVG")
						      update(d);
                            else*/
                              update(d);
                                
						}

                          function mouseover(d) {
                               var g = d3.select(this);
                            if(d.entityName.length>15) {
                                 var info = g.append('text')
                                 .classed('info', true)
                                 .attr('x',10)
                                 .attr('y', d._parent !=null? -10:-30)
                                 .text(d.bussinessProcess === undefined? d.entityName:d.bussinessProcess === false?'Dom: '+d.entityName:'BP: '+d.entityName);
                            }
                               g = d3.select(this); // The node
                          }
                         
                         function dblClick(d) {
                                 $(".businessProcess").hide();
                                if(d._parent !=null) {
                                     if (d._parent.entityName === "Functional Area for Domain Security Policy") {
                                         $(".securityDomain").show();
                                         scope.dspOperations = d.dspOperations;
                                         scope.entityName = d.entityName;
                                         scope.$apply();
                                     }
                                     else {
                                        $(".securityDomain").hide();
                                    }
                               
                                
                                 if(d._parent._parent !=null) {
                                     if(d._parent._parent.entityName === "Functional Area for Business Process Type") {
                                         $(".businessProcess").show();
                                         scope.permissions = d.permissions;
                                         scope.entityName = d.entityName;
                                         scope.$apply();
                                     }
                                     else {
                                        $(".businessProcess").hide();
                                    }
                                   
                                 }
                                }
                                
                               
                                
                              
                               $(".securityDomain").css("top",(d.x+180)+'px');
                               $(".securityDomain").css("left",(d.y+150)+'px');
                                
                               $(".businessProcess").css("top",(d.x+180)+'px');
                               $(".businessProcess").css("left",(d.y+150)+'px');
                    
                                
                              }
                         
						function collapseAll(d){
						    if (d.children){
						        d.children.forEach(collapseAll);
						        d._children = d.children;
						        d.children = null;
						    }
						    else if (d._childred){
						        d._children.forEach(collapseAll);
						    }
						}                         
					

						function setParents(d, p){
						    d._parent = p;
						  if (d.children) {
						      d.children.forEach(function(e){ setParents(e,d);});
						  } else if (d._children) {
						      d._children.forEach(function(e){ setParents(e,d);});
						  }
						}     
                         
                           function mouseout(d) {
                            // operationsDiv.empty();
                             if(d.entityName.length>15) {
                                d3.select(this).select('text.info').remove();
                            }


                        }
//ESS-MSS Servicess 
                       
                       service = DataServices.getData("Security_FunctionalArea",$('input[name=serviceType]:checked').val());
                            service.then(function(data){
                                scope.functionalArea =data;
							 }, function(reject){
                            });
                         
                         $("input[name=serviceType]:radio").change(function() {
                           
                             scope.showSecurityServices = false;
                             scope.functionalArea = [];
                             service = DataServices.getData("Security_FunctionalArea",$('input[name=serviceType]:checked').val());
                                service.then(function(data){
                                    scope.functionalArea =data;
                                 }, function(reject){
                                });
                              scope.$apply(); 
                         })
                         
                        $("#form").submit(function(event){
                            scope.loadingSecurityRecomm = true;
                            scope.$apply();
                           scope.showSecurityServices = true;
							var searchCriteria ={
							   //serviceType:$('input[name=serviceType]:checked').val(),
								essMssValue:$('input[name=serviceType]:checked').val(),
							   functionalArea: $('#functionalArea :selected').val()
                               
							};
                             var exceptionData = [];
                           
                            service = DataServices.getData("Security_configData",searchCriteria);
                            service.then(function(data){
                                var i=0;
                                var exceptiontempObj;
                                scope.showSecurityServices =true;
                                scope.tenantConfigsData =data["tenantConfigs"];
                                scope.workdayConfigsData =data["workdayConfigs"];
                                scope.comparisionConfigsData =data["comparisionConfigs"];
                                while(data["tenantConfigs"][Object.keys(scope.tenantConfigsData)[i]] !=undefined && data["workdayConfigs"][Object.keys(scope.workdayConfigsData)[i]] !=undefined) {
                                    if(data["tenantConfigs"][Object.keys(scope.tenantConfigsData)[i]] == data["workdayConfigs"][Object.keys(scope.workdayConfigsData)[i]]) {
                                        exceptiontempObj = {
                                            name : Object.keys(scope.tenantConfigsData)[i],
                                            value : "Expected",
                                            color: "green"
                                        }
                                        exceptionData.push(exceptiontempObj);
                                    }
                                    else {
                                         exceptiontempObj = {
                                            name : Object.keys(scope.tenantConfigsData)[i],
                                            value : "Critical",
                                             color: "red"
                                        }
                                       exceptionData.push(exceptiontempObj);
                                    }
                                    i++;
                                }
                                scope.exceptionData = exceptionData;
                                //var obj = { first: 'someVal', second: 'otherVal' };
                                    //alert(Object.keys(scope.tenantConfigsData)[0]); // returns first
                                scope.loadingSecurityRecomm = false;
                                scope.$apply();
							 }, function(reject){
                            });
                         })
                     }
                }
        })
        .directive('recomendationTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                          var jqueryElm = $(elm[0]);
                        var w = $('#recomendationTabs').width()-50,
                        h = 600;
                  
                       $(jqueryElm).tabs();
                     }
                }
        });

    });

