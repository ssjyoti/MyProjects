define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller:AboutCtrl
   * @description
   * # AboutCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.AboutCtrl', [])
    .controller('AboutCtrl', function ($scope,$rootScope) {
       $rootScope.moduleHeaderName = "Welcome to Pet Supplies Application";
     
    });
});

