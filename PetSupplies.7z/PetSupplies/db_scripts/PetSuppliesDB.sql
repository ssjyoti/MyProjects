create database if not exists petsuppliesdb; 
use petsuppliesdb;
flush privileges;
/*set foreign_key_checks=1;*/
drop table if exists user_role;
drop table if exists role;
drop table if exists user;
drop table if exists client;
    
 create table if not exists `petsuppliesdb`.`client` (
  `clientid` int(11) not null auto_increment,
  `client_name` varchar(44) not null,
  `db_instance` varchar(120) not null,
  `sftp_server` varchar(120) not null,
  `enabled` tinyint(1) not null,
  `application_url` varchar(220) not null default '',
  primary key (`clientid`),
  unique key `client_name` (`client_name`),
  key `client_clientid_idx` (`clientid`)
) engine=innodb auto_increment=1002 default charset=utf8;

create table if not exists `petsuppliesdb`.`user` (
  `username` varchar(44) not null,
  `first_name` varchar(120) not null,
  `last_name` varchar(120) not null,
  `email` varchar(120) not null,
  `password` varchar(120) default null,
  `is_password_reset` tinyint(1) not null,
  `pwd_last_modified` datetime default null,
  `status` varchar(44) not null,
  `clientid` int(11) default null,
  `address` varchar(500) not null,
  `contact_number` varchar(50) not null,
  `is_Cg_User` tinyint(1) not null,
  `comment` varchar(300) default null,
  primary key (`username`),
  constraint `client_clientid_idx` foreign key (`clientid`) references `petsuppliesdb`.`client` (`clientid`)
) engine=innodb default charset=utf8;

create table if not exists `petsuppliesdb`.`role` (
  `role_name` varchar(44) not null,
  primary key (`role_name`)
) engine=innodb default charset=utf8;

create table if not exists `petsuppliesdb`.`user_role` (
  `id` int(11) not null auto_increment,
  `username` varchar(44) not null,
  `role_name` varchar(44) default null,
  primary key (`id`),
  key `fk_user_name1` (`username`),
  key `fk_user_role1` (`role_name`),
  constraint `fk_user_name1` foreign key (`username`) references `user` (`username`),
  constraint `fk_user_role1` foreign key (`role_name`) references `role` (`role_name`)
) engine=innodb auto_increment=1005 default charset=utf8;
        
       	insert into `petsuppliesdb`.`role`(`ROLE_NAME`)
        VALUES ('Admin');
		insert into `petsuppliesdb`.`role` (`ROLE_NAME`) 
		VALUES ('User');
		insert into `petsuppliesdb`.`client`(`Client_Name`,`DB_Instance`,`SFTP_Server`,`ENABLED`,`APPLICATION_URL`)
		VALUES('asiapac','asiapacDB','asiapacSFTP',1,'asiapacURL');
		insert into `petsuppliesdb`.`client`(`Client_Name`,`DB_Instance`,`SFTP_Server`,`ENABLED`,`APPLICATION_URL`)
		VALUES ('us','usDB','usSFTP',1,'usURL');
		insert into `petsuppliesdb`.`client`(`Client_Name`,`DB_Instance`,`SFTP_Server`,`ENABLED`,`APPLICATION_URL`)
		VALUES ('uk','ukDB','ukSFTP',1,'ukURL');
		insert into `petsuppliesdb`.`client`(`Client_Name`,`DB_Instance`,`SFTP_Server`,`ENABLED`,`APPLICATION_URL`)
		VALUES ('anz','anzdb','anzSFTP',1,'anzURL');
		insert into `petsuppliesdb`.`client`(`Client_Name`,`DB_Instance`,`SFTP_Server`,`ENABLED`,`APPLICATION_URL`)
		VALUES ('sa','sadb','saSFTP',1,'saURL');
		
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1004,'uk',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1004,'uk',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin1','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1003,'us',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user1','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1003,'us',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin2','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1005,'anz',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user2','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1005,'anz',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin3','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1002,'asiapac',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user3','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1002,'asiapac',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin4','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1003,'us',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user4','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1003,'us',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin5','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1003,'us',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user5','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1003,'us',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin6','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1006,'sa',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user6','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1006,'sa',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin7','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1005,'anz',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user7','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1005,'anz',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin8','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1005,'anz',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user8','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1005,'anz',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin9','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1002,'asiapac',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user9','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1002,'asiapac',0,322222,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_admin10','Jyotiranjan','Admin','x@y.com','123456',1,now(),'ACTIVE',1004,'uk',0,333333,'');
		INSERT INTO `petsuppliesdb`.`user` (`USERNAME`,`FIRST_NAME`,`LAST_NAME`,`EMAIL`,`PASSWORD`,`IS_PASSWORD_RESET`,`PWD_LAST_MODIFIED`,`STATUS`,`ClientID`,`ADDRESS`,`IS_CG_USER`,`CONTACT_NUMBER`,`COMMENT`) 
		VALUES ('jyoti_user10','Jyotiranjan','User','c@e.com','123456',1,now(),'ACTIVE',1004,'uk',0,322222,'');

		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user1','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin1','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user2','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin2','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user3','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin3','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user4','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin4','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user5','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin5','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user6','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin6','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user7','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin7','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user8','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin8','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user9','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin9','Admin');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_user10','User');
		INSERT INTO `petsuppliesdb`.`user_role` (`USERNAME`,`ROLE_NAME`) VALUES ('jyoti_admin10','Admin');