create database if not exists ukdb; 
use ukdb;

flush privileges;

set foreign_key_checks=0;

drop table if exists orders;
drop table if exists product;
drop table if exists pet;
drop table if exists supply;

set foreign_key_checks=1;

create table `pet` (
  `pet_id` int(11),
  `pet_type` varchar(20),
  `breed` varchar(20),
  `about` varchar(200)
) default charset=utf8;

create table `supply` (
  `supply_id` int(11),
  `supply_type` varchar(20),
  `item` varchar(20),
  `about` varchar(200)
 ) default charset=utf8;


create table `product` (
  `product_id` varchar(20),
  `product_type` varchar(20),
  `quantity` int(11),
  `price` varchar(20),
  `pet_id` int(11) default 0,
  `supply_id` int(11) default 0,
  `status` varchar(20),
  primary key (`product_id`)
) default charset=utf8;

create table `orders` (
  `order_id` varchar(20),
  `order_type` varchar(20),
  `order_quantity` int(11),
  `order_price` varchar(20),
  `order_date` datetime default null,
  `purchase_order` int(11) default 0,
  `order_status` varchar(200),
  primary key (`order_id`)
) default charset=utf8;

insert into ukdb.pet values('0','NA','NA','NA');
insert into ukdb.pet values('1','Birds','Parrot','Known as the talking bird and understand human language');
insert into ukdb.pet values('2','Dog','Labroder','A good Frined of Human');
insert into ukdb.pet values('3','Cat','Grey Cat','A good Frined of Human');
insert into ukdb.pet values('4','Fish','Fighter Fish','Good to have in the aquarium');
insert into ukdb.pet values('5','Reptile','Snake','All snakes are not poisonus');

insert into ukdb.supply values('0','NA','NA','NA');
insert into ukdb.supply values('11','Food','Dog food','Healthy food for all kind of Dogs');
insert into ukdb.supply values('12','Accessories','neck band','Made of nice leather');
insert into ukdb.supply values('13','Health','Pet Medicine','A product of vetenary clinic');
insert into ukdb.supply values('14','Health Accesories','Pet Cloth','A nice product made of cotton');
insert into ukdb.supply values('15','Pet Uterncile','Dog plate','Good grip and made of stain less stell');
 
  
insert into ukdb.Product values('1001','Pet','80','2000','1','0','Available');
insert into ukdb.Product values('1002','Pet','1300','4000','2','0','Available');
insert into ukdb.Product values('1003','Pet','180','1000','3','0','NA');
insert into ukdb.Product values('1004','Pet','330','100','4','0','Available');
insert into ukdb.Product values('1005','Pet','150','3000','5','0','NA');

insert into ukdb.Product values('1006','Supply','80','2000','0','11','Available');
insert into ukdb.Product values('1007','Supply','1300','4000','0','12','Available');
insert into ukdb.Product values('1008','Supply','180','1000','0','13','Available');
insert into ukdb.Product values('1009','Supply','330','100','0','14','Available');
insert into ukdb.Product values('1010','Supply','150','3000','0','15','NA');

insert into ukdb.Orders values('101','Online','15','300',now(),'4234625','BackOrdered');
insert into ukdb.Orders values('102','Online','150','200',now(),'2354625','Order Received and ready for Processing');
insert into ukdb.Orders values('103','Online','105','400',now(),'7896625','Shipped');
insert into ukdb.Orders values('104','Online','235','500',now(),'12396625','Shipped');

commit;
