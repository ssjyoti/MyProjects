module.exports = function(grunt){
	grunt.initConfig({
  uglify: {
    options: {
      mangle: false
    },
    my_target: {
     files : {
      'dist/scripts/controllers/about.js' : 'scripts/controllers/about.js',
	  'dist/scripts/controllers/absenceManagement.js' : 'scripts/controllers/absenceManagement.js',
	  'dist/scripts/controllers/absencemetrics.js' : 'scripts/controllers/absencemetrics.js',
	  'dist/scripts/controllers/accessManagement.js' : 'scripts/controllers/accessManagement.js',
	  'dist/scripts/controllers/bpConfiguration.js' : 'scripts/controllers/bpConfiguration.js',
	  'dist/scripts/controllers/businessProcessFramework.js' : 'scripts/controllers/businessProcessFramework.js',
	  'dist/scripts/controllers/businessProcessOptimization.js' : 'scripts/controllers/businessProcessOptimization.js',
	  'dist/scripts/controllers/compensationPlan.js' : 'scripts/controllers/compensationPlan.js',
	  'dist/scripts/controllers/hcmStaffing.js' : 'scripts/controllers/hcmStaffing.js',
	  'dist/scripts/controllers/integrations.js' : 'scripts/controllers/integrations.js',
	  'dist/scripts/controllers/jobprofilesetup.js' : 'scripts/controllers/jobprofilesetup.js',
	  'dist/scripts/controllers/login.js' : 'scripts/controllers/login.js',
	  'dist/scripts/controllers/main.js' : 'scripts/controllers/main.js',
	  'dist/scripts/controllers/organization.js' : 'scripts/controllers/organization.js',
	  'dist/scripts/controllers/organizationAudit.js' : 'scripts/controllers/organizationAudit.js',
	  'dist/scripts/controllers/reportingMetrics.js' : 'scripts/controllers/reportingMetrics.js',
	  'dist/scripts/controllers/security.js' : 'scripts/controllers/security.js',
	  'dist/scripts/controllers/securityAudit.js' : 'scripts/controllers/securityAudit.js',
	  'dist/scripts/controllers/services.js' : 'scripts/controllers/services.js',
	  'dist/scripts/controllers/staffing.js' : 'scripts/controllers/staffing.js',
	  'dist/scripts/controllers/talent.js' : 'scripts/controllers/talent.js',
	  'dist/scripts/controllers/underConstruction.js' : 'scripts/controllers/underConstruction.js',
	  'dist/scripts/controllers/userStatus.js' : 'scripts/controllers/userStatus.js', 
	  'dist/scripts/controllers/utilization.js' : 'scripts/controllers/utilization.js',
	  'dist/scripts/controllers/worker.js' : 'scripts/controllers/worker.js',
	  'dist/scripts/app.js' : 'scripts/app.js',
	  'dist/scripts/main.js' : 'scripts/main.js'
	  
    }
    }
  }
});
grunt.loadNpmTasks('grunt-contrib-uglify');
}