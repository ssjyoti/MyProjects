define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller.ProductSearchCtrl
   * @description
   * # ProductSearchCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.ProductSearchCtrl', [])
    .controller('ProductSearchCtrl', function ($scope,$rootScope) {
    	$rootScope.moduleHeaderName = "Welcome to Pet Supplies Application";
        $scope.currentUser = sessionStorage.getItem("firstName");
        $scope.clientName = sessionStorage.getItem("clientId");
 	    $scope.currentUserId = sessionStorage.getItem("username");
 	    $scope.roleName = sessionStorage.getItem("roleId");
         $rootScope.pageWidth = screen.availWidth-215;
     
         $rootScope.pageHeight = screen.availHeight;
         $scope.cart = [];
    })
  .directive('searchproductsTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                     var service,dataCount,dataObj,counter;
                     service = DataServices.getData("Pet_Search_Results","");
                            service.then(function(data){
                            dataCount = data.length;
                                counter=1;
                                scope.productTypes = [];
                                scope.petOrSupplyTypeList = []
                                scope.productList = [];
								if(data !=undefined){
                                        for(var i=0; i<dataCount; i++) {
											if (data[i].exceptionType != "<Best Practice> : Invalid Product Assignments") {
												var dataObj = {
														srNo : counter++,
														exceptionType : data[i].exceptionType,
														productId : data[i].productId,
														petId :data[i].petId,
														productType : data[i].productType,
														breedOrItem :data[i].breedOrItem,
														petOrSupplyType :data[i].petOrSupplyType,
														price : data[i].price,
														quantity : data[i].quantity,
														supplyId : data[i].supplyId,
														status : data[i].status,
														about : data[i].about
												}
												if(scope.productTypes.indexOf(data[i].productType) == -1){
		                                            scope.productTypes.push(data[i].productType);
		                                        }
												if(scope.petOrSupplyTypeList.indexOf(data[i].petOrSupplyType) == -1){
		                                            scope.petOrSupplyTypeList.push(data[i].petOrSupplyType);
		                                        }
											}
											scope.productList.push(dataObj);
										}
                                      
                                    }
                                    
                                    
                                }, function(reject){
                            });
                    
                     scope.startIndex=0;
                     scope.endIndex=10;
                      scope.nextData = function(){
                            scope.startIndex = scope.startIndex+10;
                          if(scope.endIndex <=scope.productList.length)
                            scope.endIndex = scope.endIndex+10;

                       }
                        scope.previousData = function(){

                           scope.startIndex = scope.startIndex-10;
                           scope.endIndex = scope.endIndex-10;
                       }
                        
                        scope.addItemToCart = function(
                        		productId, petOrSupplyType,breedOrItem,
								productPrice, productQuantity) {
							//alert('add to cart'+productId+' type'+productType+'price '+productPrice+'qty '+qty);
							var count = 0 , totalPrice = 0 ;
							var cartObj = {
								productId : productId,
								petOrSupplyType : petOrSupplyType,
								breedOrItem : breedOrItem,
								productPrice : productPrice,
								productQuantity : productQuantity,
								totalPrice : totalPrice + productPrice,
								count : count + 1
							}
							scope.cart.push(cartObj);

						}

						scope.openCart = function() {
							$("#shoppingCartModal").modal(
									"show");
						}
                        
                        scope.placeOrder = function(data){
                             
                            $("#placeOrderModal").modal("show");
                        }
                       $("#placeOrderForm").submit(function(event){
                            var formData = {
                                    userName:$("#userId").val(),
                                    firstName:$("#firstName").val(),
                                    lastName:$("#lastName").val(),
                                    contactNumber:$("#contactNumber").val(),
									email:$("#email").val(),
                                    clientName:$("#clientName").val(),
									clientId:$("#clientId").val(),
                                    workdayTenant:$("#workdayTenant").val(),
							        accessType:$("#accessType").val(),
							        status:$('#status :selected').val(),
                                    comment:$("#commentsID").val()
                            };
                            service = DataServices.getData("userUpdate",formData);
                            service.then(function(data){
                                
                                    scope.addRecordStatus = data.status;
                                    scope.statusMessage = data.message;
                                scope.productList = [];
								counter = 1;
								var userList = data["userList"];
                                  if(data !=undefined){
                                        for(var i=0; i<userList.length; i++) {
                                        dataObj = {
                                            srNo :counter++,
                                            userName : userList[i].userName,
                                            firstName :userList[i].firstName,
                                            lastName :userList[i].lastName,
                                            email :userList[i].email,
                                            workdayTenant :userList[i].workdayTenant,
                                            contactNumber :userList[i].contactNumber,
                                            clientId : userList[i].clientId,
                                            clientName :userList[i].clientName,
                                            accessType :userList[i].accessType,
                                            status :userList[i].status,
                                            comment :userList[i].comment,
                                            userroles :userList[i].userroles
                                        }
                                        scope.productList.push(dataObj);
                                    }
									scope.$apply();
                                    }
                                        
                                 $("#productListModal").modal("hide");
                                 $("#statusMessageModal").modal("show");
                                      
                                  
							  }, function(reject){
                            });
                            
                        });
                }
                }
  })
    .filter('slice', function() {
            return function(arr, start, end) {
            if (!arr || !arr.length) { return; }
            return arr.slice(start, end);
            };
        })
});
