define(['angular'], function (angular) {
  'use strict';

  /**
   * @ngdoc function
   * @name petSuppliesApp.controller.ProductDetailCtrl
   * @description
   * # ProductDetailCtrl
   * Controller of the petSuppliesApp
   */
  angular.module('petSuppliesApp.controllers.ProductDetailCtrl', [])
    .controller('ProductDetailCtrl', function ($scope,$rootScope) {
      $rootScope.moduleHeaderName = "Manage Products";
     
    })
  .directive('manageproductsTabs', function($window,DataServices) {
                return {
                    restrict: 'A',

                     link: function(scope, elm, attrs) {
                     var service,dataCount,dataObj,counter;
                     service = DataServices.getData("Pet_Search_Results","");
                            service.then(function(data){
                            dataCount = data.length;
                                counter=1;
                                scope.productTypes = [];
                                scope.statusList = []
                                scope.productList = [];
                                  if(data !=undefined){
                                        for(var i=0; i<dataCount; i++) {
											if (data[i].exceptionType != "<Best Practice> : Invalid Product Assignments") {
												var dataObj = {
														srNo : counter++,
														exceptionType : data[i].exceptionType,
														productId : data[i].productId,
														petId :data[i].petId,
														productType : data[i].productType,
														breedOrItem :data[i].breedOrItem,
														petOrSupplyType :data[i].petOrSupplyType,
														price : data[i].price,
														quantity : data[i].quantity,
														supplyId : data[i].supplyId,
														status : data[i].status,
														about : data[i].about
												}
												if(scope.productTypes.indexOf(data[i].productType) == -1){
		                                            scope.productTypes.push(data[i].productType);
		                                        }
												if(scope.statusList.indexOf(data[i].status) == -1){
		                                            scope.statusList.push(data[i].status);
		                                        }
											}
											scope.productList.push(dataObj);
										}
                                      
                                    }
                                    
                                    
                                }, function(reject){
                            });
                    
                     scope.startIndex=0;
                     scope.endIndex=10;
                      scope.nextData = function(){
                            scope.startIndex = scope.startIndex+10;
                          if(scope.endIndex <=scope.productList.length)
                            scope.endIndex = scope.endIndex+10;

                       }
                        scope.previousData = function(){

                           scope.startIndex = scope.startIndex-10;
                           scope.endIndex = scope.endIndex-10;
                       }
                        
                        scope.getProductDetail = function(selectedObj){
                             scope.prodObjct = {
                            	productId:selectedObj.productId,
                            	petId:selectedObj.petId,
                            	petOrSupplyType:selectedObj.petOrSupplyType,
                            	breedOrItem:selectedObj.breedOrItem,
                            	productType:selectedObj.productType,
                            	price:selectedObj.price,
                            	quantity:selectedObj.quantity,
                            	supplyId:selectedObj.supplyId,
                            	status:selectedObj.status,
                                about:selectedObj.about
                              };
                            scope.$apply();
                            $("#productDetailModal").modal("show");
                        }
                       $("#updateProductDetailForm").submit(function(event){
                            var formData = {
                            		productId:$("#productId").val(),
                            		petId:$("#petId").val(),
                            		petOrSupplyType:$("#petOrSupplyType").val(),
                            		breedOrItem:$("#breedOrItem").val(),
                            		productType:$("#productType").val(),
                            		price:$("#price").val(),
                            		quantity:$("#quantity").val(),
                            		supplyId:$("#supplyId").val(),
                            		status:$("#status").val(),
                            		about:$('#about').val()
                            };
                            service = DataServices.getData("productUpdate",formData);
                            service.then(function(data){
                                
                                    scope.addRecordStatus = data.status;
                                    scope.statusMessage = data.message;
                                scope.productList = [];
								counter = 1;
								var productList = data["productList"];
                                  if(data !=undefined){
                                        for(var i=0; i<userList.length; i++) {
                                        dataObj = {
                                            srNo :counter++,
                                            productId : productList[i].productId,
                                            petId :productList[i].petId,
                                            petOrSupplyType :productList[i].petOrSupplyType,
                                            breedOrItem :productList[i].breedOrItem,
                                            productType :productList[i].productType,
                                            price :productList[i].price,
                                            quantity : productList[i].quantity,
                                            supplyId :productList[i].supplyId,
                                            status :productList[i].status,
                                            about :productList[i].about
                                        }
                                        scope.productList.push(dataObj);
                                    }
									scope.$apply();
                                    }
                                        
                                 $("#productDetailModal").modal("hide");
                                 $("#statusMessageModal").modal("show");
                                      
                                  
							  }, function(reject){
                            });
                            
                        });
                }
                }
  })
    .filter('slice', function() {
            return function(arr, start, end) {
            if (!arr || !arr.length) { return; }
            return arr.slice(start, end);
            };
        })
});
