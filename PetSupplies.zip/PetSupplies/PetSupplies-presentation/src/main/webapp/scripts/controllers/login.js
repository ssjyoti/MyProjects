define(['angular'], function(angular) {
    'use strict';
  /**
     * @ngdoc function
     * @name petSuppliesApp.controller:OrgCtrl
     * @description
     * # OrgCtrl
     * Controller of the petSuppliesApp
     */

     angular.module('petSuppliesApp.controllers.LoginController', [])
        .controller('LoginController',['$scope', '$rootScope','AuthenticationService','UserService','$cookieStore','$http',function($scope, $rootScope,AuthenticationService,UserService,$cookieStore,$http) {
         //   UserService.getClientList($http,$scope); 
            if(sessionStorage.getItem("isLogin") == undefined) {
                $rootScope.isLogin = true;
            }
            else if(sessionStorage.getItem("isLogin") == true) {
                 $rootScope.isLogin = false;
                
            }
              $scope.login = function () {
                $scope.dataLoading = true;
            
                AuthenticationService.Login($scope.username, $scope.password,function(response) {
					if(response.status === 'Success') {
                        AuthenticationService.SetCredentials($scope.username, $scope.password,response.client,response.roleList);
                        $scope.error = response.message;
                        $scope.dataLoading = false;
                        $rootScope.isLogin =false;
                        sessionStorage.setItem("username",$scope.username); 
                        sessionStorage.setItem("clientId",response.client); 
						sessionStorage.setItem("firstName",response.firstName); 
						

                    
                    } else {
                        $scope.error = response.message;
                        $scope.dataLoading = false;
                        $rootScope.isLogin =true;
                        sessionStorage.setItem("username",$scope.username); 
                        //sessionStorage.setItem("clientId",$scope.clientId); 
                    }
                });
            };
            
            $scope.logout =function(){
                  AuthenticationService.ClearCredentials();
                   $rootScope.isLogin = true;
                
            };
            
            $scope.userRegistration = function(){
                var registrationFormData = {
                    userId :$scope.userId,
                    firstName:$scope.firstName,
                    lastName:$scope.lastName,
                    email:$scope.email,
                    contactNumber:$scope.contactNumber,
                    workdayTanant :$scope.workdayTanant
                };
                
                AuthenticationService.userRegistration(registrationFormData,function(response){
                  if(response.status === 'Success') {
                     $scope.userRegistrationInfo = response.message;
                    
                    } else {
                        $scope.userRegistrationInfo = response.message;
                    }
                });
            };
            
            $scope.resetpassword = function(){
                 AuthenticationService.resetpassword($scope.userId,function(response){
                  if(response.status === 'Success') {
                     $scope.error = response.message;
                    
                    } else {
                        $scope.error = response.message;
                    }
                });
            }
        }])
     .service('UserService', function() {
       
        
    })
    .factory('AuthenticationService',
    ['Base64', '$http', '$cookieStore', '$rootScope', '$timeout',
    function (Base64, $http, $cookieStore, $rootScope, $timeout) {
        var service = {};

        service.Login = function (username, password,callback) {
            /* Dummy authentication for testing, uses $timeout to simulate api call
             ----------------------------------------------*/
         /*  $timeout(function(){
                //var response = { success: (username === 'client' || username === 'admin' || username === 'superuser') && (password === 'client' || password === 'admin' || password === 'superuser')};
                var response = { success:true,client:'ADP',status:'Success'};
                 
                if(!response.success) {
                    response.message = 'Username,password or client is incorrect';
                   
                }
                callback(response);
            }, 1000);*/


            /* Use this for real authentication
             ----------------------------------------------*/
            $http.post('/PetSupplies/doAuthenticate', { username: username, password: password })
                .success(function (response) {
                	//alert('Result is status='+response.status);
                	//alert('message3='+response.message+' :: client='+response.client);
                    callback(response);
                });

        };
 
        service.SetCredentials = function (username, password,clientId,roleList) {
            var authdata = Base64.encode(username + ':' + password);
			var userRole;
			//roleList = ["Admin","User"];
			if(roleList.indexOf("Admin") != -1) {
				userRole = "Admin";
			} else if(roleList.indexOf("SuperAdmin") != -1){
				userRole = "SuperAdmin";
			} else {
				userRole = "User";
			}
			
            $rootScope.globals = {
                currentUser: {
                    username: username,
                    clientId: clientId,
                    authdata: authdata,
					roleId:userRole
                }
            };
            sessionStorage.setItem("username",username); 
            sessionStorage.setItem("clientId",clientId); 
			sessionStorage.setItem("roleId",userRole); 
            sessionStorage.setItem("authdata",authdata);
            
            $http.defaults.headers.common['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
            $cookieStore.put('globals', $rootScope.globals);
            sessionStorage.setItem("isLogin",true);
           
        };
 
        service.ClearCredentials = function () {
            $rootScope.globals = {};
            $cookieStore.remove('globals');
            $http.defaults.headers.common.Authorization = 'Basic ';
            sessionStorage.removeItem("username");
            sessionStorage.removeItem("clientId");
            sessionStorage.removeItem("authdata");
            sessionStorage.removeItem("isLogin");
        };
         service.userRegistration = function(registrationFormData,callback){
             
          /* $http.post('/PetSupplies/doAuthenticate', {registrationFormData})
                .success(function (response) {
                
                    callback(response);
                });*/
        };
         service.resetpassword = function(userId,callback){
             alert('Hi-'+userId);
          /* $http.post('/PetSupplies/doAuthenticate', {userId:userId})
                .success(function (response) {
                
                    callback(response);
                });*/
        }
        return service;
    }])
 
.factory('Base64', function () {
    /* jshint ignore:start */
 
    var keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
 
    return {
        encode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;
 
            do {
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
 
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
 
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }
 
                output = output +
                    keyStr.charAt(enc1) +
                    keyStr.charAt(enc2) +
                    keyStr.charAt(enc3) +
                    keyStr.charAt(enc4);
                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
            } while (i < input.length);
 
            return output;
        },
 
        decode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;
 
            // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
            var base64test = /[^A-Za-z0-9\+\/\=]/g;
            if (base64test.exec(input)) {
                window.alert("There were invalid base64 characters in the input text.\n" +
                    "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                    "Expect errors in decoding.");
            }
            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
 
            do {
                enc1 = keyStr.indexOf(input.charAt(i++));
                enc2 = keyStr.indexOf(input.charAt(i++));
                enc3 = keyStr.indexOf(input.charAt(i++));
                enc4 = keyStr.indexOf(input.charAt(i++));
 
                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;
 
                output = output + String.fromCharCode(chr1);
 
                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }
 
                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
 
            } while (i < input.length);
 
            return output;
        }
    };
 
    /* jshint ignore:end */
});
     
    
})