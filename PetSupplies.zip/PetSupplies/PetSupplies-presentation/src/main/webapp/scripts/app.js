/*jshint unused: vars */
define(['angular', 'bootstrap','controllers/main','controllers/security','controllers/login','controllers/productSearch', 'controllers/about','controllers/productDetail','controllers/userStatus','controllers/changePassword','controllers/orderManagement','Services/DataServices'
] /*deps*/ , function(angular, bootstrap,MainCtrl, SecurityCtrl,LoginController,ProductSearchCtrl,AboutCtrl,ProductDetailCtrl,UserStatusCtrl,ChangePasswordCtrl,OrderManagementCtrl,DataServices) /*invoke*/ {
    'use strict';

    /**,
     * @ngdoc overview
     * @name petSuppliesApp
     * @description
     * # petSuppliesApp
     *
     * Main module of the application.
     */
    return angular
        .module('petSuppliesApp', ['petSuppliesApp.controllers.MainCtrl',
            'petSuppliesApp.controllers.SecurityCtrl',
            'petSuppliesApp.controllers.LoginController',
            'petSuppliesApp.controllers.ProductSearchCtrl',
            'petSuppliesApp.controllers.AboutCtrl',
            'petSuppliesApp.controllers.ProductDetailCtrl',
            'petSuppliesApp.controllers.UserStatusCtrl',
            'petSuppliesApp.controllers.ChangePasswordCtrl',
            'petSuppliesApp.controllers.OrderManagementCtrl',
            'petSuppliesApp.Service.DataServices',                
            /*angJSDeps*/
            'ngCookies',
            'ngResource',
            'ngSanitize',
            'ngRoute',
            'ngAnimate',
            'ngTouch'               
        ])
    .run(['$route', function($route)  {
      $route.reload();
    }])
        .config(function($routeProvider) {
            $routeProvider
                .when('/', {
                	templateUrl: 'views/productSearch.html',
                	controller: 'ProductSearchCtrl',
                })
                .when('/admin', {
                    templateUrl: 'views/main.html',
                    controller: 'MainCtrl'
                })
                .when('/security', {
                    templateUrl: 'views/security.html',
                    controller: 'SecurityCtrl'
                })
                .when('/login', {
                    controller: 'LoginController',                   
                    hideMenus: true
                })
                .when('/petSearch', {
                	templateUrl: 'views/productSearch.html',
                	controller: 'ProductSearchCtrl',                   
                })
                .when('/about', {
                    templateUrl: 'views/about.html',
                    controller: 'AboutCtrl'
                })
                .when('/productDetail', {
                    templateUrl: 'views/productDetail.html',
                    controller: 'ProductDetailCtrl'
                })
                .when('/user-status', {
                    templateUrl: 'views/userStatus.html',
                    controller: 'UserStatusCtrl'                 
                })
                .when('/changePassword', {
                    templateUrl: 'views/changePassword.html',
                    controller: 'ChangePasswordCtrl'
                })
                .when('/manageOrder', {
                    templateUrl: 'views/orderManagement.html',
                    controller: 'OrderManagementCtrl'
                })
                .otherwise({
                    redirectTo: '/'
                });
        })
    

})

  if(navigator.appName == "Microsoft Internet Explorer"){
        alert("Best viewed in Chrome!");
    }
    
/*$(document).bind("contextmenu",function(e){
    alert('Sorry, Right Click functionality is disabled!');
e.preventDefault();

});*/

$(document).bind("keyup keydown", function(e){
    if(e.ctrlKey && e.keyCode == 80){
        alert('Sorry, Right Click functionality is disabled!');
        return false;
    }
});