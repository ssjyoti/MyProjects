/*jshint unused: vars */
require.config({
    paths: {        
        angular: '../bower_components/angular/angular.min',
        'jquery':'../bower_components/jquery/jquery.min',
        'jqueryui':'../bower_components/jqueryui/jquery-ui.min',
        'raphael':'../bower_components/raphael/raphael-min',
        'morris':'../bower_components/morris/morris-0.4.1.min',        
        'angular-animate': '../bower_components/angular-animate/angular-animate.min',
        'angular-cookies': '../bower_components/angular-cookies/angular-cookies.min',
        'angular-mocks': '../bower_components/angular-mocks/angular-mocks',
        'angular-resource': '../bower_components/angular-resource/angular-resource.min',
        'angular-route': '../bower_components/angular-route/angular-route.min',
        'angular-sanitize': '../bower_components/angular-sanitize/angular-sanitize.min',
        'angular-touch': '../bower_components/angular-touch/angular-touch.min',
        'bootstrap': '../bower_components/bootstrap/js/bootstrap.min',
        'd3': '../bower_components/d3/d3.v3.min',       
        'highcharts':'../bower_components/highcharts/highcharts',        
        'drilldown':'../bower_components/highcharts/drilldown',
         'highcharts3d':'../bower_components/highcharts/highcharts-3d',
         'jspdf':'../bower_components/jspdf/jspdf.debug',
        'highchartsMore':'../bower_components/highcharts/highcharts-more'
        
    },
    shim: {
        angular: {
            exports: 'angular'
        },
        'angular-route': [
            'angular'
        ],
        'angular-cookies': [
            'angular'
        ],
        'angular-sanitize': [
            'angular'
        ],
        'angular-resource': [
            'angular'
        ],
        'angular-animate': [
            'angular'
        ],
        'angular-touch': [
            'angular'
        ],
        'angular-mocks': {
            deps: [
                'angular'
            ],
            exports: 'angular.mock'
        },
        'jqueryui': [
            'jquery'
        ],
        'morris': [
            'jquery'
        ],
         highcharts3d: {
          exports: "highcharts3d",
          deps: ["jquery"]
        },
         highchartsMore: {
          exports: "highchartsMore",
          deps: ["jquery"]
        }
    },
    priority: [
        'angular',
        'jquery'
    ],
    packages: [

    ]
});

//http://code.angularjs.org/1.2.1/docs/guide/bootstrap#overview_deferred-bootstrap
window.name = 'NG_DEFER_BOOTSTRAP!';
require([
    'angular',
    'app',
    'angular-route',
    'angular-cookies',
    'angular-sanitize',
    'angular-resource',
    'angular-animate',
    'angular-touch',
    'jquery',
    'jqueryui',    
    'morris'
], function(angular, app, ngRoutes, ngCookies, ngSanitize, ngResource, ngAnimate, ngTouch) {
    'use strict';
    /* jshint ignore:start */
    var $html = angular.element(document.getElementsByTagName('html')[0]);
    /* jshint ignore:end */
    angular.element().ready(function() {
        angular.resumeBootstrap([app.name]);
        
    });
});
