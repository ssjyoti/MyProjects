package com.sogetinl.cg.common;

public class MailConstants {
	public static final String MAIL_SMTP_USER = "mail.smtp.user";

	public static final String MAIL_HMAILSERVER_PASS = "mail.hmailserver.password";

	public static final String MAIL_TYPE_PREFIX = "workday.PetSupplies";

	public static final String MAIL_SUBJECT = "mail.subject";

	public static final String MAIL_MESSAGE = "mail.message";

	public static final String MAIL_TO = "mail.to";

	public static final String MAIL_PROPERTIES_FILE = "petSupplies\\mail.properties";

	public static final String MAIL_TYPE_REGISTRATION = "user.registration";

	public static final String MAIL_TYPE_UPDATE = "user.update";

	public static final String MAIL_TYPE_PASSWORD_RESET = "password.reset";

	public static final String MAIL_TYPE_CHANGE_PASSWORD = "change.password";

	public static final String MAIL_CONFIG_SET_UP = "PetSupplies.workday.mail.setup";
}
