package com.sogetinl.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.sogetinl.cg.common.ClientContextManager;
import com.sogetinl.cg.common.CommonConstants;
import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.PetSuppliesReponse;
import com.sogetinl.cg.service.cart.ShoppingCartService;
import com.sogetinl.cg.vo.petVO.CartVO;
import com.sogetinl.cg.vo.petVO.OrderVO;

/**
 * jyotiranjan.paik
 */
@Controller
public class ShoppingCartController
{
   private final static Logger LOG = Logger.getLogger(ShoppingCartController.class);

   @Autowired
   private ShoppingCartService shoppingCartService;
   
   
   @RequestMapping(value = "/getShoppingCartData", method = RequestMethod.GET, headers = { "Content-type=application/json" })
   public @ResponseBody List<CartVO> getShoppingCartData(final HttpServletRequest request, final HttpServletResponse response)
   {
      LOG.info("ENTER>> ShoppingCartController::getShoppingCartData  - ");

      if (request.getSession().getAttribute(CommonConstants.CLIENT_DB_REF) != null)
      {
         ClientContextManager.setContextHolder((String) request.getSession().getAttribute(CommonConstants.CLIENT_DB_REF));
      }
      List<CartVO> searchList = null;
      try
      {
         searchList = shoppingCartService.getShoppingCartData();
      }
      catch (final PetSuppliesException e)
      {
         LOG.error("ShoppingCartController  :: getShoppingCartData>> Exceptions occurred>> " + e);
      }

      LOG.info("EXIT>> ShoppingCartController::getShoppingCartData");
      
      final Gson json = new Gson();
      LOG.info("ShoppingCartController  :: getShoppingCartData>> JSON >> Response=" + json.toJson(searchList));
     
      return searchList;

   }
   
   @RequestMapping(value = "/updateShoppingCart", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse updateShoppingCart(
         @RequestBody final CartVO cartVO, final HttpServletRequest request) {
      LOG.info("ENTER>> ShoppingCartController::updateShoppingCart  - ");
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      try {
         shoppingCartService.updateShoppingCart(cartVO);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ShoppingCartController::updateShoppingCart  - "+ e.getMessage());
         new PetSuppliesReponse("Failure", "Error occurred while updating Cart",
               cartVO.getOrderType(), cartVO.getCartId(), null, null);
      }
      List<CartVO> cartVOList = null;
      try {
         cartVOList = shoppingCartService.getShoppingCartData();
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ShoppingCartController::updateShoppingCart  - "
               + e.getMessage());
         new PetSuppliesReponse("Failure",
               "Product updated, but failed to fetch the Productr list",
               cartVO.getOrderType(), cartVO.getCartId(), null, null);
      }
      LOG.info("Exit>> ShoppingCartController::updateShoppingCart  - returning>"
            + cartVOList);
     
      return new PetSuppliesReponse("Success", "Cart updated successfully",
            cartVO.getOrderType(), cartVO.getCartId(), null, null);
   }
   
   @RequestMapping(value = "/placeOrder", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse placeOrder(
         @RequestBody final OrderVO orderVO, final HttpServletRequest request) {
      LOG.info("ENTER>> ShoppingCartController::placeOrder  - ");
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      try {
         shoppingCartService.placeOrder(orderVO);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> ShoppingCartController::placeOrder  - "+ e.getMessage());
         new PetSuppliesReponse("Failure", "Error occurred while placing Order",
               orderVO.getOrderId(), orderVO.getOrderType(), null, null);
      }
      
      LOG.info("Exit>> ShoppingCartController::placeOrder  - returning>");
     
      return new PetSuppliesReponse("Success", "Order placed successfully",
            orderVO.getOrderId(), orderVO.getOrderType(), null, null);
   }

}
