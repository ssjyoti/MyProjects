package com.sogetinl.cg.common;

import java.util.List;

import com.sogetinl.cg.vo.user.UserVO;

public class PetSuppliesReponse {
	public String status = CommonConstants.EMPTY_STRING;

	public String message = CommonConstants.EMPTY_STRING;

	public String client = CommonConstants.EMPTY_STRING;

	public String firstName = CommonConstants.EMPTY_STRING;

	public List<String> roleList = null;

	public List<UserVO> userList = null;

	public PetSuppliesReponse(final String status, final String message,
			final String firstName, final String client,
			final List<String> roleList, final List<UserVO> userList) {
		this.status = status;
		this.message = message;
		this.client = client;
		this.roleList = roleList;
		this.firstName = firstName;
		this.userList = userList;
	}

	@Override
	public String toString() {
		return "PetSuppliesReponse [status=" + status + ", message=" + message
				+ ", client=" + client + ", firstName=" + firstName
				+ ", roleList=" + roleList + ", userList=" + userList + "]";
	}

}
