package com.sogetinl.cg.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.sogetinl.cg.common.PetSuppliesException;

/**
 * jyotiranjan.paik
 */

public class PetSuppliesInitController implements Controller {
	private final static Logger LOG = Logger
			.getLogger(PetSuppliesInitController.class);

	@Override
	public ModelAndView handleRequest(final HttpServletRequest request,
			final HttpServletResponse response) throws PetSuppliesException {
		LOG.info("PetSuppliesInitController");
		return new ModelAndView("petSupplies");
	}
}
