package com.sogetinl.cg.common;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

public class MailUtility {
	private final static Logger LOG = Logger.getLogger(MailUtility.class);

	public static void main(final String[] args) {
		MailUtility.sendMail("jyotiranjan.paik@capgemini.com", "Jyoti",
				MailConstants.MAIL_TYPE_REGISTRATION);
	}

	/**
	 * @param to
	 * @param mailType
	 */
	public static void sendMail(final String to, final String name,
			final String mailType) {
		final Properties properties = getMailProperties();

		final String from = properties
				.getProperty(MailConstants.MAIL_SMTP_USER);
		final String password = properties
				.getProperty(MailConstants.MAIL_HMAILSERVER_PASS);

		final Session session = getSession(from, password, properties);

		try {
			// Create a default MimeMessage object.
			final MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));

			// Set Subject: header field
			message.setSubject(properties
					.getProperty(MailConstants.MAIL_TYPE_PREFIX + "."
							+ mailType + "." + MailConstants.MAIL_SUBJECT));

			// Now set the actual message
			message.setText(getString(
					properties.getProperty(MailConstants.MAIL_TYPE_PREFIX + "."
							+ mailType + "." + MailConstants.MAIL_MESSAGE),
					name));
			LOG.info("Mail Message>> "
					+ getString(properties
							.getProperty(MailConstants.MAIL_TYPE_PREFIX + "."
									+ mailType + "."
									+ MailConstants.MAIL_MESSAGE), name));
			// Send message
			Transport.send(message);

			LOG.info("Mail  sent successfully to...." + to);
		} catch (final MessagingException mex) {
			mex.printStackTrace();
		}
	}

	/**
	 * @param from
	 * @param password
	 * @param properties
	 * @return
	 */
	private static Session getSession(final String from, final String password,
			final Properties properties) {
		// Get the default Session object.
		final Session session = Session.getDefaultInstance(properties,
				new javax.mail.Authenticator() {
					@Override
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(from, password);// Specify
						// the
						// Username
						// and
						// the
						// PassWord
					}
				});
		return session;
	}

	private static Properties getMailProperties() {

		final Properties prop = System.getProperties();

		final InputStream input = null;
		try {
			prop.load(Thread.currentThread().getContextClassLoader()
					.getResourceAsStream(MailConstants.MAIL_PROPERTIES_FILE));
		} catch (final FileNotFoundException e) {
			LOG.error("File not  found :: Error while loading mail.properties file"
					+ e);
		} catch (final IOException e) {
			LOG.error("IO Error while loading mail.properties file" + e);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (final IOException e) {
					LOG.error("IO Error while loading mail.properties file" + e);
				}
			}
		}
		return prop;
	}

	private static String getString(final String message,
			final Object... params) {
		try {
			return MessageFormat.format(message, params);
		} catch (final MissingResourceException e) {
			return '!' + message + '!';
		}
	}

	public static boolean isMailSetup() {
		boolean isMailSetup = true;
		final Properties properties = getMailProperties();
		isMailSetup = Boolean.parseBoolean(properties
				.getProperty(MailConstants.MAIL_CONFIG_SET_UP));
		LOG.info("isMailSetup >> " + isMailSetup);
		return isMailSetup;
	}

}
