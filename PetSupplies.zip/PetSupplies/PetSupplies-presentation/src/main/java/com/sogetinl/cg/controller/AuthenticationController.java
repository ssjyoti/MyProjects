package com.sogetinl.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sogetinl.cg.common.ClientContextManager;
import com.sogetinl.cg.common.ClientName;
import com.sogetinl.cg.common.CommonConstants;
import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.PetSuppliesReponse;
import com.sogetinl.cg.domain.Person;
import com.sogetinl.cg.domain.User;
import com.sogetinl.cg.domain.UserRole;
import com.sogetinl.cg.common.UserConstants;
import com.sogetinl.cg.service.authentication.AuthenticationService;
import com.sogetinl.cg.vo.user.UserVO;
import com.google.gson.Gson;

/**
 * jyotiranjan.paik
 */
@Controller
public class AuthenticationController
{
   private final static Logger LOG = Logger.getLogger(AuthenticationController.class);

   @Autowired
   private AuthenticationService authService;

   @RequestMapping(value = "/doAuthenticate", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse authenticate(@RequestBody
   final Person person, final HttpServletRequest request)
   {
      LOG.info("ENTRY>> AuthenticationController::authenticate  - UNAME:: " + person.getUsername() + " PWD:: " + person.getPassword());
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      User user = null;
      try
      {
         user = authService.authenticate(person);
      }
      catch (final PetSuppliesException e)
      {
         LOG.error("AuthenticationController::authenticate Error - " + e);
         return new PetSuppliesReponse(UserConstants.USER_AUTHENTICATION_FAILED, e.getMessage(), CommonConstants.EMPTY_STRING, CommonConstants.EMPTY_STRING, null, null);
      }
      LOG.info("Exit>> AuthenticationController::authenticate.");
      setClientContextHolderAndSession(user, request);

      final Gson json = new Gson();
      final PetSuppliesReponse authResponse = new PetSuppliesReponse(UserConstants.USER_AUTHENTICATION_SUCCESS, UserConstants.USER_AUTHENTICATION_SUCCESS_MSG, user.getFirstName(),
            user.getClient().getClientName(), getRolesNames(user), null);
      LOG.info("AuthenticationController  :: Roles ::: " + user.getRoles().toString());
      LOG.info("AuthenticationController  :: authenticate>> JSON >> authResponse=" + json.toJson(authResponse));
      return authResponse;
   }

   private void setClientContextHolderAndSession(final User user, final HttpServletRequest request)
   {
      if (null != user.getClient())
      {
         if (ClientName.ASIAPAC.getValue().equalsIgnoreCase(user.getClient().getClientName()))
         {

            ClientContextManager.setContextHolder(ClientName.ASIAPAC.getValue());
            LOG.info("AuthenticationController::setClientContextHolderAndSession>>." + ClientName.ASIAPAC);
         }
         else if (ClientName.US.getValue().equalsIgnoreCase(user.getClient().getClientName()))
         {
            LOG.info("AuthenticationController::setClientContextHolderAndSession>>." + ClientName.US);
            ClientContextManager.setContextHolder(ClientName.US.getValue());
         }
         else if (ClientName.ANZ.getValue().equalsIgnoreCase(user.getClient().getClientName()))
         {
            LOG.info("AuthenticationController::setClientContextHolderAndSession>>." + ClientName.ANZ);
            ClientContextManager.setContextHolder(ClientName.ANZ.getValue());
         }
         else if (ClientName.UK.getValue().equalsIgnoreCase(user.getClient().getClientName()))
         {
            LOG.info("AuthenticationController::setClientContextHolderAndSession>>." + ClientName.UK);
            ClientContextManager.setContextHolder(ClientName.UK.getValue());
         }
         else if (ClientName.SA.getValue().equalsIgnoreCase(user.getClient().getClientName()))
         {
            LOG.info("AuthenticationController::setClientContextHolderAndSession>>." + ClientName.SA);
            ClientContextManager.setContextHolder(ClientName.SA.getValue());
         }
         request.getSession().setAttribute(CommonConstants.CLIENT_DB_REF, user.getClient().getClientName());
      }
      else
      {
         //ClientContextHolder.setClientName(ClientName.XRAY);
         ClientContextManager.setContextHolder(ClientName.PetSupplies.getValue());
      }
      request.getSession().setAttribute(CommonConstants.SESSION_USER, user);
   }

   private List<String> getRolesNames(final User user)
   {
      final List<String> roles = new ArrayList<String>();
      if (user.getUserroles() != null)
      {
         LOG.info("Role size == " + user.getUserroles().size());
         LOG.info("Role size II == " + user.getRoles().size());
      }
      int i = 0;
      for (final UserRole userole : user.getUserroles())
      {
         LOG.info("userole " + (++i) + ": " + userole.getRoleName());
         LOG.info("userole II" + (++i) + ": " + userole.getRole().getRoleName());
         roles.add(userole.getRole().getRoleName());
      }
      if (roles.size() > 0)
         return roles;
      for (final String ur : user.getRoles())
      {
         LOG.info("Role-" + (++i) + ": " + ur);
         roles.add(ur);
      }

      return roles;
   }
   
   @RequestMapping(value = "/getUserListForAdmin", method = RequestMethod.GET, headers = { "Content-type=application/json" })
   public @ResponseBody List<UserVO> getUserListForAdmin(
         final HttpServletRequest request) {
      LOG.info("ENTER>> AuthenticationController::getUserListForAdmin  - ");

      final User user = (User) request.getSession().getAttribute(
            CommonConstants.SESSION_USER);
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      List<UserVO> userVOList = null;
      try {
         userVOList = authService.getUserListForAdmin(user);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> AuthenticationController::getUserListForAdmin  - "
               + e.getMessage());
      }
      LOG.info("Exit>> AuthenticationController::getUserListForAdmin  - returning>"
            + userVOList);
      return userVOList;
   }
   
   @RequestMapping(value = "/updateUser", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse updateUser(
         @RequestBody final UserVO userVO, final HttpServletRequest request) {
      LOG.info("ENTER>> AuthenticationController::updateUser  - ");
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);
      try {
         authService.updateUser(userVO);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> AuthenticationController::updateUser  - "
               + e.getMessage());
         new PetSuppliesReponse("Failure", "Error occurred while updating user",
               userVO.getFirstName(), userVO.getClientName(), null, null);
      }
      List<UserVO> userVOList = null;
      final User user = (User) request.getSession().getAttribute(
            CommonConstants.SESSION_USER);
      try {
         userVOList = authService.getUserListForAdmin(user);
      } catch (final PetSuppliesException e) {
         LOG.info("EXCEPTION>> AuthenticationController::getUserListForAdmin  - "
               + e.getMessage());
         new PetSuppliesReponse("Failure",
               "User updated, but failed to fetch the user list",
               userVO.getFirstName(), userVO.getClientName(), null, null);
      }
      LOG.info("Exit>> AuthenticationController::updateUser  - returning>"
            + userVOList);
      final Gson json = new Gson();
      LOG.info("AuthenticationController  :: updateUser>> JSON >> "
            + json.toJson(new PetSuppliesReponse("Success",
                  "User updated successfully", userVO.getFirstName(),
                  userVO.getClientName(), null, userVOList)));
      return new PetSuppliesReponse("Success", "User updated successfully",
            userVO.getFirstName(), userVO.getClientName(), null, userVOList);
   }
   
   @RequestMapping(value = "/changePassword", method = RequestMethod.POST, headers = { "Content-type=application/json" })
   public @ResponseBody PetSuppliesReponse changePassword(
         @RequestBody final UserVO userVO, final HttpServletRequest request) {
      LOG.info("ENTER>> AuthenticationController::changePassword  - ");
      ClientContextManager.setContextHolder(CommonConstants.PetSupplies_DB_REF);

      final User user = (User) request.getSession().getAttribute(
            CommonConstants.SESSION_USER);
      int updateCnt = 0;
      String statusMessage=null;
      try {
         
      final User userAuth ;
      final Person person =  new Person();
      person.setUsername(userVO.getUserName());
      person.setPassword(userVO.getPassword());
      person.setClient(userVO.getClientName());
      userAuth = authService.authenticate(person);
      statusMessage = userAuth.getComment();
      if(!((userVO.getNewPassword()).equals(userVO.getCnfNewPassword()))){
         throw new PetSuppliesException();
         //userAuth.setComment("New Password and Confirm Password is invalid !");
      }
      
      updateCnt = authService
               .changePassword(user.getUserName(), userVO.getNewPassword());
         
      } catch (final PetSuppliesException e) {
         LOG.error("AuthenticationController::changePassword Error - " + e);
         return new PetSuppliesReponse(UserConstants.CHANGE_PASSWORD_FAILED,
               UserConstants.CHANGE_PASSWORD_FAILED_MSG,
               CommonConstants.EMPTY_STRING, CommonConstants.EMPTY_STRING,
               null, null);
      }
      /*if (MailUtility.isMailSetup() && updateCnt > 0) {
         // Send email to user
         MailUtility.sendMail(user.getEmail(), user.getUserName(),
               MailConstants.MAIL_TYPE_CHANGE_PASSWORD);
      }*/
      LOG.info("Exit>> AuthenticationController::changePassword  - ");
      return new PetSuppliesReponse(UserConstants.CHANGE_PASSWORD_SUCCESS,
            UserConstants.CHANGE_PASSWORD_SUCCESS_MSG,
            CommonConstants.EMPTY_STRING, CommonConstants.EMPTY_STRING,
            null, null);
   }

}
