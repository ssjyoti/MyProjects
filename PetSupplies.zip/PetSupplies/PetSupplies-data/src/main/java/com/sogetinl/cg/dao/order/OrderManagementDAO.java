
 package com.sogetinl.cg.dao.order;

import com.sogetinl.cg.common.PetSuppliesException;
import java.util.List;
import com.sogetinl.cg.domain.Orders;

public interface OrderManagementDAO
{
   public List<Orders> findAll() throws PetSuppliesException;

   public List<Orders> findBySearchCriteria(String criteriaString) throws PetSuppliesException;
   
}

