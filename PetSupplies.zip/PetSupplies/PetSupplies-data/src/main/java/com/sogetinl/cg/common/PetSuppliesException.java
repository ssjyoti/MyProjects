package com.sogetinl.cg.common;

public class PetSuppliesException extends Exception {

	private static final long serialVersionUID = 1L;

	public PetSuppliesException() {
		super();
	}

	public PetSuppliesException(final String message) {
		super(message);
	}

	public PetSuppliesException(final Throwable cause) {
		super(cause);
	}

}
