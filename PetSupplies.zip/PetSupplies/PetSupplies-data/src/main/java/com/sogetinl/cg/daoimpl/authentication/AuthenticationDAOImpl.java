/**
 *
 */
package com.sogetinl.cg.daoimpl.authentication;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sogetinl.cg.dao.authentication.AuthenticationDAO;
import com.sogetinl.cg.domain.Client;
import com.sogetinl.cg.domain.User;
import com.sogetinl.cg.common.PetSuppliesException;

/**
 * @author jyotiranjan.paik
 */
@Repository
@Transactional
public class AuthenticationDAOImpl implements AuthenticationDAO {

	private final static Logger LOG = Logger
			.getLogger(AuthenticationDAOImpl.class);

	@PersistenceContext(unitName = "PetSuppliesUnit")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public User authenticate(final String userName, final String pwd)
			throws PetSuppliesException {
		LOG.info("getting User from credentials");

		final List<User> results = entityManager.createQuery(
				"select us from User us where us.userName='" + userName.trim()
						+ "' and us.password='" + pwd.trim()
						+ "' and us.status='ACTIVE'").getResultList();
		User user = new User();
		try {

			if (results != null & results.size() > 0) {
				LOG.info("Users obtained=" + results.size());
				user = results.get(0);// obj;
			} else {
				throw new NoResultException();
			}
		} catch (final NoResultException nre) {
			user.setComment("Invalid login details");// No Such User");
		} catch (final NonUniqueResultException nure) {
			user.setComment("More than 1 record for User");
		}

		LOG.info("Returning : " + user);
		return user;
	}

	@SuppressWarnings("unchecked")
   @Override
   public List<User> getUserListForAdmin(final String userName,
         final Client client) throws PetSuppliesException {
	   List<User> results = entityManager
            .createQuery("select us from User us").getResultList();
      if (results != null & results.size() > 0) {
         LOG.info("getUserList::Users obtained=" + results.size());
      } else if (results != null) {
         results = new ArrayList<User>();
      }
      LOG.info("getUserListForAdmin::Returning : " + results);

      return results;
   }

	@Override
   public User getUser(String userName, String email) throws PetSuppliesException {
      final User user = (User) entityManager
            .createQuery(
                  "select us from User us where us.userName=:userName  and us.email=:email ")
            .setParameter("userName", userName)
            .setParameter("email", email).getSingleResult();
      return user;
   }
	
	@Override
   public void updateUser(final User user) throws PetSuppliesException {
      LOG.info("persisting Organization type instance");
      LOG.info("saveOrUpdate OrganizationExceptionAudit instance");
      try {
         entityManager.merge(user);
         entityManager.flush();
         LOG.info("saveOrUpdate successful");
      } catch (final Exception re) {
         LOG.error("saveOrUpdate failed", re);
         throw new PetSuppliesException(re.getMessage());
      }
   }
	
	@Override
   public int changePassword(final String userName, final String password)
         throws PetSuppliesException {
      LOG.info("changePassword  enter...");
      final Query query = entityManager
            .createQuery("UPDATE User user SET user.password = :password, user.isPwdReset= :isPwdReset "
                  + "WHERE user.userName= :userName");// id= :id");
      query.setParameter("password", password);
      query.setParameter("userName", userName);// "id", userId);
      query.setParameter("isPwdReset", true);
      final int updateCount = query.executeUpdate();
      if (updateCount > 0) {
         LOG.info("changePassword  done...");
      }
      return updateCount;
   }
	
}
