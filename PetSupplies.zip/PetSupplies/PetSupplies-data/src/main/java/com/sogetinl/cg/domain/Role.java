package com.sogetinl.cg.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Entity implementation class for Entity: Role
 */
@Entity
@Table(name = "role")
public class Role implements Serializable {

	/**
	 *
	 */
	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 6972701062586482149L;

	/*
	 * @GeneratedValue(strategy = GenerationType.AUTO)
	 * 
	 * @Column(name = "ID") private Integer id;
	 */

	@Id
	@Column(name = "ROLE_NAME")
	private String roleName;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "role")
	private List<UserRole> roleusers = new ArrayList<UserRole>();

	/*
	 * public Integer getId() { return this.id; } public void setId(final
	 * Integer id) { this.id = id; }
	 */

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(final String roleName) {
		this.roleName = roleName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("Role [roleName=");
		builder.append(roleName);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the roleusers
	 */
	public List<UserRole> getRoleusers() {
		return roleusers;
	}

	/**
	 * @param roleusers
	 *            the roleusers to set
	 */
	public void setRoleusers(final List<UserRole> roleusers) {
		this.roleusers = roleusers;
	}

}
