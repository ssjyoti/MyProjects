package com.sogetinl.cg.common;

import java.lang.reflect.Field;

import org.apache.log4j.Logger;

public class PetSuppliesUtil {
	private final static Logger LOG = Logger.getLogger(PetSuppliesUtil.class);

	private PetSuppliesUtil() {
		super();
	}

	public static boolean isBlankObject(final Object obj) {
		LOG.info("PetSuppliesUtil >>> isBlankObject >> Object Name>>> "
				+ obj.getClass().getName());
		boolean isBlank = false;
		try {
			for (final Field f : obj.getClass().getFields()) {
				f.setAccessible(true);
				if (f.get(obj) == null) {
					isBlank = true;
				}
			}
		} catch (final SecurityException e) {
			LOG.error("PetSuppliesUtil >>> isBlankObject >> SecurityException>>> " + e);
		} catch (final IllegalArgumentException e) {
			LOG.error("PetSuppliesUtil >>> isBlankObject >> IllegalArgumentException>>> "
					+ e);
		} catch (final IllegalAccessException e) {
			LOG.error("PetSuppliesUtil >>> isBlankObject >> IllegalAccessException>>> "
					+ e);
		}
		return isBlank;
	}
}
