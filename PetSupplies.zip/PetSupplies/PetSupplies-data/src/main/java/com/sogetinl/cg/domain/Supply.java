package com.sogetinl.cg.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "supply")
public class Supply implements Serializable
{

   /**
    *
    */
   private static final long serialVersionUID = -8260424354311764871L;

   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   @Column(name = "SUPPLY_ID")
   private Integer supplyId;

   @Column(name = "SUPPLY_TYPE")
   private String supplyType;

   @Column(name = "ITEM")
   private String item;

   @Column(name = "ABOUT")
   private String about;
      
   @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "supply")
   private Set<Product> productList = new HashSet<Product>();

   /**
    * @return the supplyId
    */
   public Integer getSupplyId()
   {
      return supplyId;
   }

   /**
    * @param supplyId the supplyId to set
    */
   public void setSupplyId(final Integer supplyId)
   {
      this.supplyId = supplyId;
   }

   /**
    * @return the supplyType
    */
   public String getSupplyType()
   {
      return supplyType;
   }

   /**
    * @param supplyType the supplyType to set
    */
   public void setSupplyType(final String supplyType)
   {
      this.supplyType = supplyType;
   }

   /**
    * @return the item
    */
   public String getItem()
   {
      return item;
   }

   /**
    * @param item the item to set
    */
   public void setItem(final String item)
   {
      this.item = item;
   }

   /**
    * @return the proudctList
    */
   public Set<Product> getProductList()
   {
      return productList;
   }

   /**
    * @param productList the productList to set
    */
   public void setProductList(final Set<Product> productList)
   {
      this.productList = productList;
   }
   
   /**
    *@return the about
    */
   public String getAbout()
   {
      return about;
   }

   /**
    * @param about the about to set
    */
   public void setAbout(String about)
   {
      this.about = about;
   }

   @Override
   public String toString()
   {
      StringBuilder builder = new StringBuilder();
      builder.append("Supply [supplyId=");
      builder.append(supplyId);
      builder.append(", supplyType=");
      builder.append(supplyType);
      builder.append(", item=");
      builder.append(item);
      builder.append(", about=");
      builder.append(about);
      builder.append(", productList=");
      builder.append(productList);
      builder.append("]");
      return builder.toString();
   }

}
