package com.sogetinl.cg.dao.authentication;

import java.util.List;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.domain.Client;
import com.sogetinl.cg.domain.User;

public interface AuthenticationDAO {
	
	public User authenticate(String userName, String pwd) throws PetSuppliesException;
	
	public List<User> getUserListForAdmin(String userName, Client client)
         throws PetSuppliesException;
	
	public User getUser(final String userName, final String email)
         throws PetSuppliesException;
	
	public void updateUser(final User user) throws PetSuppliesException;
	
	public int changePassword(String userName, String password) throws PetSuppliesException;


}
