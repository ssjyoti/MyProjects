
package com.sogetinl.cg.daoimpl.order;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.dao.order.OrderManagementDAO;
import com.sogetinl.cg.domain.Orders;

@Repository
@Transactional
public class OrderManagementDAOImpl implements OrderManagementDAO
{

   private final static Logger LOG = Logger.getLogger(OrderManagementDAOImpl.class);

   @PersistenceContext(unitName = "PetSuppliesUnit")
   private EntityManager entityManager;

   @SuppressWarnings("unchecked")
   @Override

   public List<Orders> findAll() throws PetSuppliesException
   {

      LOG.info("getting All Orders");
      try
      {
         final Query query = entityManager.createQuery("from Orders");
         final List<Orders> orders = query.getResultList();
         LOG.info("Order@OrderManagementDAO: Returning " + orders.size());
         return orders;
      }
      catch (final Exception re)
      {
         LOG.error("get failed", re);
re.printStackTrace();
         throw new PetSuppliesException(re.getMessage());
      }

   }

   @SuppressWarnings("unchecked")
   @Override
   public List<Orders> findBySearchCriteria(final String criteriaString) throws PetSuppliesException
   {
      LOG.info("getting All Orders by Criteria ");
      try
      {
         final List<Orders> orders = entityManager.createQuery("select us from Order od where od.orderId='%" + criteriaString + "%' or pd.purchaseOrder='%" + criteriaString + "%'").getResultList();

         return orders;
      }
      catch (final Exception re)
      {
         LOG.error("get failed", re);

         throw new PetSuppliesException(re.getMessage());
      }

   }
   
   @Override
   public void updateOrder(final Orders orders) throws PetSuppliesException {
        LOG.info("saveOrUpdate Product");
      try {
         entityManager.merge(orders);
         entityManager.flush();
         LOG.info("saveOrUpdate successful");
      } catch (final Exception re) {
         LOG.error("saveOrUpdate failed", re);
         throw new PetSuppliesException(re.getMessage());
      }
   }


}
