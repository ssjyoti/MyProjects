
package com.sogetinl.cg.daoimpl.product;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.dao.product.ProductDAO;
import com.sogetinl.cg.domain.Product;

@Repository
@Transactional
public class ProductDAOImpl implements ProductDAO
{

   private final static Logger LOG = Logger.getLogger(ProductDAOImpl.class);

   @PersistenceContext(unitName = "PetSuppliesUnit")
   private EntityManager entityManager;

   @SuppressWarnings("unchecked")
   @Override

   public List<Product> findAll() throws PetSuppliesException
   {

      LOG.info("getting All Products");
      try
      {
         final Query query = entityManager.createQuery("from Product");
         final List<Product> products = query.getResultList();
         LOG.info("Product@PetSearchDAO: Returning " + products.size());
         return products;
      }
      catch (final Exception re)
      {
         LOG.error("get failed", re);

         throw new PetSuppliesException(re.getMessage());
      }

   }

   @SuppressWarnings("unchecked")
   @Override
   public List<Product> findBySearchCriteria(final String criteriaString) throws PetSuppliesException
   {
      LOG.info("getting All Products by Criteria ");
      try
      {
         final List<Product> products = entityManager.createQuery("select us from Product pd where pd.petType='%" + criteriaString + "%' or pd.supplyType='%" + criteriaString + "%'").getResultList();

         return products;
      }
      catch (final Exception re)
      {
         LOG.error("get failed", re);

         throw new PetSuppliesException(re.getMessage());
      }

   }
   
   @Override
   public void updateProduct(final Product product) throws PetSuppliesException {
        LOG.info("saveOrUpdate Product");
      try {
         entityManager.merge(product);
         entityManager.flush();
         LOG.info("saveOrUpdate successful");
      } catch (final Exception re) {
         LOG.error("saveOrUpdate failed", re);
         throw new PetSuppliesException(re.getMessage());
      }
   }

}
