package com.sogetinl.cg.common;


import org.apache.log4j.Logger;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

public class ClientRoutingDataSource extends AbstractRoutingDataSource {
	private final static Logger LOG = Logger
			.getLogger(ClientRoutingDataSource.class);

	@Override
	protected Object determineCurrentLookupKey() {
		// TO-DO return the client info from the session
		LOG.info("IN ClientRoutingDataSource :: "
				+ ClientContextHolder.getClientName());
		return ClientContextHolder.getClientName();
	}

	@Override
	public java.util.logging.Logger getParentLogger() {
		// TODO Auto-generated method stub
		return null;
	}
}
