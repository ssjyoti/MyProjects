package com.sogetinl.cg.common;

import java.util.ArrayList;
import java.util.List;

public class CommonConstants {
	public static final String PARENT_SEC_NAME = "Security";

	public static final String START_NAME = "Start";

	public static final String STANDARD_ORG_TYPE = "Standard";

	public static final String SEPARATOR = "~|~";

	public static final String SEPARATOR_SPLIT = "~\\|~";

	public static final String ORG_EXCEPTION_SEVERITY_TYPE1 = "Critical";

	public static final String ORG_EXCEPTION_SEVERITY_TYPE2 = "Warning";

	public static final String ORG_AUDIT_EXCEPTION_TYPE1 = "OrganizationException";

	public static final String ORG_AUDIT_EXCEPTION_TYPE2 = "OrganizationTypeException";

	public static final String UTILIZATION_IN_USE = "In Use";

	public static final String SESSION_USER = "User";

	public static final String FUN_AREA_FOR_DOMAIN_SEC_POLICY = "FunAreaforDomainSecPolicy";

	public static final String FUN_AREA_FOR_BUS_PRC_TYPE = "FunAreaforBusPrcType";

	public static final String YES_STR_VAL = "Yes";

	public static final String ALL_STR_VAL = "All";

	public static final String NO_STR_VAL = "No";

	public static final String PetSupplies_DB_REF = "PetSupplies";

	public static final String CLIENT_DB_REF = "clName";

	public static final String STAFFING_SUMMARY_TEXT = "Summary";

	public static final String STAFFING_TIME_TYPE_FULL = "Full time";

	public static final String ESS_TEXT = "Employee Self Service";

	public static final String MSS_TEXT = "Manager Self Service";

	public static final String DAYS_STR_VAL = "Days";

	public static final String HOURS_STR_VAL = "Hours";

	public static final String MONTHLY_STR_VAL = "Monthly";

	public static final String SEMIMONTHLY_STR_VAL = "Semi-monthly";

	public static final String BIWEEKLY_STR_VAL = "Bi-weekly (Mon-Sun)";

	public static final String ANNUAL_STR_VAL = "Annual";

	public static final String ENTRY_OPTION_TIME_OFF = "Enter through Time Off Only";

	public static final String ENTRY_OPTION_TIME_TRACKING = "Enter through Time Tracking Only";

	public static final String ENTRY_OPTION_BOTH = "Entry through Time Tracking and Time Off";

	public static final String TIME_OFF_PLANS_FIELD = "timeOffPlan";

	public static final String TIME_OFF_PLAN_COUNTRY_FIELD = "timeOffPlanCountry";

	public static final String LEAVE_OF_ABSENCE_COUNTRY_FIELD = "countryRegion";

	public static final String LEAVE_INACTIVE_FIELD = "inactive";
	public static final String LEAVE_UNITOFTIME_FIELD = "unitOfTime";
	public static final String LEAVE_TRACK_BALANCE_FIELD = "trackBalance";
	public static final String LEAVE_WORKERTYPE_FIELD = "workerType";
	public static final String LEAVE_IMPACT_FIELD = "leaveImpact";
	public static final String LEAVE_DNAEMP_TO_REQ_FIELD = "dNAEmpToRequest";

	public static final String LEAVE_OF_ABSENCE_ALL_WORKERS = "All Workers";

	public static final String PERIODIC_SCHDEULE_FIELD = "periodSchedule";

	public static final String TIME_PLAN_TYPE_FIELD = "timeOffPlanType";

	public static final String TIME_OFF_PLAN_STRING = "Time Off Plans";

	public static final String LEAVE_COUNTRY_REGION_FIELD = "countryRegion";

	public static final String LEAVE_FAMILY_FIELD = "leaveFamily";

	public static final String LEAVE_TYPE_CATEGORY_FIELD = "leaveTypeCategory";

	public static final String LEAVE_TYPE_FIELD = "leaveType";

	public static final String ABSENCE_ACCRUAL_EFFECT = "Absence Accrual Effect";

	public static final String BENEFIT_EFFECT = "Benefit Effect";

	public static final String SABBATICAL_EFFECT = "Sabbatical Effect";

	public static final String TENURE_EFFECT = "Tenure Effect";

	public static final String INACTIVATE_EMPLOYEE = "Inactivate Employee";

	public static final String PAYROLL_EFFECT = "Payroll Effect";

	public static final String STOCK_VESTING_EFFECT = "Stock Vesting Effect";

	public static final String SEARCH_TYPE_DEFAULT = "default";

	public static final String JOB_SET_UP_JOB_NAME = "jobSetupJob";

	public static final String BP_CONFIG_JOB_NAME = "bpConfigJob";

	public static final String MANIFEST_JOB_NAME = "manifestJob";
	
	public static final String BENEFITS_JOB_NAME = "benefitsJob";

	public static final String JOB_MANAGEMENT_TEXT = "Job Management";

	public static final String POSITION_MANAGEMENT_TEXT = "Position Management";

	public static final String POSITION_FILLED_TEXT = "Filled";

	public static final String POSITION_UNFILLED_TEXT = "Unfilled";

	public static final String BP_FRAMEWORK_TEXT = "Business Process";

	public static final String TOTAL_BP_TEXT = "Total BP:";

	public static final String NUMBER_OF_ORGS_TEXT = "No.of Orgs :";

	// Job Set up
	public static final String JOB_SET_UP_DIFFICULTY_EASY = "Easy";

	public static final String JOB_SET_UP_DIFFICULTY_HARD = "Hard";

	public static final String JOB_SET_UP_DIFFICULTY_DIFFICULT = "Difficult";

	public static final String JOB_PROFILE_MGMT_LEVEL_FIELD = "managmentLevel";

	public static final String JOB_PROFILE_COMP_GRADE_FIELD = "compensationGrade";

	public static final String JOB_PROFILE_PAY_RATE_FIELD = "payRateType";

	// BP Config Constants

	public static final String BP_CONFIG_INI_EXCLUDED = "Initiator Excluded";

	public static final String BP_CONFIG_PRI_APPR_EXCLUDED = "Prior  Approvers Excluded";

	public static final String BP_CONFIG_WORK_EVENT_EXCLUDED = "Worker for event Excluded";

	public static final String BP_CONFIG_COMPLETION = "Completion";

	public static final String BP_CONFIG_OPTIONAL = "Optional";

	// Reporting constants

	public static final String REPORT_CATEGORY_CUSTOM = "Custom Reports";

	public static final String REPORT_CATEGORY_STD = "Standard Reports";

	public static final String REPORT_CATEGORY_CUSTOM_KEY = "customReports";

	public static final String REPORT_CATEGORY_STD_KEY = "standardReports";

	public static final String REPORT_USED = "Used";

	public static final String REPORT_UNUSED = "Unused";

	public static final String REPORT_FIELD_CALCULATED = "Calculated";

	public static final String REPORT_FIELD_DELIVERED = "Workday Delivered";

	public static final List<String> MODULE_ORDER = new ArrayList<String>();

	// Access Management Constants
	public static final String AM_KY_TOTAL = "totalLogins";

	public static final String AM_KY_CH_PASS = "changePasswords";

	public static final String AM_KY_PHONE = "phoneLogins";

	public static final String AM_KY_TAB = "tabLogins";

	public static final String AM_KY_DESKTOP = "desktopLogins";

	public static final String AM_KY_INVALID = "invalidLogins";

	public static final String AM_MGMT_PHONE_LOGINS = "Phone";

	public static final String AM_MGMT_TABLET_LOGINS = "Tablet";

	public static final String AM_MGMT_DESKTOP_LOGINS = "Desktop";

	public static final String EMPTY_STRING = "";
	

	static {
		MODULE_ORDER.add("HR Core");
		MODULE_ORDER.add("Payroll");
		MODULE_ORDER.add("Financials");
		MODULE_ORDER.add("Absence");
		MODULE_ORDER.add("Talent");
		MODULE_ORDER.add("Time Tracking");
		MODULE_ORDER.add("Compensation");
		MODULE_ORDER.add("Benefits");
	}

}
