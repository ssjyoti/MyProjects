package com.sogetinl.cg.vo.user;

public enum UserRole {
	SUPERUSER("SUPERUSER"), ADMIN("ADMIN"), USER("USER");

	private String role;

	private UserRole(final String role) {
		this.role = role;
	}

	public String getValue() {
		return role;
	}

}
