package com.sogetinl.cg.common;

public class UserConstants {
	public static final String USER_AUTHENTICATION_SUCCESS = "Success";

	public static final String USER_AUTHENTICATION_FAILED = "Failed";

	public static final String USER_AUTHENTICATION_SUCCESS_MSG = "Authenticated successfully..";

	public static final String USER_LOGOFF_SUCCESS_MSG = "Logged out successfully..";

	public static final String USER_REGISTRATION_SUCCESS = "Success";

	public static final String USER_REGISTRATION_FAILED = "Failed";

	public static final String USER_REGISTRATION_DUPLICATE = "Duplicate";

	public static final String USER_REGISTRATION_SUCCESS_MSG = "User Registration done successfully.";

	public static final String USER_REGISTRATION_FAILED_MSG = "User registration failed. Error occurred while user registration..";

	public static final String USER_REGISTRATION_DUPLICATE_MSG = "User already exists.";

	public static final String CLIENT_REGISTRATION_SUCCESS = "Success";

	public static final String CLIENT_REGISTRATION_FAILED = "Failed";

	public static final String CLIENT_REGISTRATION_DUPLICATE = "Duplicate";

	public static final String CLIENT_REGISTRATION_SUCCESS_MSG = "Client Registration done successfully.";

	public static final String CLIENT_REGISTRATION_FAILED_MSG = "Client Registration Failed. Error occurred while client registration..";

	public static final String CLIENT_REGISTRATION_DUPLICATE_MSG = "Client Registration Failed. Client already exists.";

	public static final String CLIENT_DELETION_SUCCESS = "Success";

	public static final String CLIENT_DELETION_FAILED = "Failed";

	public static final String CLIENT_DELETION_SUCCESS_MSG = "Client Deletion Done Successfully.";

	public static final String CLIENT_DELETION_FAILED_MSG = "Error occurred while deleting client. Retry..";

	public static final String USER_UPDATE_SUCCESS = "Success";

	public static final String USER_UPDATE_FAILED = "Failed";

	public static final String RESET_PASSWORD_SUCCESS = "Success";

	public static final String RESET_PASSWORD_FAILED = "Failed";

	public static final String RESET_PASSWORD_SUCCESS_MSG = "Reset Password done successfully.";

	public static final String RESET_PASSWORD_FAILED_MSG = "Error occurred whilie user reset password..";

	public static final String CHANGE_PASSWORD_SUCCESS = "Success";

	public static final String CHANGE_PASSWORD_FAILED = "Failed";

	public static final String CHANGE_PASSWORD_SUCCESS_MSG = "Password changed successfully.";

	public static final String CHANGE_PASSWORD_FAILED_MSG = "Wrong Password";
	
	public static final String PRODUCT_UPDATE_SUCCESS = "Product saved Successfully";
}
