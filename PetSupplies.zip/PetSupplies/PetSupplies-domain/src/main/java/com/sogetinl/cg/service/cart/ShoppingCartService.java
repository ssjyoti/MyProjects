package com.sogetinl.cg.service.cart;

import java.util.List;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.vo.petVO.CartVO;
import com.sogetinl.cg.vo.petVO.OrderVO;

public interface ShoppingCartService
{
   public List<CartVO> getShoppingCartData() throws PetSuppliesException;
   
   public String updateShoppingCart(CartVO cartVO) throws PetSuppliesException;
   
   public String placeOrder(OrderVO orderVO) throws PetSuppliesException;
   
}
