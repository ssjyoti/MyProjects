package com.sogetinl.cg.vo.user;

public enum UserRoleVO {
	SUPERUSER("SUPERUSER"), ADMIN("ADMIN"), USER("USER");

	private String role;

	private UserRoleVO(final String role) {
		this.role = role;
	}

	public String getValue() {
		return role;
	}

}
