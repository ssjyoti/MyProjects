package com.sogetinl.cg.serviceimpl.product;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.UserConstants;
import com.sogetinl.cg.dao.product.ProductDAO;
import com.sogetinl.cg.domain.Pet;
import com.sogetinl.cg.domain.Product;
import com.sogetinl.cg.domain.Supply;
import com.sogetinl.cg.service.product.ProductService;
import com.sogetinl.cg.vo.petVO.ProductVO;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService
{

   private final static Logger LOG = Logger.getLogger(ProductServiceImpl.class);

   @Autowired
   private ProductDAO productDAO;

   @Override
   public List<ProductVO> getProductSearchData() throws PetSuppliesException
   {
      LOG.info("ProductSearchServiceImpl >> getProductSearchData >> ENTER");
      ProductVO productVO;
      List<Product> products = productDAO.findAll();
      List<ProductVO> searchResults = new ArrayList<ProductVO>();
      try
      {
         for (Product prod : products)
         {
            productVO = new ProductVO();
            productVO.setProductId(prod.getProductId());
            productVO.setProductType(prod.getProductType());
            productVO.setQuantity(prod.getQuantity());
            productVO.setPrice(prod.getPrice());
            productVO.setStatus(prod.getStatus());
            if (0 != prod.getPet().getPetId())
            {
               productVO.setPetId(prod.getPet().getPetId());
               productVO.setBreedOrItem(prod.getPet().getBreed());
               productVO.setPetOrSupplyType(prod.getPet().getPetType());
               productVO.setAbout(prod.getPet().getAbout());
            }
            else if (0 != prod.getSupply().getSupplyId())
            {
               productVO.setSupplyId(prod.getSupply().getSupplyId());
               productVO.setBreedOrItem(prod.getSupply().getItem());
               productVO.setPetOrSupplyType(prod.getSupply().getSupplyType());
               productVO.setAbout(prod.getSupply().getAbout());
            }

            searchResults.add(productVO);
         }

      }
      catch (Exception e)
      {
         LOG.info("ProductSearchService >> Exception >> EXIT"+e);
      }

      LOG.info("DashboardService >> getDashboardData >> EXIT");
      return searchResults;

   }
   
   @Override
   public String updateProduct(final ProductVO productVO) throws PetSuppliesException {
      LOG.info("ProductServiceImpl>>> updateProduct productVO>>  "
            + productVO.toString());
      final Product prod = new Product();
      final Pet pet = new Pet();
      final Supply supply = new Supply();
      
      pet.setPetId(productVO.getPetId());
      pet.setPetType(productVO.getPetOrSupplyType());
      pet.setBreed(productVO.getBreedOrItem());
      pet.setAbout(productVO.getAbout());
      
      supply.setSupplyId(productVO.getSupplyId());
      supply.setSupplyType(productVO.getPetOrSupplyType());
      supply.setItem(productVO.getBreedOrItem());
      supply.setAbout(productVO.getAbout());
      
      BeanUtils.copyProperties(productVO, prod);
      
      prod.setPet(pet);
      prod.setSupply(supply);
      LOG.info("ProductServiceImpl>>> updateProduct  product>>  "
            + prod.toString());
      productDAO.updateProduct(prod);
      return UserConstants.PRODUCT_UPDATE_SUCCESS;
   }

}
