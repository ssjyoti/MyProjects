package com.sogetinl.cg.vo.petVO;

import java.io.Serializable;

public class OrderVO implements Serializable
{

   /** * indicates/is used for. */

   private static final long serialVersionUID = -7605905395760106739L;

   private String orderId;
   
   private String cartId;

   private String orderType;

   private String orderQuantity;

   private String orderPrice;

   private String orderDate;

   private String purchaseOrder;

   private String orderStatus;

   public String getOrderId()
   {
      return orderId;
   }

   public void setOrderId(String orderId)
   {
      this.orderId = orderId;
   }

   public String getOrderType()
   {
      return orderType;
   }

   public void setOrderType(String orderType)
   {
      this.orderType = orderType;
   }

   public String getOrderQuantity()
   {
      return orderQuantity;
   }

   public void setOrderQuantity(String orderQuantity)
   {
      this.orderQuantity = orderQuantity;
   }

   public String getOrderPrice()
   {
      return orderPrice;
   }

   public void setOrderPrice(String orderPrice)
   {
      this.orderPrice = orderPrice;
   }

   public String getOrderDate()
   {
      return orderDate;
   }

   public void setOrderDate(String orderDate)
   {
      this.orderDate = orderDate;
   }

   public String getPurchaseOrder()
   {
      return purchaseOrder;
   }

   public void setPurchaseOrder(String purchaseOrder)
   {
      this.purchaseOrder = purchaseOrder;
   }

   public String getOrderStatus()
   {
      return orderStatus;
   }

   public void setOrderStatus(String orderStatus)
   {
      this.orderStatus = orderStatus;
   }

   public String getCartId()
   {
      return cartId;
   }

   public void setCartId(String cartId)
   {
      this.cartId = cartId;
   }

   @Override
   public String toString()
   {
      return "OrderVO [orderId=" + orderId + "orderType=" + orderType + " orderQuantity=" + orderQuantity + " orderPrice=" + orderPrice + " orderDate=" + orderDate + " purchaseOrder=" + purchaseOrder
            + " orderStatus=" + orderStatus + "]";
   }

}
