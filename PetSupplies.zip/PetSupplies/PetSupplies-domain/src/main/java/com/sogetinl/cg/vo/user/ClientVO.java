package com.sogetinl.cg.vo.user;

import java.io.Serializable;

public class ClientVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String clientName;

	private String dbInstance;

	private String sftpServer;

	private String applicationURL;

	private Boolean enabled;

	private String errorMsg;

	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}

	/**
	 * @param clientName
	 *            the clientName to set
	 */
	public void setClientName(final String clientName) {
		this.clientName = clientName;
	}

	/**
	 * @return the dbInstance
	 */
	public String getDbInstance() {
		return dbInstance;
	}

	/**
	 * @param dbInstance
	 *            the dbInstance to set
	 */
	public void setDbInstance(final String dbInstance) {
		this.dbInstance = dbInstance;
	}

	/**
	 * @return the sftpServer
	 */
	public String getSftpServer() {
		return sftpServer;
	}

	/**
	 * @param sftpServer
	 *            the sftpServer to set
	 */
	public void setSftpServer(final String sftpServer) {
		this.sftpServer = sftpServer;
	}

	/**
	 * @return the applicationURL
	 */
	public String getApplicationURL() {
		return applicationURL;
	}

	/**
	 * @param applicationURL
	 *            the applicationURL to set
	 */
	public void setApplicationURL(final String applicationURL) {
		this.applicationURL = applicationURL;
	}

	/**
	 * @return the enabled
	 */
	public Boolean getEnabled() {
		return enabled;
	}

	/**
	 * @param enabled
	 *            the enabled to set
	 */
	public void setEnabled(final Boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg
	 *            the errorMsg to set
	 */
	public void setErrorMsg(final String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("ClientVO [clientName=");
		builder.append(clientName);
		builder.append(", dbInstance=");
		builder.append(dbInstance);
		builder.append(", sftpServer=");
		builder.append(sftpServer);
		builder.append(", applicationURL=");
		builder.append(applicationURL);
		builder.append(", enabled=");
		builder.append(enabled);
		builder.append(", errorMsg=");
		builder.append(errorMsg);
		builder.append("]");
		return builder.toString();
	}
}
