package com.sogetinl.cg.vo.dashboard;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DashboardVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Map<String, Map<String, Integer>> countSectionMap;

	private Set<String> moduleList;

	private Map<String, List<String>> utlizationMap;

	private DashboardTenantVO tenantInfo;

	private Map<String, Integer> alertSectionMap;

	public Map<String, Map<String, Integer>> getCountSectionMap() {
		return countSectionMap;
	}

	public void setCountSectionMap(
			final Map<String, Map<String, Integer>> countSectionMap) {
		this.countSectionMap = countSectionMap;
	}

	public Set<String> getModuleList() {
		return moduleList;
	}

	public void setModuleList(final Set<String> moduleList) {
		this.moduleList = moduleList;
	}

	public Map<String, List<String>> getUtlizationMap() {
		return utlizationMap;
	}

	public void setUtlizationMap(final Map<String, List<String>> utlizationMap) {
		this.utlizationMap = utlizationMap;
	}

	public DashboardTenantVO getTenantInfo() {
		return tenantInfo;
	}

	public void setTenantInfo(DashboardTenantVO tenantInfo) {
		this.tenantInfo = tenantInfo;
	}

	public Map<String, Integer> getAlertSectionMap() {
		return alertSectionMap;
	}

	public void setAlertSectionMap(Map<String, Integer> alertSectionMap) {
		this.alertSectionMap = alertSectionMap;
	}

}
