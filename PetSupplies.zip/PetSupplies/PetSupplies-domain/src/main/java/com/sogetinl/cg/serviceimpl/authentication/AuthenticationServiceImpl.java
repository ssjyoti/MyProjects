package com.sogetinl.cg.serviceimpl.authentication;



import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sogetinl.cg.dao.authentication.AuthenticationDAO;
import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.common.UserConstants;
import com.sogetinl.cg.domain.Client;
import com.sogetinl.cg.domain.Person;
import com.sogetinl.cg.domain.Role;
import com.sogetinl.cg.domain.User;
import com.sogetinl.cg.domain.UserRole;
import com.sogetinl.cg.service.authentication.AuthenticationService;
import com.sogetinl.cg.vo.user.UserVO;

@Service
@Transactional
public class AuthenticationServiceImpl implements AuthenticationService {
	private final static Logger LOG = Logger
			.getLogger(AuthenticationServiceImpl.class);

	@Autowired
	protected AuthenticationDAO authenticationDAO;

	@Override
	public User authenticate(final Person person) throws PetSuppliesException {
		LOG.info("AuthenticationServiceImpl>>> authenticate ENTER ");
		String userName = null, pwd = null;
		User user = null;

		userName = person.getUsername();
		pwd = person.getPassword();

		if (userName != null && pwd != null) {
			LOG.info("AuthenticationServiceImpl>>> authenticate returning user >> ");
			user = authenticationDAO.authenticate(userName, pwd);
		} else {
			user = new User();
			user.setComment("Please enter a valid username and/or password");
		}

		if (user != null && user.getUserName() == null) {
			final String msg = user.getComment();
			user.setComment(null);
			throw new PetSuppliesException(msg);
		}
		LOG.info("AuthenticationServiceImpl>>> authenticate EXIT ");
		return user;
	}

	@Override
   public List<UserVO> getUserListForAdmin(final User user)
         throws PetSuppliesException {

      boolean isAdmin = false;
      LOG.info("AuthenticationServiceImpl>>> getUserListForAdmin ENTER ");
      final List<UserVO> userList = new ArrayList<UserVO>();
      List<User> clientUserList = null;
      try {
         for (final UserRole userRole : user.getUserroles()) {
            final Role role = userRole.getRole();
            LOG.info("Role of user>>" + role.getRoleName());
            if ("Admin".equalsIgnoreCase(role.getRoleName())) {
               isAdmin = true;
            } 
         }

         if (isAdmin) {
            clientUserList = authenticationDAO.getUserListForAdmin(
                  user.getUserName(), user.getClient());
         } else {
            final UserVO unAuthorisedUser = new UserVO();
            unAuthorisedUser.setErrorMsg("Unauthorized to view users!");
            userList.add(unAuthorisedUser);
         }
      } catch (final PetSuppliesException e) {
         LOG.error("AuthenticationServiceImpl::getUserListForAdmin Error - "+ e);
         final UserVO fetchError = new UserVO();
         fetchError
               .setErrorMsg("getUserListForAdmin::Exception occurred while fetching users!"
                     + e.getMessage());
         userList.add(fetchError);
      }

      if (clientUserList != null && clientUserList.size() > 0) {
         for (final User userObj : clientUserList) {
            final UserVO userVO = new UserVO();
            userVO.setUserName(userObj.getUserName());
            userVO.setEmail(userObj.getEmail());
            userVO.setContactNumber(userObj.getContactNumber());
            userVO.setFirstName(userObj.getFirstName());
            userVO.setLastName(userObj.getLastName());
            userVO.setStatus(userObj.getStatus());
            userVO.setAddress(userObj.getAddress());
            userVO.setClientName(userObj.getClient().getClientName());
            userVO.setComment(userObj.getComment());
            userVO.setClientId(userObj.getClient().getClientID());
            for (final UserRole userrole : userObj.getUserroles()) {
               if (userVO.getAccessType() != null) {
                  userVO.setAccessType(userVO.getAccessType() + ","
                        + userrole.getRole().getRoleName());
               } else {
                  userVO.setAccessType(userrole.getRole().getRoleName());
               }
            }

            //if (isAdmin && "User".equalsIgnoreCase(userVO.getAccessType())) {
               userList.add(userVO);
           // } 

         }
      }
      LOG.info("AuthenticationServiceImpl>>> getUserListForAdmin EXIT");
      return userList;

   }
	
	@Override
   public String updateUser(final UserVO userVO) throws PetSuppliesException {
      LOG.info("AuthenticationServiceImpl>>> updateUser userVO>>  "
            + userVO.toString());
      final User user = new User();
      final Client cient = new Client();
      cient.setClientID(userVO.getClientId());
      cient.setClientName(userVO.getClientName());
      userVO.setIsPwdReset(true);
      BeanUtils.copyProperties(userVO, user);
      final User dbUser = authenticationDAO.getUser(user.getUserName(),
            user.getEmail());
      if (null != dbUser) {
         user.setPassword(dbUser.getPassword());
      }
      user.setClient(cient);
      java.util.Date date = new java.util.Date();
      Timestamp ts_now = new Timestamp(date.getTime());
      user.setPwdLastModifiedDate(ts_now);
      LOG.info("AuthenticationServiceImpl>>> updateUser  user>>  "
            + user.toString());
      authenticationDAO.updateUser(user);
      return UserConstants.USER_REGISTRATION_SUCCESS;
   }
	
	@Override
   public int changePassword(final String userName, final String password)
         throws PetSuppliesException {
      return authenticationDAO.changePassword(userName, password);
   }
		
}
