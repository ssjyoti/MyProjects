package com.sogetinl.cg.vo.petVO;

import java.io.Serializable;

public class ProductVO implements Serializable
{

   /** * indicates/is used for. */

   private static final long serialVersionUID = -7605905395760106739L;

   private String productId;

   private String quantity;

   private String price;

   private Integer petId;

   private String productType;

   private String breedOrItem;

   private Integer supplyId;
   
   private String petOrSupplyType;

   private String status;
   
   private String about;

   public String getProductId()
   {
      return productId;
   }

   public void setProductId(String productId)
   {
      this.productId = productId;
   }

   public String getQuantity()
   {
      return quantity;
   }

   public void setQuantity(String quantity)
   {
      this.quantity = quantity;
   }

   public String getPrice()
   {
      return price;
   }

   public void setPrice(String price)
   {
      this.price = price;
   }

   public Integer getPetId()
   {
      return petId;
   }

   public void setPetId(Integer petId)
   {
      this.petId = petId;
   }

   public String getProductType()
   {
      return productType;
   }

   public void setProductType(String productType)
   {
      this.productType = productType;
   }

   public String getBreedOrItem()
   {
      return breedOrItem;
   }

   public void setBreedOrItem(String breedOrItem)
   {
      this.breedOrItem = breedOrItem;
   }

   public Integer getSupplyId()
   {
      return supplyId;
   }

   public void setSupplyId(Integer supplyId)
   {
      this.supplyId = supplyId;
   }

   
   
   public String getPetOrSupplyType()
   {
      return petOrSupplyType;
   }

   public void setPetOrSupplyType(String petOrSupplyType)
   {
      this.petOrSupplyType = petOrSupplyType;
   }

   
   
   public String getStatus()
   {
      return status;
   }

   public void setStatus(String status)
   {
      this.status = status;
   }

   public String getAbout()
   {
      return about;
   }

   public void setAbout(String about)
   {
      this.about = about;
   }

   @Override
   public String toString()
   {
      return "ProductVO [productId=" + productId + "quantity=" + quantity + " price=" + price + " petId=" + petId + " productType=" + productType + " breedOrItem=" + breedOrItem + " supplyId=" + supplyId
            +  " petOrSupplyType=" + petOrSupplyType
            +  " status=" + status
            +  " about=" + about
            + "]";
   }

}
