package com.sogetinl.cg.service.product;

import java.util.List;

import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.vo.petVO.ProductVO;
import com.sogetinl.cg.vo.user.UserVO;

public interface ProductService
{
   public List<ProductVO> getProductSearchData() throws PetSuppliesException;
   
   public String updateProduct(ProductVO productVO) throws PetSuppliesException;
   
}
