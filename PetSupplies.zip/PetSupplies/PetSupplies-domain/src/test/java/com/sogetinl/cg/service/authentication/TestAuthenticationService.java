package com.sogetinl.cg.service.authentication;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.Gson;
import com.sogetinl.cg.common.PetSuppliesException;
import com.sogetinl.cg.domain.Person;
import com.sogetinl.cg.domain.User;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:**/testContext.xml" })
public class TestAuthenticationService extends TestCase {
   private final static Logger LOG = Logger
         .getLogger(TestAuthenticationService.class);

   @Autowired
   private AuthenticationService authenticationService;

   @Test
   public void testAuthenticate() {
      final Person person = new Person();
      person.setUsername("jyoti_user");
      person.setPassword("123456");
      User user = null;
      try {
         user = authenticationService.authenticate(person);
      } catch (final PetSuppliesException e) {
         LOG.error("Error @testAuthenticate: " + e.getMessage());
      }

      
        final Gson json = new Gson(); LOG.info(
        "testGetManualEntryDetails  :: getManualEntryDetails>> JSON >> " +
        json.toJson(user));
       
      LOG.info(user);
      LOG.info("************USER ENDS***************");
      // assertEquals("KENEXA_ADMIN", user.getUserName());
      assertNull(user.getUserName());
   }

   
}
